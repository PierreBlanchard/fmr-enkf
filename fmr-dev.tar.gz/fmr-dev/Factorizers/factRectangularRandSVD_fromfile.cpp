
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FMemUtils.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"
#include "Utils/FParameterNames.hpp"

// not mandatory but useful to define some flags
#include "Core/FFmmAlgorithm.hpp"
#include "Core/FFmmAlgorithmThread.hpp"

// ... for FMM
#include "Kernels/Interpolation/FInterpMatrixKernel.hpp" // Otherwise KERNEL_FUNCTION_TYPE not declared in M2L handler

// FMR includes
#include "Definition/FACTDefines.hpp"
#include "Correlations/CorrelationKernels.hpp"
#include "StandardLRA/SVD.hpp"
#include "StandardLRA/QRD.hpp"
#include "RandomizedLRA/AdaptiveRandomizedRangeFinder.hpp"
#include "RandomizedLRA/RandomizedRangeFinder.hpp"
#include "RandomizedLRA/RandSVD.hpp"
#include "Utils/MatrixNorms.hpp"
#include "Utils/ErrorEstimators.hpp"
#include "Utils/MatrixIO.hpp" // In order to read covariance matrix from file

#include "MatrixWrappers/DenseWrapper.hpp"

// ... for full SVD
#include "StandardLRA/fullSVD.hpp"

/**
* In this file we load a rectangular matrix M from a file. Then, we compute the (approximate) eigenvalues and eigenvectors of M using a randomized SVD.
* The randomized algorithm is powered by dense MMPs ONLY! C is explicitely build, since it is read from file.
*
* ./Factorizers/Release/factRectangularRandSVD_fromfile -binin -v 2 
* ./Factorizers/Release/factRectangularRandSVD_fromfile -binin -v 2 -mat unitSphere2000_G50_rect
*
* For POD: if binary input matrix is located on local computer
* ./Factorizers/Release/factRectangularRandSVD_fromfile -binin -v 2 -mat POD/snapshots_r58176_c5501 -pr 500 -os 100 -verifyRSVD 0
* 
* Author: Pierre Blanchard (pierre.blanchard@inria.fr)
* Date created: March 11th, 2015 
*/


int main(int argc, char* argv[])
{
	std::cout << "Factorize a RECTANGULAR matrix loaded from file using a randomized SVD." << std::endl;

    ////////////////////////////////////////////////////////////////////
    /// Input file

    // input matrix filename
    const std::string matrixName(FParameters::getStr(argc,argv,"-mat", "Covariance/unitSphere2000_G50"));
    const std::string matrixPath = FParameters::getStr(argc,argv,"-pmat", std::string("../Data/Matrices/" + matrixName).c_str());
    const std::string matrixfilename = FParameters::getStr(argc,argv,"-fmat", std::string(matrixPath + ".bin").c_str());

    ////////////////////////////////////////////////////////////////////
    /// Read matrix
    std::cout<< "Read matrix from file: " ;

    // Display name
    std::cout<< matrixfilename << "\n";

    // Declare M
    FReal *M = nullptr;
  
    // Read matrix in binary file
    FSize nbRows, nbCols; nbRows=nbCols=0;
    MatrixIO::read(nbRows,nbCols,M,matrixfilename);
    std::cout<< "nbRows=" << nbRows << std::endl  ;
    std::cout<< "nbCols=" << nbCols << std::endl  ;

    // Minimum dimension needs be nbRows, i.e. short and fat matrix
    //if(nbRows>nbCols) 
    //    throw std::runtime_error("Matrix is not short-fat, need to transpose matrix first [TODO]!");

    // This test is for non symmetric matrices (can be modified)
    const bool isMatrixSymmetric = false;

    ////////////////////////////////////////////////////////////////////
    /// Timers
    FTic time;
    time.tic();

    ////////////////////////////////////////////////////////////////////
    /// Parameters

    // Verbose (print matrices)
    const int verbose = FParameters::getValue(argc, argv, "-v", 0);
    const FSize displaySize = 10;
    std::cout<< "Verbose level: " << verbose <<std::endl;
    // randomized range finder (0: fixed accuracy; 1: fixed rank)
    const int flag_RRF = FParameters::getValue(argc, argv, "-fRRF", 1);
    // prescribed rank
    const FSize prescribed_rank = FParameters::getValue(argc, argv, "-pr", nbCols/10);
    const int oversampling = FParameters::getValue(argc, argv, "-os", 5);
    const int qRSI = FParameters::getValue(argc, argv, "-q", 0);
    // prescribed accuracy and balance parameter
    const int eARRF = FParameters::getValue(argc, argv, "-pe", 6); 
    const int bARRF = FParameters::getValue(argc, argv, "-b", 10);
    const FSize adaptive_rank = FParameters::getValue(argc, argv, "-rmax", nbCols/10); // DO NOT CONSIDER compression rates below 10%!
    // Use a precomputed Gaussian random matrix (for purpose of comparison of FMM and STD RandSVD)
    const bool readW = false;
    // Verify RSVD outputs (namely approximation of matrix C)
    const bool verifyRSVD = FParameters::getValue(argc, argv, "-verifyRSVD", true);

    // Display parameters
    if(flag_RRF==0) {
        std::cout<< "Rank: not known a priori!" <<std::endl;
        std::cout<< "Adaptive parameters: balance=" << bARRF 
                 << " - accuracy=1.e-" << eARRF <<std::endl;
        std::cout<< "Nb of power iterations: " << qRSI <<std::endl;
    }
    else {
        std::cout<< "Prescribed rank: " << prescribed_rank <<std::endl;
        std::cout<< "Oversampling: " << oversampling <<std::endl;
        if((prescribed_rank+oversampling)>nbCols) 
            throw std::runtime_error("Oversampled rank should be lower than full rank!");
        std::cout<< "Nb of subspace iterations: " << qRSI <<std::endl;
    }
    std::cout<< "Application of M: Dense (BLAS::gemm())" <<std::endl;

    // display C
    std::setprecision(15);
    if(verbose){
        std::cout<<"\nM=["<<std::endl;
        for ( FSize i=0; i<displaySize; ++i) {
            for ( FSize j=0; j<displaySize; ++j)
                std::cout << M[i+j*nbRows] << " ";
            std::cout<< std::endl;
        }
        std::cout<<"]"<<std::endl;
    }

    ////////////////////////////////////////////////////////////////////
    /// Compute and store exact singular values

    // Declare pointer to Sigma
    FReal *Sigma = NULL;

    if(verifyRSVD)
    {

        // Declare SV output filename
        std::string svfilename = matrixPath + "-sv";
        // Read sv if file exists, compute sv abd write in file otherwise
        fullSVD<FReal>::ReadIfExists_ComputeAndWriteOtherwise(nbRows,nbCols,M,Sigma,svfilename,false/*Matrix C is NOT symmetric in general*/,true);

    }// end verifyRSVD



    ////////////////////////////////////////////////////////////////////
    /// Init FMR components for factorization of M

    // Dense Matrix Wrapper
    typedef DenseWrapper<FReal> DenseWrapperClass;

    // Fixed rank RRF
    typedef RRF<FReal,DenseWrapperClass> RRFClass;
    // Fixed accuracy RRF (or Adaptive RRF)
    typedef AdaptiveRRF<FReal,DenseWrapperClass> ARRFClass;

    ////////////////////////////////////////////////////////////////////
    /// Compute FACT using randomized routine

    // Declare square root and rank 
    FReal* U = NULL; 
    FReal* VT = NULL; 
    FSize rank = 0;
    FReal* ApproxSingularValues=NULL;
    //
    FTic timeRandSVD, timeInitRandSVD;
    double tRSVD,tInitRSVD;
    {
        std::cout << "\nInit Randomized SVD ... \n";
        timeInitRandSVD.tic();
        //
        // Init matrix wrapper
        //
        DenseWrapperClass MatrixWrapper(nbRows, nbCols, isMatrixSymmetric);
        MatrixWrapper.init(M);
        //
        // Init RRF algorithm
        // 
        if(flag_RRF==0) { // Adaptive Randomized Range Finder
            ARRFClass AdaptRandRangeFinder(&MatrixWrapper,eARRF,bARRF,adaptive_rank,qRSI); 
            tInitRSVD = timeInitRandSVD.tacAndElapsed();
            std::cout << "... took @tInitRSVD = "<< tInitRSVD <<"\n";
            //
            std::cout << "\nPerform Randomized SVD ... ";
            timeRandSVD.tic();
            RandSVD<FReal,ARRFClass> RSVD(nbRows,nbCols,&AdaptRandRangeFinder);
            rank = RSVD.computeFACT(readW);
            // Get approx. singular values
            ApproxSingularValues = new FReal[rank];
            FBlas::copy(int(rank),RSVD.getApproxSingularValues(),ApproxSingularValues);
            // Get approx. singular vectors
            U = new FReal[nbRows*rank];
            FBlas::copy(int(nbRows*rank),RSVD.getApproxU(),U);
            VT = new FReal[nbCols*rank];
            FBlas::copy(int(nbCols*rank),RSVD.getApproxVT(),VT);   
        }
        else if(flag_RRF==1) { // Classic Randomized Range Finder
            RRFClass RandRangeFinder(&MatrixWrapper,prescribed_rank,oversampling,qRSI);
            tInitRSVD = timeInitRandSVD.tacAndElapsed();
            std::cout << "... took @tInitRSVD = "<< tInitRSVD <<"\n";
            //
            std::cout << "\nPerform Randomized SVD ... ";
            timeRandSVD.tic();
            RandSVD<FReal,RRFClass> RSVD(nbRows,nbCols,&RandRangeFinder);
            rank = RSVD.computeFACT(readW);
            // Get approx. singular values
            ApproxSingularValues = new FReal[rank];
            FBlas::copy(int(rank),RSVD.getApproxSingularValues(),ApproxSingularValues);
            // Get approx. singular vectors
            U = new FReal[nbRows*rank];
            FBlas::copy(int(nbRows*rank),RSVD.getApproxU(),U);
            VT = new FReal[nbCols*rank];
            FBlas::copy(int(nbCols*rank),RSVD.getApproxVT(),VT);                        
        }
        tRSVD = timeRandSVD.tacAndElapsed();
        std::cout << "... took @tRSVD = "<< tRSVD <<"\n";
    }


    ////////////////////////////////////////////////////////////////////
    /// Show approximate singular values & store in txt file
    if(verbose>=1){  
        Display::vector(rank,ApproxSingularValues,"ApproxSingularValues",std::min(rank,displaySize),0);
    }

    {

        // Declare ASV output filename
        std::ostringstream oss_rank; oss_rank << rank;
        std::ostringstream oss_qRSI; oss_qRSI << qRSI;
        std::string approxsvfilename = matrixPath + "-approxsv" + oss_rank.str();
        if(qRSI>0)
            approxsvfilename+= "-q" + oss_qRSI.str();
        approxsvfilename += ".txt";

        std::cout << "Write first " << rank << " approx. sigular values in "<< approxsvfilename <<"."<< std::endl;

        // Size
        const FSize svdSize = rank;

        FSize sizeSVDINFO = svdSize;
        FSize rankSVDINFO = 3; // SINGVALS, OESPEC, OEFROB

        // Allocate memory for singular values and optimal errors
        FReal* optErrorSpec = new FReal[svdSize];
        FReal* optErrorFrob = new FReal[svdSize];
        FReal* SVDINFO = new FReal[svdSize*rankSVDINFO];

        // Optimal/Minimal errors in Spectral norm (first entry has no meaning, should be equal to 1)
        for(FSize i = 0 ; i<svdSize ; ++i)
            optErrorSpec[i]=FMath::Abs(ApproxSingularValues[i]/ApproxSingularValues[0]);
        // Optimal/Minimal errors in Frobenius norm
        optErrorFrob[svdSize-1]=ApproxSingularValues[svdSize-1]*ApproxSingularValues[svdSize-1];
        for(FSize i = svdSize-2 ; i>=0 ; --i){
            optErrorFrob[i]=optErrorFrob[i+1]+ApproxSingularValues[i]*ApproxSingularValues[i];
        }
        FBlas::scal(int(svdSize),FReal(1.)/optErrorFrob[0],optErrorFrob);
        
        for(FSize i = 0 ; i<svdSize-1 ; ++i)
            optErrorFrob[i]=FMath::Sqrt(optErrorFrob[i]);

        // Copy SVD infos
        for(FSize i = 0 ; i<sizeSVDINFO ; ++i){
            SVDINFO[i+0*sizeSVDINFO]=ApproxSingularValues[i];
            SVDINFO[i+1*sizeSVDINFO]=optErrorSpec[i];
            SVDINFO[i+2*sizeSVDINFO]=optErrorFrob[i];
        }

        //// Write singular values in binary file
        //MatrixIO::write(matrixSize,1,Sigma,svfilename);
        // Write singular values in text file
        MatrixIO::writeCSV_sv(sizeSVDINFO,rankSVDINFO,SVDINFO,approxsvfilename);

        delete[] SVDINFO;
        delete[] optErrorSpec;
        delete[] optErrorFrob;

    }

    if(verifyRSVD)
    {
        ////////////////////////////////////////////////////////////////////
        /// Verify that M ~ Q(Q^tMQ)Q^t = QQ^t(M)QQ^t
        std::cout << "\nVerify approximation of M... \n";
        FTic timeApprox;
        timeApprox.tic();
        FrobeniusError<FReal> errorM_Frob;
        //FReal errorM_Spec, errorM_SpecRel;

        /// Compute and display errors

        // Form M_approx = USV^t
        FReal *const M_approx = new FReal [nbRows*nbCols];

        // Copy U in US
        FReal *const US = new FReal [nbRows*rank];
        is_int(nbRows*rank);
        FBlas::copy(int(nbRows*rank),U,US);

        // Form US=U x S
        is_int(nbRows);
        for ( FSize j=0; j<rank; ++j) 
            FBlas::scal(int(nbRows),ApproxSingularValues[j],US+j*nbRows);

        // Form USVt=US x Vt
        is_int(nbRows); is_int(rank); 
        FBlas::gemm(int(nbRows),int(rank),int(nbCols),FReal(1.),
                   US,int(nbRows),VT,int(rank),M_approx,int(nbRows));

        delete [] US;

        // display M_approx
        if(verbose==2){
            std::cout<<"\nM_approx=["<<std::endl;
            for ( FSize i=0; i<displaySize; ++i) {
                for ( FSize j=0; j<displaySize; ++j)
                    std::cout << M_approx[i+j*nbRows] << " ";
                std::cout<< std::endl;
            }
            std::cout<<"]"<<std::endl;
        }

        // Compare spectrum
        std::cout << "Error ||Sigma_approx - Sigma||_L2/Inf\n";
        FMath::FAccurater<FReal> errorSingVals;
        for ( FSize i=0; i<rank; ++i) 
          errorSingVals.add(Sigma[i],ApproxSingularValues[i]);
        std::cout << " L2  = "<< errorSingVals.getRelativeL2Norm() <<"\n";
        std::cout << " Inf = "<< errorSingVals.getRelativeInfNorm() <<"\n";

        // M - (QU)S(QU)^t
        std::cout << "Error ||M - (QU)S(QU)^t||_F\n";
        // Compute error in Frobenius norm
        for ( FSize i=0; i<nbRows; ++i) 
            for ( FSize j=0; j<nbCols; ++j)
                errorM_Frob.addRel(M[i+j*nbRows],M_approx[i+j*nbRows]);
        std::cout << " Frob  = "<< errorM_Frob.getNorm() <<"\n";
        std::cout << " FrobRel  = "<< errorM_Frob.getRelativeNorm() <<"\n";
//
//        // Compute error on a matrix vector product  || (QU)S(QU)^tX - CX ||
//        // ... with X a random vector
//        FReal* pV = new FReal[matrixSize];
//        std::mt19937_64 generator(std::random_device{}());
//        std::normal_distribution<double> distribution(0.0,1.0);
//        distribution(generator); // init
//        for ( FSize i=0; i<matrixSize; ++i) pV[i] = FReal(distribution(generator));
//        // Applying C and C_approx to X
//        FReal* Prandlr = new FReal[matrixSize];      
//        is_int(matrixSize); 
//        FBlas::gemv(int(matrixSize),int(matrixSize),FReal(1.),C_approx,pV,Prandlr);
//        // Init potential for direct calculation
//        FReal* Pdirect = new FReal[matrixSize]; 
//        is_int(matrixSize); 
//        FBlas::gemv(int(matrixSize),int(matrixSize),FReal(1.),C,pV,Pdirect);
//        // Compute error 
//        std::cout << "Error ||CX - (QU)S(QU)^tX||_L2/Inf\n";
//        FMath::FAccurater<FReal> errorMVP;
//        for ( FSize i=0; i<matrixSize; ++i) 
//          errorMVP.add(Pdirect[i],Prandlr[i]);
//        std::cout << " L2  = "<< errorMVP.getRelativeL2Norm() <<"\n";
//        std::cout << " Inf = "<< errorMVP.getRelativeInfNorm() <<"\n";
//
//        // Compute error in Spectral norm (requires NxN SVD...)
//        // BEWARE! C_approx is modified here
//        std::cout << "Error ||C - (QU)S(QU)^t||_S\n";
//        for ( FSize i=0; i<matrixSize; ++i) 
//            for ( FSize j=0; j<matrixSize; ++j)
//                C_approx[i*matrixSize+j]-=C[i*matrixSize+j];
//        errorC_Spec = MatrixNorms<FReal>::computeSpectral(matrixSize,C_approx);
//        errorC_SpecRel = errorC_Spec / Sigma[0]; 
//        std::cout << " Spec  = "<< errorC_Spec <<"\n";
//        std::cout << " SpecRel  = "<< errorC_SpecRel <<"\n";
//
        delete [] M_approx;
//
        double tApprox = timeApprox.tacAndElapsed();
        std::cout << "... took @tApprox = " << tApprox <<"\n";
//
//        /// Display infos on error estimation
//        std::cout << "\nA few infos on error estimation: \n";
//        std::cout << "@errorC_Frob = "<< errorC_Frob.getNorm() <<"\n";
//        std::cout << "@errorC_FrobRel = "<< errorC_Frob.getRelativeNorm() <<"\n";
//
//        std::cout << "@errorC_Spec = "<< errorC_Spec <<"\n";
//        std::cout << "@errorC_SpecRel = "<< errorC_SpecRel <<"\n";
//
//        std::cout << "@errorSingVals_L2  = "<< errorSingVals.getRelativeL2Norm() <<"\n";
//        std::cout << "@errorSingVals_Inf = "<< errorSingVals.getRelativeInfNorm() <<"\n";
//
//        std::cout << "@errorMVP_L2  = "<< errorMVP.getRelativeL2Norm() <<"\n";
//        std::cout << "@errorMVP_Inf = "<< errorMVP.getRelativeInfNorm() <<"\n";
//        std::cout << "@tApprox = "<< tApprox <<"\n";
//
    }// end verifyRSVD
//
//
//    /// Display results and perfs
//    std::cout << "\nA few parameters and performances (of the RandSVD): \n";
//    std::cout << "@tInitRSVD = "<< tInitRSVD <<"\n";
//    std::cout << "@tRSVD = "<< tRSVD <<"\n";

    /// Free memory
    delete[] M;
    delete[] U;
    delete[] VT;
    delete[] Sigma;

    return 0;
}
