
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FMemUtils.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"
#include "Utils/FParameterNames.hpp"

// not mandatory but useful to define some flags
#include "Core/FFmmAlgorithm.hpp"
#include "Core/FFmmAlgorithmThread.hpp"

// ... for FMM
#include "Kernels/Interpolation/FInterpMatrixKernel.hpp" // Otherwise KERNEL_FUNCTION_TYPE not declared in M2L handler

// FMR includes
#include "Definition/FMRDefines.hpp"
#include "Correlations/CorrelationKernels.hpp"
#include "StandardLRA/SVD.hpp"
#include "StandardLRA/fullSVD.hpp"
#include "StandardLRA/QRD.hpp"
#include "RandomizedLRA/AdaptiveRandomizedRangeFinder.hpp"
#include "RandomizedLRA/RandomizedRangeFinder.hpp"
#include "RandomizedLRA/RandSVD.hpp"
#include "Utils/MatrixNorms.hpp"
#include "Utils/ErrorEstimators.hpp"
#include "Utils/MatrixIO.hpp" // In order to read covariance matrix from file

// ... for FMM
#include "Definition/ScalFMMDefines.hpp"
#include "FMM/UniformKernel.hpp"
#include "FMM/FMMWrapper.hpp"
#include "MatrixWrappers/DenseWrapper.hpp"

/**
* In this file load a grid from a file and generate a covariance matrix C. Then we compute the (approximate) eigenvalues and eigenvectors of C using a randomized SVD.
* The randomized algorithm is powered by either regular, blas or FMM MMPs. C can be explicitely build (not mandatory), in this case C can then be stored in file in order 
* to be re-used as input in factRandSVD_fromfile.cpp
*
* Author: Pierre Blanchard (pierre.blanchard@inria.fr)
* Date created: April 9th, 2015 
*/


int main(int argc, char* argv[])
{
	std::cout << "Factorize a matrix loaded from file (or generated from a grid) using a randomized SVD." << std::endl;

    ////////////////////////////////////////////////////////////////////
    /// Input file

    // Still read geometry (for now)
    const std::string distributionName(FParameters::getStr(argc,argv,"-d",   "unitSphere2000"));
    const std::string distributionPath(FParameters::getStr(argc,argv,"-p2d", "../Data/FMAInput/"));
    std::string myfilename = distributionPath + distributionName;
    if(  FParameters::existParameter(argc, argv, FParameterDefinitions::InputBinFormat.options)){
        myfilename += ".bfma";
    }
    else {
        myfilename += ".fma";
    }

    const char* const filename       = FParameters::getStr(argc,argv,"-f", myfilename.c_str());
    // open particle file
    FFmaGenericLoader<FReal> loader(filename);
    if(!loader.isOpen()) throw std::runtime_error("Particle file couldn't be opened!");

    ////////////////////////////////////////////////////////////////////
    /// Timers
    FTic time;
    time.tic();

    ////////////////////////////////////////////////////////////////////
    /// Parameters

    // Verbose (print matrices)
    const int verbose = FParameters::getValue(argc, argv, "-v", 0);
    const FSize displaySize = 10;
    std::cout<< "Verbose level: " << verbose <<std::endl;
    // dimension
    static const int dim = 3;
    // size of the grid
    const FSize sizeGrid = loader.getNumberOfParticles();
    std::cout<< "Full rank: " << sizeGrid <<std::endl;
    // randomized range finder (0: fixed accuracy; 1: fixed rank)
    const int flag_RRF = FParameters::getValue(argc, argv, "-fRRF", 1);
    // prescribed rank
    const FSize prescribed_rank = FParameters::getValue(argc, argv, "-pr", sizeGrid/10);
    const int oversampling = FParameters::getValue(argc, argv, "-os", 5);
    const int qRSI = FParameters::getValue(argc, argv, "-q", 0);
    // prescribed accuracy and balance parameter
    const int eARRF = FParameters::getValue(argc, argv, "-pe", 6); 
    const int bARRF = FParameters::getValue(argc, argv, "-b", 10);
    const FSize adaptive_rank = FParameters::getValue(argc, argv, "-rmax", sizeGrid/10); // DO NOT CONSIDER compression rates below 10%!
    // Build C?
    const bool buildC = FParameters::getValue(argc, argv, "-fbuildC", true);
    // Option to write covariance matrix in file
    const bool storeCinfile(FParameters::getValue(argc,argv,"-storeCinfile",   false));
    // fast variant of RRF algo (0: blas, 1: fmm, 2: todo)
    const int flag_MMP = FParameters::getValue(argc, argv, "-fMMP", 0);
    // Indicate if MVP should be verified during RandSVD algo
    const bool verifyMMP = FParameters::getValue(argc, argv, "-verifyMMP", true);
    // Use a precomputed Gaussian random matrix (for purpose of comparison of FMM and STD RandSVD)
    const bool readW = false;
    // Verify RSVD outputs (namely approximation of matrix C)
    const bool verifyRSVD = FParameters::getValue(argc, argv, "-verifyRSVD", true);

    // Display parameters
    if(flag_RRF==0) {
        std::cout<< "Rank: not known a priori!" <<std::endl;
        std::cout<< "Adaptive parameters: balance=" << bARRF 
                 << " - accuracy=1.e-" << eARRF <<std::endl;
        std::cout<< "Nb of power iterations: " << qRSI <<std::endl;
    }
    else {
        std::cout<< "Prescribed rank: " << prescribed_rank <<std::endl;
        std::cout<< "Oversampling: " << oversampling <<std::endl;
        if((prescribed_rank+oversampling)>sizeGrid) 
            throw std::runtime_error("Oversampled rank should be lower than full rank!");
        std::cout<< "Nb of subspace iterations: " << qRSI <<std::endl;
    }
    std::cout<< "Application of C: " << flag_MMP << " (0: Blas,1: FMM, 2: [TODO] HMat)" <<std::endl;

    ////////////////////////////////////////////////////////////////////
    /// Generate 3D grid
    FPoint<FReal>* grid = new FPoint<FReal>[sizeGrid];
    FReal* pV = new FReal[sizeGrid];

    for(FSize idxPart = 0 ; idxPart < sizeGrid ; ++idxPart){
        FPoint<FReal> position;
        FReal physicalValue = 0.0;
        loader.fillParticle(&position,&physicalValue);
        grid[idxPart]=position;
        pV[idxPart]=physicalValue;
    }

    ////////////////////////////////////////////////////////////////////
    /// Build covariance matrix C
  
    // Set length scales
    const FReal lengthScale[dim] = {FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.)),
                                    FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.)),
                                    FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.))}; 

    // correlation function
    std::cout<< "Correlation function: " ;
    typedef CK_Gauss<FReal,dim> CorrelationKernelClass; 
    const unsigned int CID = CorrelationKernelClass::CID;
    CorrelationKernelClass CorrelationKernel(lengthScale);

    // Declare pointer to C
    FReal *C;
    FReal *Sigma;

    // Build C?
    if(!buildC){C = NULL; Sigma = NULL;}
    else{

        std::cout<< "Assemble covariance matrix C: " ;
  
        C = new FReal[sizeGrid*sizeGrid];
  
        FTic timeAssC;
        for(FSize idxRow = 0 ; idxRow < sizeGrid  ; ++idxRow)
            for(FSize idxCol = 0 ; idxCol < sizeGrid  ; ++idxCol)
                C[idxRow*sizeGrid+idxCol] = CorrelationKernel.evaluate(grid[idxRow],
                                                                       grid[idxCol]);
        double tAssC = timeAssC.tacAndElapsed();
        std::cout << "... took @tAssC = "<< tAssC <<"\n";
    
        if(storeCinfile){

            std::cout<< "Store covariance matrix C in file: " ;

            const std::string matrixName(FParameters::getStr(argc,argv,"-mat", "unitSphere2000"));
            std::string paramsName;
            std::ostringstream oss;
            oss << 100*lengthScale[0];
            if(CID==0) // EXPO
                paramsName = "_E" + oss.str();
            else if(CID==1) // GAUSS
                paramsName = "_G" + oss.str();

            const std::string matrixfilename = FParameters::getStr(argc,argv,"-fmat", std::string("../Data/Matrices/Covariance/" + matrixName + paramsName + ".bin").c_str());
            
            // Display name
            std::cout<< matrixfilename ;

            // Write matrix
            MatrixIO::write(sizeGrid,sizeGrid,C,matrixfilename);

        }// end write C in file

        // display C
        if(verbose){
            Display::matrix(sizeGrid,sizeGrid,C,"C",displaySize);
        }
  
        ////////////////////////////////////////////////////////////////////
        /// Compute and store exact singular values        
        std::ostringstream oss;
        if(CID == 0) oss << "_E";
        else if(CID == 1) oss << "_G";
        else throw std::runtime_error("Provide a valid correlation kernel!");
        oss << 100*lengthScale[0];

        // Declare SV output filename
        std::string svfilename = "../Data/SingVals/" + distributionName + oss.str() + "-sv";

        if(verifyRSVD)
        {

            fullSVD<FReal>::ReadIfExists_ComputeAndWriteOtherwise(sizeGrid,sizeGrid,C,Sigma,svfilename,true/*Matrix C is ALWAYS symmetric in this test*/);

            // Check positivity ?
            std::cout << "C is non-negative? ";
            bool isNonNeg=true;
            for(FSize i = 0 ; i<sizeGrid ; ++i)
                if(Sigma[i]<-1e-14) isNonNeg=false;
            if(isNonNeg) std::cout << "YES." << std::endl;
            else std::cout << "NO, C has negative singular values!" << std::endl;

        }// end verifyRSVD

    }// end build C

    ////////////////////////////////////////////////////////////////////
    /// Init FMM components for fast application of C

    // Approximate nearfield? Kernel needs to be smooth (in particular at origin), e.g. Gaussian.
    const bool approximateNearfield = FParameters::getValue(argc, argv, "-appNF", false);
    // tree height
    const int TreeHeight    = FParameters::getValue(argc,argv,"-h", 3);
    const int SubTreeHeight = FParameters::getValue(argc,argv,"-sh", 2);
    // init oct-tree
    OctreeClass tree(TreeHeight, SubTreeHeight, loader.getBoxWidth(), loader.getCenterOfBox());
    // UnifFMM with precomputed P2P
    typedef UniformKernel< FReal, CellClass, ContainerClass, CorrelationKernelClass, ORDER, NVALS > FMMKernelClass;
    // ScalFMM algorithm    
    typedef FFmmAlgorithm<OctreeClass,CellClass,ContainerClass,FMMKernelClass,LeafClass> FMMAlgoClass;

    ////////////////////////////////////////////////////////////////////
    /// Init FMR components for factorization of C

    // FMM Matrix Wrapper
    typedef FMMWrapper<FReal,OctreeClass,CorrelationKernelClass,FMMKernelClass,FMMAlgoClass> FMMWrapperClass;
    // Dense Matrix Wrapper
    typedef DenseWrapper<FReal> DenseWrapperClass;

    // Fixed rank RRF
    typedef AdaptiveRRF<FReal,FMMWrapperClass> FMM_ARRFClass;
    typedef AdaptiveRRF<FReal,DenseWrapperClass> Dense_ARRFClass;
    // Fixed accuracy RRF (or Adaptive RRF)
    typedef RRF<FReal,FMMWrapperClass> FMM_RRFClass;
    typedef RRF<FReal,DenseWrapperClass> Dense_RRFClass;

    ////////////////////////////////////////////////////////////////////
    /// Compute FACTORIZATION using randomized SVD

    // Declare singular vectors and rank 
    FReal* U = NULL; 
    FSize rank = 0;
    FReal* ApproxSingularValues=NULL;
    //
    FReal energy2 = 0.;
    FReal estimator_order_approx_Spec = 1.;
    FTic timeRandSVD, timeInitRandSVD;
    double tRSVD,tInitRSVD;
    {
        std::cout << "\nInit Randomized SVD ... \n";
        timeInitRandSVD.tic();
        //
        // Init RRF algorithm
        if(flag_RRF==0 && flag_MMP<2) { // Adaptive Randomized Range Finder + Dense MMPs
            // Dense Wrapper
            DenseWrapperClass* DenseMatrixWrapper = new DenseWrapperClass(sizeGrid,sizeGrid,true);
            DenseMatrixWrapper->init(C);
            // Adaptive RRF
            Dense_ARRFClass AdaptRandRangeFinder(DenseMatrixWrapper,eARRF,bARRF,adaptive_rank,qRSI,verifyMMP); 
            //
            tInitRSVD = timeInitRandSVD.tacAndElapsed();
            std::cout << "... took @tInitRSVD = "<< tInitRSVD <<"\n";
            //
            std::cout << "\nPerform Randomized SVD ... ";
            timeRandSVD.tic();
            // RandSVD
            RandSVD<FReal,Dense_ARRFClass> RSVD(sizeGrid,sizeGrid,&AdaptRandRangeFinder);
            rank = RSVD.computeSQRT(readW);
            // Get approx. singular vectors
            U = new FReal[sizeGrid*rank];
            FBlas::copy(int(sizeGrid*rank),RSVD.getApproxU(),U);
            // Get some parameters
            energy2=RSVD.getEnergy2(); estimator_order_approx_Spec=RSVD.getApproxBaselineSpec();
        }
        else if(flag_RRF==0 && flag_MMP==2) { // Adaptive Randomized Range Finder + FMM MMPs
            // FMM Wrapper
            FMMWrapperClass* FMMMatrixWrapper = new FMMWrapperClass(&tree,&CorrelationKernel,grid,sizeGrid,approximateNearfield);
            FMMMatrixWrapper->init();
            // Adaptive RRF
            FMM_ARRFClass AdaptRandRangeFinder(FMMMatrixWrapper,eARRF,bARRF,adaptive_rank,qRSI,verifyMMP); 
            //
            tInitRSVD = timeInitRandSVD.tacAndElapsed();
            std::cout << "... took @tInitRSVD = "<< tInitRSVD <<"\n";
            //
            std::cout << "\nPerform Randomized SVD ... ";
            timeRandSVD.tic();
            // RandSVD
            RandSVD<FReal,FMM_ARRFClass> RSVD(sizeGrid,sizeGrid,&AdaptRandRangeFinder);
            rank = RSVD.computeSQRT(readW);
            // Get approx. singular vectors
            U = new FReal[sizeGrid*rank];
            FBlas::copy(int(sizeGrid*rank),RSVD.getApproxU(),U);
            // Get some parameters
            energy2=RSVD.getEnergy2(); estimator_order_approx_Spec=RSVD.getApproxBaselineSpec();
        }
        else if(flag_RRF==1 && flag_MMP<2) { // Classic Randomized Range Finder + Dense MMPs
            // Dense Wrapper
            DenseWrapperClass* DenseMatrixWrapper = new DenseWrapperClass(sizeGrid,sizeGrid,true);
            DenseMatrixWrapper->init(C);
            // RRF
            Dense_RRFClass RandRangeFinder(DenseMatrixWrapper,prescribed_rank,oversampling,qRSI,verifyMMP);
            tInitRSVD = timeInitRandSVD.tacAndElapsed();
            std::cout << "... took @tInitRSVD = "<< tInitRSVD <<"\n";
            //
            std::cout << "\nPerform Randomized SVD ... ";
            timeRandSVD.tic();
            // RandSVD
            RandSVD<FReal,Dense_RRFClass> RSVD(sizeGrid,sizeGrid,&RandRangeFinder);
            rank = RSVD.computeFACT(readW);
            // Get approx. singular values
            ApproxSingularValues = new FReal[rank];
            FBlas::copy(int(rank),RSVD.getApproxSingularValues(),ApproxSingularValues);
            // Get approx. singular vectors
            U = new FReal[sizeGrid*rank];
            FBlas::copy(int(sizeGrid*rank),RSVD.getApproxU(),U);
            // Get some parameters
            energy2=RSVD.getEnergy2(); estimator_order_approx_Spec=RSVD.getApproxBaselineSpec();
        }
        else if(flag_RRF==1 && flag_MMP==2) { // Classic Randomized Range Finder + FMM MMPs
            // FMM Wrapper
            FMMWrapperClass* FMMMatrixWrapper = new FMMWrapperClass(&tree,&CorrelationKernel,grid,sizeGrid,approximateNearfield);
            FMMMatrixWrapper->init();
            // RRF
            FMM_RRFClass RandRangeFinder(FMMMatrixWrapper,prescribed_rank,oversampling,qRSI,verifyMMP);
            tInitRSVD = timeInitRandSVD.tacAndElapsed();
            std::cout << "... took @tInitRSVD = "<< tInitRSVD <<"\n";
            //
            std::cout << "\nPerform Randomized SVD ... ";
            timeRandSVD.tic();
            // RandSVD
            RandSVD<FReal,FMM_RRFClass> RSVD(sizeGrid,sizeGrid,&RandRangeFinder);
            rank = RSVD.computeFACT(readW);
            // Get approx. singular values
            ApproxSingularValues = new FReal[rank];
            FBlas::copy(int(rank),RSVD.getApproxSingularValues(),ApproxSingularValues);
            // Get approx. singular vectors
            U = new FReal[sizeGrid*rank];
            FBlas::copy(int(sizeGrid*rank),RSVD.getApproxU(),U);
            // Get some parameters
            energy2=RSVD.getEnergy2(); estimator_order_approx_Spec=RSVD.getApproxBaselineSpec();
        }
        else {throw std::runtime_error("Wrong combination of flags (flag_RRF && flag_MMP)!");}
        tRSVD = timeRandSVD.tacAndElapsed();
        std::cout << "... took @tRSVD = "<< tRSVD <<"\n";
    }


    ////////////////////////////////////////////////////////////////////
    /// Show eigen values and vectors & store them in binary file
    if(verbose)
        Display::vector(rank,ApproxSingularValues,"approxSV",displaySize,1);

    if(verifyRSVD)
    {

    ////////////////////////////////////////////////////////////////////
    /// Verify that C ~ Q(Q^tCQ)Q^t = QQ^t(C)QQ^t
    std::cout << "\nVerify approximation of C... \n";
    FTic timeApprox;
    timeApprox.tic();
    FrobeniusError<FReal> errorC_Frob;
    FReal errorC_Spec, errorC_SpecRel;

    /// Compute and display errors
    if(buildC){

        // Form C_approx = USU^t
        FReal *const C_approx = new FReal [sizeGrid*sizeGrid];

        // Copy U in US
        FReal *const US = new FReal [sizeGrid*rank];
        FBlas::copy(int(sizeGrid*rank),U,US);

        // Form US=U x S
        for ( FSize j=0; j<rank; ++j) 
            FBlas::scal(int(sizeGrid),ApproxSingularValues[j],US+j*sizeGrid);

        // Form USUt=US x Ut
        is_int(sizeGrid); is_int(rank); 
        FBlas::gemmt(int(sizeGrid),int(rank),int(sizeGrid),FReal(1.),
                   US,int(sizeGrid),U,int(sizeGrid),C_approx,int(sizeGrid));

        delete [] US;

        // C - (QU)S(QU)^t
        std::cout << "Error ||C - (QU)S(QU)^t||_F\n";
        // Compute error in Frobenius norm
        for ( FSize i=0; i<sizeGrid; ++i) 
            for ( FSize j=0; j<sizeGrid; ++j)
                errorC_Frob.addRel(C[i*sizeGrid+j],C_approx[i*sizeGrid+j]);
        std::cout << " Frob  = "<< errorC_Frob.getNorm() <<"\n";
        std::cout << " FrobRel  = "<< errorC_Frob.getRelativeNorm() <<"\n";

        // Compute error on a matrix vector product  || (QU)S(QU)^tX - CX ||
        FReal* Prandlr = new FReal[sizeGrid]; 
        // Applying (QU)S(QU)^t to X
        is_int(sizeGrid); is_int(rank); 
        FBlas::gemv(int(sizeGrid),int(rank),FReal(1.),C_approx,pV,Prandlr);
        // Init potential for direct calculation
        FReal* Pdirect = new FReal[sizeGrid]; 
        FBlas::gemv(int(sizeGrid),int(rank),FReal(1.),C,pV,Pdirect);
        // Compute error 
        std::cout << "Error ||CX - (QU)S(QU)^tX||_L2/Inf\n";
        FMath::FAccurater<FReal> errorMVP;
        for ( FSize i=0; i<sizeGrid; ++i) 
          errorMVP.add(Pdirect[i],Prandlr[i]);
        std::cout << " L2  = "<< errorMVP.getRelativeL2Norm() <<"\n";
        std::cout << " Inf = "<< errorMVP.getRelativeInfNorm() <<"\n";

        // Compute reduced error in Frobenius Norm
        FReal theo_energy2 = 0.;
        for ( FSize i=0; i<rank; ++i) 
            theo_energy2 += Sigma[i]*Sigma[i];
        FReal theo_residual_energy2 = 0.;
        for ( FSize i=rank; i<sizeGrid; ++i) 
            theo_residual_energy2 += Sigma[i]*Sigma[i];
        FReal theo_residual_energy = FMath::Sqrt(theo_residual_energy2);
        FReal theo_full_energy2 = theo_energy2 + theo_residual_energy2;
        //std::cout << " Verify that 0 = full_energy2 - theo_full_energy2 = "
        //          << errorC_Frob.getReferenceNorm2() - theo_full_energy2 <<"\n";

        // The 2 following are identical
        // However the first one only requires evaluation of the kernel 
        // the second the SVD of the covariance matrix
        FReal residual_energy_svd = FMath::Sqrt(theo_full_energy2 - energy2);
        //FReal residual_energy_def = FMath::Sqrt(errorC_Frob.getReferenceNorm2() - energy2); 
        ////////////////////////////////////////////////////////////////////////////
        //// TO Investigate
        //std::cout << " theo residual energy = \sum_{j>rank}\s_j(C)^2 = "<< theo_residual_energy <<" (Frobenius estimator order)\n";
        //std::cout << " appr residual energy = (|C|^2-|Ck|^2)^{1/2} = "<< residual_energy_svd <<" (Frobenius estimator order APPROXIMATION)\n";
        //// residual energy (i.e. |C|^2-|Ck|^2 where |C| is obtained by SVD or using the entrywise definition) is very close to exact error, but Why?
        //std::cout << " (|C|^2_SVD-|Ck|^2) - |C-Ck|^2 = "<< (theo_full_energy2 - energy2) - errorC_Frob.getNorm()*errorC_Frob.getNorm() <<" (Should not a priori be equal to 0 but in fact very close, WHY?!)\n";
        //std::cout << " (|C|^2_DEF-|Ck|^2) - |C-Ck|^2 = "<< (errorC_Frob.getReferenceNorm2() - energy2) - errorC_Frob.getNorm()*errorC_Frob.getNorm() <<" (Should not a priori be equal to 0 but in fact very close, WHY?!)\n";
        ////////////////////////////////////////////////////////////////////////////

        FReal estimator_order_Frob = theo_residual_energy;
        FReal estimator_order_approx_Frob = residual_energy_svd;

        std::cout << "estimator_order_Frob = " << estimator_order_Frob << std::endl;
        std::cout << "estimator_order_approx_Frob = " << estimator_order_approx_Frob << std::endl;

        FReal reduced_errorC_Frob = errorC_Frob.getNorm() / estimator_order_Frob;

        // Compute estimator in Frobenius Norm
        FReal upperAverageBoundFrobenius = ErrorEstimators<FReal>::upperAverageBoundFrobenius(qRSI,rank,oversampling);

        // Compare energy of approximation and total energy of C
        std::cout << "\n(Total energy of C  )^2 = " << theo_full_energy2 << std::endl;
        std::cout << "(Total energy of C_k)^2 = " << energy2 << std::endl;
        std::cout << "@energy_fraction = " << FMath::Abs(FMath::Sqrt(theo_full_energy2)-FMath::Sqrt(energy2))/FMath::Sqrt(theo_full_energy2)  << std::endl;


        // Compute error in Spectral norm (requires NxN SVD...)
        std::cout << "\nError ||C - (QU)S(QU)^t||_S\n";
        for ( FSize i=0; i<sizeGrid; ++i) 
            for ( FSize j=0; j<sizeGrid; ++j)
                C_approx[i*sizeGrid+j]-=C[i*sizeGrid+j];
        errorC_Spec = MatrixNorms<FReal>::computeSpectral(sizeGrid,C_approx);
        errorC_SpecRel = errorC_Spec / Sigma[0]; 
        std::cout << " Spec  = "<< errorC_Spec <<"\n";
        std::cout << " SpecRel  = "<< errorC_SpecRel <<"\n";

        // Compute reduced error in Spectral Norm
        FReal estimator_order_Spec = Sigma[rank];
        std::cout << "estimator_order_Spec = " << estimator_order_Spec << std::endl;
        std::cout << "estimator_order_approx_Spec = " << estimator_order_approx_Spec << std::endl;

        FReal reduced_errorC_Spec = errorC_Spec / estimator_order_Spec;

        // Compute estimator in Spectral Norm
        FReal factorSpec; 
        if(qRSI){
            // bound if spectrum cte after k
            //factorSpec = FMath::Sqrt(sizeGrid-rank); 
            // exact bound
            factorSpec = estimator_order_Frob/estimator_order_Spec; 
        }
        else{
            FReal estimator_order_Frob_B2 = 0.;
            for ( FSize i=rank; i<sizeGrid; ++i) 
                estimator_order_Frob_B2 += FMath::pow(Sigma[i],FReal(2*(2*qRSI+1)));
            factorSpec = FMath::Sqrt(estimator_order_Frob_B2)/FMath::pow(estimator_order_Spec,FReal(2*qRSI+1));
        }
        FReal upperAverageBoundSpectral = ErrorEstimators<FReal>::upperAverageBoundSpectral(qRSI,rank,oversampling,factorSpec);

        /// Display infos on error estimation
        std::cout << "\nA few infos on error estimation: \n";
        std::cout << "@lowerAverageBoundFrobenius = "<< estimator_order_Frob <<"\n";

        std::cout << "@lowerAverageBoundFrobeniusRel = "<< estimator_order_Frob/FMath::Sqrt(errorC_Frob.getReferenceNorm2()) <<"\n";
        std::cout << "@reduced_errorC_Frob = "<< reduced_errorC_Frob - FReal(1.) <<"\n";
        std::cout << "@reduced_upperAverageBoundFrobenius = "<< upperAverageBoundFrobenius <<"\n";
        std::cout << "@lowerAverageBoundSpectral = "<< estimator_order_Spec <<"\n";
        std::cout << "@lowerAverageBoundSpectralRel = "<< estimator_order_Spec/Sigma[0] <<"\n";

        std::cout << "@reduced_errorC_Spec = "<< reduced_errorC_Spec - FReal(1.) <<"\n";
        std::cout << "@reduced_upperAverageBoundSpectral = "<< upperAverageBoundSpectral <<"\n";

        std::cout << "\n@errorMVP_L2  = "<< errorMVP.getRelativeL2Norm() <<"\n";
        std::cout << "@errorMVP_Inf = "<< errorMVP.getRelativeInfNorm() <<"\n";


        delete [] C_approx;

    }
    else{

        // DO NOTHING! Exact error should only be computed if C is assembled!

    }

    double tApprox = timeApprox.tacAndElapsed();
    std::cout << "... took @tApprox = " << tApprox <<"\n";

    std::cout << "\nA few parameters and performances (of the RandSVD): \n";
    std::cout << "@errorC_Frob = "<< errorC_Frob.getNorm() <<"\n";
    std::cout << "@errorC_FrobRel = "<< errorC_Frob.getRelativeNorm() <<"\n";
    std::cout << "@errorC_Spec = "<< errorC_Spec <<"\n";
    std::cout << "@errorC_SpecRel = "<< errorC_SpecRel <<"\n";
    std::cout << "@tApprox = "<< tApprox <<"\n";

    }// end verifyRSVD

    /// Display results and perfs
    std::cout << "\nA few parameters and performances (of the RandSVD): \n";
    std::cout << "@tInitRSVD = "<< tInitRSVD <<"\n";
    std::cout << "@tRSVD = "<< tRSVD <<"\n";
    std::cout << "@size = "<< sizeGrid <<"\n";
    std::cout << "@rank = "<< rank <<"\n";


  /// Free memory
  delete[] U;
  delete[] C;
  delete[] Sigma;

  return 0;
}
