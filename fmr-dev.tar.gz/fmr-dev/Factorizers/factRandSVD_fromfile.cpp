
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FMemUtils.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"
#include "Utils/FParameterNames.hpp"

// not mandatory but useful to define some flags
#include "Core/FFmmAlgorithm.hpp"
#include "Core/FFmmAlgorithmThread.hpp"

// ... for FMM
#include "Kernels/Interpolation/FInterpMatrixKernel.hpp" // Otherwise KERNEL_FUNCTION_TYPE not declared in M2L handler

// FMR includes
#include "Definition/FMRDefines.hpp"
#include "Correlations/CorrelationKernels.hpp"
#include "StandardLRA/SVD.hpp"
#include "StandardLRA/fullSVD.hpp"
#include "StandardLRA/QRD.hpp"
#include "RandomizedLRA/AdaptiveRandomizedRangeFinder.hpp"
#include "RandomizedLRA/RandomizedRangeFinder.hpp"
#include "RandomizedLRA/RandSVD.hpp"
#include "Utils/MatrixNorms.hpp"
#include "Utils/ErrorEstimators.hpp"
#include "Utils/MatrixIO.hpp" // In order to read covariance matrix from file

#include "MatrixWrappers/DenseWrapper.hpp"


/**
* In this file we load a (spd) matrix from a file. Then we compute the (approximate) eigenvalues and eigenvectors of C using a randomized SVD.
* Covariance file can be generated using factRandSVD.cpp or [TODO] testReadGridAndWriteCovariance.cpp. 
* This test works with any covariance matrix! Not necessarily associated with spatial grid.
* The randomized algorithm is powered by dense MMPs ONLY! C is explicitely build, since it is read from file.
* 
* Author: Pierre Blanchard (pierre.blanchard@inria.fr)
* Date created: April 9th, 2015 
*/


int main(int argc, char* argv[])
{
	std::cout << "Factorize a matrix loaded from file using a randomized SVD." << std::endl;

    ////////////////////////////////////////////////////////////////////
    /// Input file

    // input matrix filename
    const std::string matrixName(FParameters::getStr(argc,argv,"-mat", "unitSphere2000_G50"));
    const std::string matrixPath = FParameters::getStr(argc,argv,"-pmat", std::string("../Data/Matrices/" + matrixName).c_str());
    const std::string matrixfilename = FParameters::getStr(argc,argv,"-fmat", std::string(matrixPath + ".bin").c_str());

    ////////////////////////////////////////////////////////////////////
    /// Read covariance matrix C 
    std::cout<< "Read covariance matrix C from file: " ;

    // Display name
    std::cout<< matrixfilename << "\n";

    // Declare C
    FReal *C = nullptr;

    std::cout<< "Assemble covariance matrix C: " ;
  
    // Read matrix from binary file
    FSize nbRows, nbCols; nbRows=nbCols=0;
    MatrixIO::read(nbRows,nbCols,C,matrixfilename);
    std::cout<< "nbRows=" << nbRows << std::endl  ;
    std::cout<< "nbCols=" << nbCols << std::endl  ;
    FAssertLF(nbRows==nbCols); // specific to this example

    ////////////////////////////////////////////////////////////////////
    /// Timers
    FTic time;
    time.tic();

    ////////////////////////////////////////////////////////////////////
    /// Parameters

    // Verbose (print matrices)
    const int verbose = FParameters::getValue(argc, argv, "-v", 0);
    const FSize displaySize = 10;
    std::cout<< "Verbose level: " << verbose <<std::endl;
    // size of the grid
    const FSize sizeGrid = nbRows;
    std::cout<< "Full rank: " << sizeGrid <<std::endl;
    // randomized range finder (0: fixed accuracy; 1: fixed rank)
    const int flag_RRF = FParameters::getValue(argc, argv, "-fRRF", 1);
    // prescribed rank
    const FSize prescribed_rank = FParameters::getValue(argc, argv, "-pr", sizeGrid/10);
    const int oversampling = FParameters::getValue(argc, argv, "-os", 5);
    const int qRSI = FParameters::getValue(argc, argv, "-q", 0);
    // prescribed accuracy and balance parameter
    const int eARRF = FParameters::getValue(argc, argv, "-pe", 6); 
    const int bARRF = FParameters::getValue(argc, argv, "-b", 10);
    const FSize adaptive_rank = FParameters::getValue(argc, argv, "-rmax", sizeGrid/10); // DO NOT CONSIDER compression rates below 10%!
    // fast variant of RRF algo (0: blas, 1: fmm, 2: todo)
    const int flag_MMP = 0; //< Force dense MMP, since this test could be used for an arbitrary covariance matrix (ie, no explicit formula)
    // Indicate if MVP should be verified during RandSVD algo
    const bool verifyMMP = FParameters::getValue(argc, argv, "-verifyMMP", true);
    // Use a precomputed Gaussian random matrix (for purpose of comparison of FMM and STD RandSVD)
    const bool readW = false;
    // Verify RSVD outputs (namely approximation of matrix C)
    const bool verifyRSVD = FParameters::getValue(argc, argv, "-verifyRSVD", true);

    // Display parameters
    if(flag_RRF==0) {
        std::cout<< "Rank: not known a priori!" <<std::endl;
        std::cout<< "Adaptive parameters: balance=" << bARRF 
                 << " - accuracy=1.e-" << eARRF <<std::endl;
        std::cout<< "Nb of power iterations: " << qRSI <<std::endl;
    }
    else {
        std::cout<< "Prescribed rank: " << prescribed_rank <<std::endl;
        std::cout<< "Oversampling: " << oversampling <<std::endl;
        if((prescribed_rank+oversampling)>sizeGrid) 
            throw std::runtime_error("Oversampled rank should be lower than full rank!");
        std::cout<< "Nb of subspace iterations: " << qRSI <<std::endl;
    }
    std::cout<< "Application of C: Dense (BLAS::gemm())" <<std::endl;

    // display C
    std::setprecision(15);
    if(verbose){
        Display::matrix(sizeGrid,sizeGrid,C,"C",displaySize);
    }

    ////////////////////////////////////////////////////////////////////
    /// Compute and store exact singular values

    // Declare C
    FReal *Sigma = nullptr;

    // Declare SV output filename
    std::string svfilename = matrixPath + "-sv";

    if(verifyRSVD)
    {

        fullSVD<FReal>::ReadIfExists_ComputeAndWriteOtherwise(sizeGrid,sizeGrid,C,Sigma,svfilename,true/*Matrix C is ALWAYS symmetric in this test*/);

        // Check positivity ?
        std::cout << "C is non-negative? ";
        bool isNonNeg=true;
        for(FSize i = 0 ; i<sizeGrid ; ++i)
            if(Sigma[i]<-1e-14) isNonNeg=false;
        if(isNonNeg) std::cout << "YES." << std::endl;
        else std::cout << "NO, C has negative singular values!" << std::endl;

    }// end verifyRSVD
  


    ////////////////////////////////////////////////////////////////////
    /// Init FMR components for factorization of C

    // Dense Matrix Wrapper
    typedef DenseWrapper<FReal> DenseWrapperClass;

    // Fixed rank RRF
    typedef AdaptiveRRF<FReal,DenseWrapperClass> Dense_ARRFClass;
    // Fixed accuracy RRF (or Adaptive RRF)
    typedef RRF<FReal,DenseWrapperClass> Dense_RRFClass;

    ////////////////////////////////////////////////////////////////////
    /// Compute FACTORIZATION using randomized routine

    // Declare square root and rank 
    FReal* U = NULL; 
    FSize rank = 0;
    FReal* ApproxSingularValues=NULL;
    //
    FReal energy2 = 0.;
    FReal estimator_order_approx_Spec = 1.;
    FTic timeRandSVD, timeInitRandSVD;
    double tRSVD,tInitRSVD;
    {
        std::cout << "\nInit Randomized SVD ... \n";
        timeInitRandSVD.tic();
        //
        // Init RRF algorithm
        if(flag_RRF==0 && flag_MMP<2) { // Adaptive Randomized Range Finder + Dense MMPs
            // Dense Wrapper
            DenseWrapperClass* DenseMatrixWrapper = new DenseWrapperClass(sizeGrid,sizeGrid,true/*Matrix C is ALWAYS symmetric in this test*/);
            DenseMatrixWrapper->init(C);
            // Adaptive RRF
            Dense_ARRFClass AdaptRandRangeFinder(DenseMatrixWrapper,eARRF,bARRF,adaptive_rank,qRSI,verifyMMP); 
            //
            tInitRSVD = timeInitRandSVD.tacAndElapsed();
            std::cout << "... took @tInitRSVD = "<< tInitRSVD <<"\n";
            //
            std::cout << "\nPerform Randomized SVD ... ";
            timeRandSVD.tic();
            // RandSVD
            RandSVD<FReal,Dense_ARRFClass> RSVD(sizeGrid,sizeGrid,&AdaptRandRangeFinder);
            rank = RSVD.computeFACT(readW);
            // Get approx. singular values
            ApproxSingularValues = new FReal[rank];
            FBlas::copy(int(rank),RSVD.getApproxSingularValues(),ApproxSingularValues);
            // Get approx. singular vectors
            U = new FReal[sizeGrid*rank];
            FBlas::copy(int(sizeGrid*rank),RSVD.getApproxU(),U);
            // Get some parameters
            energy2=RSVD.getEnergy2(); estimator_order_approx_Spec=RSVD.getApproxBaselineSpec();
        }
        else if(flag_RRF==1 && flag_MMP<2) { // Classic Randomized Range Finder + Dense MMPs
            // Dense Wrapper
            DenseWrapperClass* DenseMatrixWrapper = new DenseWrapperClass(sizeGrid,sizeGrid,true/*Matrix C is ALWAYS symmetric in this test*/);
            DenseMatrixWrapper->init(C);
            // RRF
            Dense_RRFClass RandRangeFinder(DenseMatrixWrapper,prescribed_rank,oversampling,qRSI,verifyMMP);
            tInitRSVD = timeInitRandSVD.tacAndElapsed();
            std::cout << "... took @tInitRSVD = "<< tInitRSVD <<"\n";
            //
            std::cout << "\nPerform Randomized SVD ... ";
            timeRandSVD.tic();
            // RandSVD
            RandSVD<FReal,Dense_RRFClass> RSVD(sizeGrid,sizeGrid,&RandRangeFinder);
            rank = RSVD.computeFACT(readW);
            // Get approx. singular values
            ApproxSingularValues = new FReal[rank];
            FBlas::copy(int(rank),RSVD.getApproxSingularValues(),ApproxSingularValues);
            // Get approx. singular vectors
            U = new FReal[sizeGrid*rank];
            FBlas::copy(int(sizeGrid*rank),RSVD.getApproxU(),U);
            // Get some parameters
            energy2=RSVD.getEnergy2(); estimator_order_approx_Spec=RSVD.getApproxBaselineSpec();
        }
        else {throw std::runtime_error("Wrong combination of flags (flag_RRF && flag_MMP)!");}
        tRSVD = timeRandSVD.tacAndElapsed();
        std::cout << "... took @tRSVD = "<< tRSVD <<"\n";
    }

    ////////////////////////////////////////////////////////////////////
    /// Show eigen values and vectors & store them in binary file    
    std::cout << "ApproxSingularValues=[" <<"\n";
    for(FSize r = 0 ; r<rank ; ++r){
        std::cout << ApproxSingularValues[r] <<", ";
    }
    std::cout << "]" <<"\n";

    if(verifyRSVD)
    {
    ////////////////////////////////////////////////////////////////////
    /// Verify that C ~ Q(Q^tCQ)Q^t = QQ^t(C)QQ^t
    std::cout << "\nVerify approximation of C... \n";
    FTic timeApprox;
    timeApprox.tic();
    FrobeniusError<FReal> errorC_Frob;
    FReal errorC_Spec, errorC_SpecRel;

    /// Compute and display errors

    // Form C_approx = USU^t
    FReal *const C_approx = new FReal [sizeGrid*sizeGrid];

    // Copy U in US
    FReal *const US = new FReal [sizeGrid*rank];
    is_int(sizeGrid*rank);
    FBlas::copy(int(sizeGrid*rank),U,US);

    // Form US=U x S
    is_int(sizeGrid);
    for ( FSize j=0; j<rank; ++j) 
        FBlas::scal(int(sizeGrid),ApproxSingularValues[j],US+j*sizeGrid);

    // Form USUt=US x Ut
    is_int(sizeGrid); is_int(rank); 
    FBlas::gemmt(int(sizeGrid),int(rank),int(sizeGrid),FReal(1.),
               US,int(sizeGrid),U,int(sizeGrid),C_approx,int(sizeGrid));

    delete [] US;

    // display C_approx
    if(verbose){
        std::cout<<"\nC_approx=["<<std::endl;
        for ( FSize i=0; i<sizeGrid/10; ++i) {
            for ( FSize j=0; j<sizeGrid/10; ++j)
                std::cout << C_approx[i*sizeGrid+j] << " ";
            std::cout<< std::endl;
        }
        std::cout<<"]"<<std::endl;
    }

    // C - (QU)S(QU)^t
    std::cout << "Error ||C - (QU)S(QU)^t||_F\n";
    // Compute error in Frobenius norm
    for ( FSize i=0; i<sizeGrid; ++i) 
        for ( FSize j=0; j<sizeGrid; ++j)
            errorC_Frob.addRel(C[i*sizeGrid+j],C_approx[i*sizeGrid+j]);
    std::cout << " Frob  = "<< errorC_Frob.getNorm() <<"\n";
    std::cout << " FrobRel  = "<< errorC_Frob.getRelativeNorm() <<"\n";

    // Compute error on a matrix vector product  || (QU)S(QU)^tX - CX ||
    FReal* pV = new FReal[sizeGrid];
    for ( FSize i=0; i<sizeGrid; ++i) pV[i] = FReal(1.0);
    // Applying C^{1/2} to UX
    FReal* Prandlr = new FReal[sizeGrid];      
    is_int(sizeGrid); is_int(rank); 
    FBlas::gemv(int(sizeGrid),int(rank),FReal(1.),C_approx,pV,Prandlr);
    // Init potential for direct calculation
    FReal* Pdirect = new FReal[sizeGrid]; 
    FBlas::gemv(int(sizeGrid),int(rank),FReal(1.),C,pV,Pdirect);
    // Compute error 
    std::cout << "Error ||CX - (QU)S(QU)^tX||_L2/Inf\n";
    FMath::FAccurater<FReal> errorMVP;
    for ( FSize i=0; i<sizeGrid; ++i) 
      errorMVP.add(Pdirect[i],Prandlr[i]);
    std::cout << " L2  = "<< errorMVP.getRelativeL2Norm() <<"\n";
    std::cout << " Inf = "<< errorMVP.getRelativeInfNorm() <<"\n";

    // Compute reduced error in Frobenius Norm
    FReal theo_energy2 = 0.;
    for ( FSize i=0; i<rank; ++i) 
        theo_energy2 += Sigma[i]*Sigma[i];
    FReal theo_residual_energy2 = 0.;
    for ( FSize i=rank; i<sizeGrid; ++i) 
        theo_residual_energy2 += Sigma[i]*Sigma[i];
    FReal theo_residual_energy = FMath::Sqrt(theo_residual_energy2);
    FReal theo_full_energy2 = theo_energy2 + theo_residual_energy2;
    //std::cout << " Verify that 0 = full_energy2 - theo_full_energy2 = "
    //          << errorC_Frob.getReferenceNorm2() - theo_full_energy2 <<"\n";

    // The 2 following are identical
    // However the first one only requires evaluation of the kernel 
    // the second the SVD of the covariance matrix
    FReal residual_energy_svd = FMath::Sqrt(theo_full_energy2 - energy2);
    //FReal residual_energy_def = FMath::Sqrt(errorC_Frob.getReferenceNorm2() - energy2); 
    ////////////////////////////////////////////////////////////////////////////
    //// TO Investigate
    //std::cout << " theo residual energy = \sum_{j>rank}\s_j(C)^2 = "<< theo_residual_energy <<" (Frobenius estimator order)\n";
    //std::cout << " appr residual energy = (|C|^2-|Ck|^2)^{1/2} = "<< residual_energy_svd <<" (Frobenius estimator order APPROXIMATION)\n";
    //// residual energy (i.e. |C|^2-|Ck|^2 where |C| is obtained by SVD or using the entrywise definition) is very close to exact error, but Why?
    //std::cout << " (|C|^2_SVD-|Ck|^2) - |C-Ck|^2 = "<< (theo_full_energy2 - energy2) - errorC_Frob.getNorm()*errorC_Frob.getNorm() <<" (Should not a priori be equal to 0 but in fact very close, WHY?!)\n";
    //std::cout << " (|C|^2_DEF-|Ck|^2) - |C-Ck|^2 = "<< (errorC_Frob.getReferenceNorm2() - energy2) - errorC_Frob.getNorm()*errorC_Frob.getNorm() <<" (Should not a priori be equal to 0 but in fact very close, WHY?!)\n";
    ////////////////////////////////////////////////////////////////////////////

    FReal estimator_order_Frob = theo_residual_energy;
    FReal estimator_order_approx_Frob = residual_energy_svd;

    std::cout << "estimator_order_Frob = " << estimator_order_Frob << std::endl;
    std::cout << "estimator_order_approx_Frob = " << estimator_order_approx_Frob << std::endl;

    FReal reduced_errorC_Frob = errorC_Frob.getNorm() / estimator_order_Frob;

    // Compute estimator in Frobenius Norm
    FReal upperAverageBoundFrobenius = ErrorEstimators<FReal>::upperAverageBoundFrobenius(qRSI,rank,oversampling);

    // Compare energy of approximation and total energy of C
    std::cout << "\n(Total energy of C  )^2 = " << theo_full_energy2 << std::endl;
    std::cout << "(Total energy of C_k)^2 = " << energy2 << std::endl;
    std::cout << "@energy_fraction = " << FMath::Abs(FMath::Sqrt(theo_full_energy2)-FMath::Sqrt(energy2))/FMath::Sqrt(theo_full_energy2)  << std::endl;


    // Compute error in Spectral norm (requires NxN SVD...)
    std::cout << "\nError ||C - (QU)S(QU)^t||_S\n";
    for ( FSize i=0; i<sizeGrid; ++i) 
        for ( FSize j=0; j<sizeGrid; ++j)
            C_approx[i*sizeGrid+j]-=C[i*sizeGrid+j];
    errorC_Spec = MatrixNorms<FReal>::computeSpectral(sizeGrid,C_approx);
    errorC_SpecRel = errorC_Spec / Sigma[0]; 
    std::cout << " Spec  = "<< errorC_Spec <<"\n";
    std::cout << " SpecRel  = "<< errorC_SpecRel <<"\n";

    // Compute reduced error in Spectral Norm
    FReal estimator_order_Spec = Sigma[rank];
    std::cout << "estimator_order_Spec = " << estimator_order_Spec << std::endl;
    std::cout << "estimator_order_approx_Spec = " << estimator_order_approx_Spec << std::endl;

    FReal reduced_errorC_Spec = errorC_Spec / estimator_order_Spec;

    // Compute estimator in Spectral Norm
    FReal factorSpec; 
    if(qRSI){
        // bound if spectrum cte after k
        //factorSpec = FMath::Sqrt(sizeGrid-rank); 
        // exact bound
        factorSpec = estimator_order_Frob/estimator_order_Spec; 
    }
    else{
        FReal estimator_order_Frob_B2 = 0.;
        for ( FSize i=rank; i<sizeGrid; ++i) 
            estimator_order_Frob_B2 += FMath::pow(Sigma[i],FReal(2*(2*qRSI+1)));
        factorSpec = FMath::Sqrt(estimator_order_Frob_B2)/FMath::pow(estimator_order_Spec,FReal(2*qRSI+1));
    }
    FReal upperAverageBoundSpectral = ErrorEstimators<FReal>::upperAverageBoundSpectral(qRSI,rank,oversampling,factorSpec);

    /// Display infos on error estimation
    std::cout << "\nA few infos on error estimation: \n";
    std::cout << "@lowerAverageBoundFrobenius = "<< estimator_order_Frob <<"\n";

    std::cout << "@lowerAverageBoundFrobeniusRel = "<< estimator_order_Frob/FMath::Sqrt(errorC_Frob.getReferenceNorm2()) <<"\n";
    std::cout << "@reduced_errorC_Frob = "<< reduced_errorC_Frob - FReal(1.) <<"\n";
    std::cout << "@reduced_upperAverageBoundFrobenius = "<< upperAverageBoundFrobenius <<"\n";
    std::cout << "@lowerAverageBoundSpectral = "<< estimator_order_Spec <<"\n";
    std::cout << "@lowerAverageBoundSpectralRel = "<< estimator_order_Spec/Sigma[0] <<"\n";

    std::cout << "@reduced_errorC_Spec = "<< reduced_errorC_Spec - FReal(1.) <<"\n";
    std::cout << "@reduced_upperAverageBoundSpectral = "<< upperAverageBoundSpectral <<"\n";

    std::cout << "\n@errorMVP_L2  = "<< errorMVP.getRelativeL2Norm() <<"\n";
    std::cout << "@errorMVP_Inf = "<< errorMVP.getRelativeInfNorm() <<"\n";


    delete [] C_approx;

    double tApprox = timeApprox.tacAndElapsed();
    std::cout << "... took @tApprox = " << tApprox <<"\n";

    std::cout << "@errorC_Frob = "<< errorC_Frob.getNorm() <<"\n";
    std::cout << "@errorC_FrobRel = "<< errorC_Frob.getRelativeNorm() <<"\n";
    std::cout << "@errorC_Spec = "<< errorC_Spec <<"\n";
    std::cout << "@errorC_SpecRel = "<< errorC_SpecRel <<"\n";
    std::cout << "@tApprox = "<< tApprox <<"\n";

    }// end verifyRSVD

    /// Display results and perfs
    std::cout << "\nA few parameters and performances (of the RandSVD): \n";
    std::cout << "@tInitRSVD = "<< tInitRSVD <<"\n";
    std::cout << "@tRSVD = "<< tRSVD <<"\n";

    /// Free memory
    delete[] U;
    delete[] C;
    delete[] Sigma;

    return 0;
}
