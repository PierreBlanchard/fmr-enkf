
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator
#include <algorithm> // for max_element


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FMemUtils.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"
#include "Utils/FParameterNames.hpp"

// not mandatory but useful to define some flags
#include "Core/FFmmAlgorithm.hpp"
#include "Core/FFmmAlgorithmThread.hpp"

// FMR includes
#include "Definition/FACTDefines.hpp"
#include "Correlations/CorrelationKernels.hpp"
#include "Utils/MatrixNorms.hpp"
#include "Utils/ErrorEstimators.hpp"
#include "Utils/MatrixIO.hpp" // In order to read covariance matrix from file
#include "Utils/Display.hpp" // In order to display vectors and arrays

// ... for FMM
#include "Definition/ScalFMMDefines.hpp"

/**.
*
* Author: Pierre Blanchard (pierre.blanchard@inria.fr)
* Date created: August 16th, 2015 
*/


int main(int argc, char* argv[])
{
	std::cout << "FACT: Read from .txt (or .dat) file and convert to binary file in order to compress and accelerate reading (in programs like factRandSVD_fromfile.cpp)." << std::endl;
    ////////////////////////////////////////////////////////////////////
    /// Command lines:
    //
    // Example:
    // ./Factorizers/Release/factConvertTxtToBin -v 2 -mat snapshots -nrows 10 -ncols 5501
    // ./Factorizers/Release/factConvertTxtToBin -v 2 -ipmat ../Data/Matrices/Covariance/ -pmat ../Data/Matrices/Covariance/ -mat unitGrid2000_G50 -nrows 2000 -ncols 2000
    // 
    ////////////////////////////////////////////////////////////////////
    /// Timers 
    FTic time; 
    time.tic();

    ////////////////////////////////////////////////////////////////////
    /// Parameters
    // Verbose (print matrices)
    const int verbose = FParameters::getValue(argc, argv, "-v", 0);
    std::cout<< "Verbose level: " << verbose <<std::endl;
    // Debug mode (if input spl not available or too large to be read on local cmp)
    const int dbg = FParameters::getValue(argc, argv, "-dbg", 0);
    std::cout<< "Debug mode: " << dbg << std::endl;    

    // Input/Output path (to directory containing samples themselves containing a big_matrix directory)
    const std::string inMatrixPath = FParameters::getStr(argc,argv,"-ipmat", std::string("../Data/Matrices/POD/").c_str());
    const std::string outMatrixPath = FParameters::getStr(argc,argv,"-pmat", std::string("../Data/Matrices/POD/").c_str());

    // Input sample
    const std::string inMatrixName = FParameters::getStr(argc,argv,"-mat", std::string("snapshots").c_str());

    ////////////////////////////////////////////////////////////////////
    /// Input file

//    for ( FSize blockIdx=0; blockIdx<nbBlockMatrices; ++blockIdx) {
    const FSize nbRows =  FParameters::getValue(argc, argv, "-nrows", 10);
    const FSize nbCols =  FParameters::getValue(argc, argv, "-ncols", 5501);
    
    // input matrix filename
    std::ostringstream oss_nbRows; oss_nbRows << nbRows;
    std::ostringstream oss_nbCols; oss_nbCols << nbCols;
    const std::string inMatrixFileName(FParameters::getStr(argc,argv,"-f", std::string(inMatrixName + "_r" + oss_nbRows.str() + "_c"  + oss_nbCols.str()).c_str())); // if nothing specified then use file associated with n=50
    const std::string matrixfilename = inMatrixPath + inMatrixFileName + ".txt";

    // Read D
    std::cout<< "Read distance matrix D from file: " ;
    FTic timeReadM;
    double tReadM;
    timeReadM.tic();
    // Display name
    std::cout<< matrixfilename << "\n";

    // Declare M: Matrix to factorize
    FReal *M = new FReal[nbRows*nbCols];

    // Read matrix from text file ...
    FSize tNbRows = nbRows;
    FSize tNbCols = nbCols;  

    MatrixIO::readCSV(tNbRows,tNbCols,M,matrixfilename,' ');

    std::cout<< "Nb rows: " << tNbRows <<std::endl;
    std::cout<< "Nb cols: " << tNbCols <<std::endl;
    std::cout<< "Memory: " << double(sizeof(FReal) * tNbRows * tNbCols) *double(1.e-6) << " MBytes" <<std::endl;

    FAssertLF(tNbRows==nbRows);
    FAssertLF(tNbCols==nbCols);

    tReadM = timeReadM.tacAndElapsed();
    std::cout << "... took @tReadM = "<< tReadM <<"\n";

    // Display M
    const FSize displaySize = 5;
    std::setprecision(15);
    if(verbose==2){
        Display::matrix(nbRows,nbCols,M,"M",displaySize);
    }
    
    ////////////////////////////////////////////////////////////////////
    /// Output file

    // Precision
    if(sizeof(FReal)==4) std::cout<< "Precision: Single Float" <<std::endl;
    else if(sizeof(FReal)==8) std::cout<< "Precision: Double Float (For the sake of memory, please work with SINGLE floats!)" <<std::endl;
    else throw std::runtime_error("Wrong datatype!");

    // binary file name
    const std::string binaryfilename = outMatrixPath + inMatrixFileName + ".bin";

    // Write in binary file
    std::cout<< "Write matrix M to binary file: " ;
    FTic timeWriteM;
    double tWriteM;
    timeWriteM.tic();
    // Display name
    std::cout<< binaryfilename << "\n";
    
    MatrixIO::write(nbRows,nbCols,M,binaryfilename);

    tWriteM = timeWriteM.tacAndElapsed();
    std::cout << "... took @tWriteM = "<< tWriteM <<"\n";

    ////////////////////////////////////////////////////////////////////
    /// Verification
    FReal *Mread = NULL;

    // Read from binary file
    std::cout<< "Verify binary file: " ;
    FTic timeVerif;
    double tVerif;
    timeVerif.tic();

    tNbRows = nbRows;
    tNbCols = nbCols;  

    MatrixIO::read(tNbRows,tNbCols,Mread,binaryfilename);

    FAssertLF(tNbRows==nbRows);
    FAssertLF(tNbCols==nbCols);

    tVerif = timeVerif.tacAndElapsed();
    std::cout << "... took @tVerif = "<< tVerif <<"\n";

    // Display D
    if(verbose==2){
        Display::matrix(nbRows,nbCols,Mread,"Mread",displaySize);
    }

    /// Compute error
    FrobeniusError<FReal> errorFrob;
    // D_read - D
    std::cout << "Error ||M_read - M||_F\n";
    // Compute error in Frobenius norm
    for ( FSize i=0; i<nbRows; ++i) 
        for ( FSize j=0; j<nbCols; ++j)
            errorFrob.addRel(FReal(Mread[i+j*nbRows]),FReal(M[i+j*nbRows]));
    std::cout << " Frob  = "<< errorFrob.getNorm() <<"\n";
    std::cout << " FrobRel  = "<< errorFrob.getRelativeNorm() <<"\n";

    /// Free memory
    delete[] M;
    delete[] Mread;

    return 0;
}
