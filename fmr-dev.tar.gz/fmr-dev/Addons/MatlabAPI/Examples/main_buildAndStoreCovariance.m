clear all
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Define global variables and paths used by the interface

% Define FMR's api and home directory 
global fmr_home_directory = [pwd() '/../../../']

% Add all subdirs of FMR to search path
addpath(genpath([fmr_home_directory '/Addons/MatlabAPI']))

% Interface verbose?
global verbose_cpp=true;
global verbose_make=false;

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Description:
%% Octave example
%% This is an example of Gaussian random fields generation 
%% using RandSVD powered by dense MMPs
%% By calling precompiled fmr examples
%% Covariance matrix is either computed and stored
%% or computed just before 

%% TODO
%% Define global parameters (compile options, float precision, ...)
%% 


%% Pierre Blanchard (pierre.blanchard@inria.fr)
%% June, 10th 2016
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Grid (artificial or load from other code)

% Define new grid or read existing grid?
grid_is_new=true;

% Size of the grid
n=2000

%% Grid name and Grid points (artificial or load from other code)

%grid_name='unitSegment'
%grid_points(1,:)=linspace(-1,1,n)*0.0;
%grid_points(2,:)=linspace(-1,1,n);
%grid_points(3,:)=linspace(-1,1,n)*0.0;
%grid_width=1;
%grid_center=[0.,0.,0.];
%grid_is_new=true;

%grid_name='unitGrid'
%grid_points(1,:)=linspace(-1,1,n);
%grid_points(2,:)=linspace(-1,1,n);
%grid_points(3,:)=linspace(-1,1,n);
%grid_width=1;
%grid_center=[0.,0.,0.];
%grid_is_new=true;

% The 'unitSphere' grid was already precomputed in scalfmm (in binary format)
grid_name='unitSphere'
grid_points=zeros(3,1);
grid_width=0.;
grid_center=[0.,0.,0.];
grid_is_new=false;

% Grid structure
gridz = struct('size',n,
                'points',grid_points,
                'name',grid_name,
                'width',grid_width,
                'center',grid_center,
                'directory',[fmr_home_directory '/Addons/MatlabAPI/Data/FMAInputGrids'],
                'filename',[grid_name num2str(n)],
                'binaryformat',true % Set to true if grid stored in binary format
                );

% Grid full filename
if(gridz.binaryformat)
    grid_fileextension='.bfma';
else
    grid_fileextension='.fma';
end%
grid_fullfilename=[gridz.directory '/' gridz.filename grid_fileextension];

gridz.('fullfilename')=grid_fullfilename;

% Write grid in file (need to translate from matlab to scalfmm/fmr format)
% [...]
if(grid_is_new)
    storeGrid(gridz);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Correlation kernel
correlation_name='Gauss'
correlation_length=0.5
% Correlation structure
correlationz = struct('name',correlation_name,
                    'length',correlation_length,
                    'directory',[fmr_home_directory '/Addons/MatlabAPI/Data/Matrices/Covariance'],
                    'filename',[correlation_name(1) num2str(100*correlation_length)]
                    );

%% I/O file names

% covariance matrix file name (in case written in matlab)
%covariance_matrix_filename=['../Data/Matrices/' gridz.filename '_' correlationz.filename]

%% Store covariance matrix?
storeCovariance=true;
if(storeCovariance)

    % covariance matrix file name (in case written in matlab)
    covariance_path=[correlationz.directory '/' gridz.filename '_' correlationz.filename];

    disp('Build and Store covariance in file...')
    buildInMatlab=false; % Turn ON in case correlation is not implemented in C++
    buildAndStoreCovariance(gridz,correlationz,covariance_path,buildInMatlab); % use C++ routine

end%