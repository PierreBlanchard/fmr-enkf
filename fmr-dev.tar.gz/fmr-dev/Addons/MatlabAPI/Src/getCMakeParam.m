
  function val = getCMakeParam(param)
 % Checks the cmake cache and extracts the stored parameter
  

 txt = fileread(fullfile(getPathToFMR,'Build','CMakeCache.txt'));
 if isempty(txt)
   error('Couldn''t find the cmake cache.  Did you run make?');
  end
 tokens = regexp(txt,[param,':\w+=(.*)'],'tokens','dotexceptnewline');
 if isempty(tokens)
   error('Couldn''t find the parameter %s in your cmake cache',param);
 end
 val = tokens{1}{1};


 end