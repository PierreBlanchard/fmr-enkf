
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [output,text] = mySystemCall(commandline)

% Custom system call
% - redirect stderr to stdout
[output, text] = system([commandline ' 2>&1']);

end%