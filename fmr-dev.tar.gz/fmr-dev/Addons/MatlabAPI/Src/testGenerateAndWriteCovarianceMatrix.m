%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description:
% Call testGenerateAndWriteCovarianceMatrix executable.
% Also provide required arguments.
% I/Os:
% [...]
function [] = testGenerateAndWriteCovarianceMatrix(grid_fullfilename,covariance_fullfilename,correlation_length,correlation_name)

global verbose_cpp;
global fmr_home_directory;
fmr_build_directory = [fmr_home_directory '/Build'];
initial_dir = pwd();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Executable
execname='testGenerateAndWriteCovarianceMatrix'

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Input -> arguments

% translate correlation name to id
switch(correlation_name)
case 'Gauss'
	correlation_ID=0;
case 'Expo'
	correlation_ID=1;
end%
args=[' -f ' grid_fullfilename ' -of ' covariance_fullfilename ' -corr ' num2str(correlation_ID) ' -ls ' num2str(100*correlation_length)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Move to build directory
displayCmd(['cd ' fmr_build_directory])
cd(fmr_build_directory)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compile C++ routine
compile_options='-j 2';
[output,text]=makeExecutable(execname,compile_options);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Run C++ executable

% Provide full path to executable is safer 
myCmd = [fmr_build_directory '/Tests/Release/' execname ' ' args ];

% Display command using coloring (works in GUI or CLI (matlab -nodesktop)) 
displayCmd(myCmd);

% Execute command
[output, StdOutErr] = mySystemCall( myCmd );

% Display stdout and sterr using coloring (works in GUI or CLI (matlab -nodesktop)) 
if(verbose_cpp)
	displayStdOut(StdOutErr)
end%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Handle ouputs
%% 
%% No output, since matrix is generated then stored in binary file.
%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Back to initial directory
displayCmd(['cd ' initial_dir])
cd(initial_dir)

end%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%