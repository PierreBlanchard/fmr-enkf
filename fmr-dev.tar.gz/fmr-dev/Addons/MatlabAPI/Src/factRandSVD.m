
% Description:
% Call factRandSVD executable
% Also provide required arguments.
% I/Os:
% [...]
function [U,S,V] = factRandSVD(n, r, p, q, rank_is_fixed, correlation_length, correlation_name, grid_filename)

global verbose_cpp;
global fmr_home_directory;
fmr_build_directory = [fmr_home_directory '/Build'];
initial_dir = pwd();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Executable name
execname='factRandSVD'

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Input -> arguments

% Grid filename
args=[' -f ' grid_filename];

% Correlation
switch(correlation_name)
case 'Gauss'
	correlation_ID=0
case 'Expo'
	correlation_ID=1
end%
args=[args ' -corr ' num2str(correlation_ID) ' -ls ' num2str(100*correlation_length)];

% Randomized SVD
if(rank_is_fixed)
	args=[args ' -fRRF 1 -pr ' num2str(r) ' -os ' num2str(p) ' -q ' num2str(q) ];
else
	args=[args ' -fRRF 0 -pe ' num2str(r) ' -b ' num2str(p) ' -q ' num2str(q) ];
end%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Move to build directory
disp(['$ cd ' fmr_build_directory])
cd(fmr_build_directory)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compile C++ routine
compile_options='-j 2'
[cmtext,mtext]=makeExecutable(execname,compile_options);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Run RandSVD using C++
disp(['$ ./Factorizers/Release/' execname ' ' args])
disp('...')
[output, text] = mySystemCall(
	['./Factorizers/Release/' execname ' ' args]
);

if(verbose_cpp)
	displayStdOut(text,'blue')
end%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Read output matrices from file
U=V=zeros(n,r);
S=zeros(r);

%% [...]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Back to octave directory
disp(['$ cd ' initial_dir])
cd(initial_dir)

end%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
