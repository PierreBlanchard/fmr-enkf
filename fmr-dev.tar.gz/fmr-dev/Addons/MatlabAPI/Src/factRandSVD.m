
% Description:
% Call factRandSVD executable
% Also provide required arguments.
% I/Os:
% [...]
function [U,S,V] = factRandSVD(n, r, p, q, rank_is_fixed, correlation_length, correlation_name, grid_fullfilename)

global verbose_cpp;
global fmr_home_directory;
fmr_build_directory = [fmr_home_directory '/Build'];
initial_dir = pwd();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Executable name
execname='factRandSVD';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Input -> arguments

% Split full filename
[grid_directory, grid_filename, grid_extension] = fileparts(grid_fullfilename);

% Grid filename
args=[' -d ' grid_filename ' -p2d ' grid_directory '/ '];

% Correlation
switch(correlation_name)
case 'Gauss'
	correlation_ID=0;
case 'Expo'
	correlation_ID=1;
end%
args=[args ' -corr ' num2str(correlation_ID) ' -ls ' num2str(100*correlation_length)];

% Randomized SVD
if(rank_is_fixed)
	args=[args ' -fRRF 1 -pr ' num2str(r) ' -os ' num2str(p) ' -q ' num2str(q) ];
else
	args=[args ' -fRRF 0 -pe ' num2str(r) ' -b ' num2str(p) ' -q ' num2str(q) ];
end%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Move to build directory
displayCmd(['cd ' fmr_build_directory])
cd(fmr_build_directory)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compile C++ routine
compile_options='-j 2';
[cmtext,mtext]=makeExecutable(execname,compile_options);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Run RandSVD using C++

% Provide full path to executable is safer 
myCmd = [fmr_build_directory '/Factorizers/Release/' execname ' ' args ];

% Display command using coloring (works in GUI or CLI (matlab -nodesktop)) 
displayCmd(myCmd);

% Execute command
[output, StdOutErr] = mySystemCall( myCmd );

% Display stdout and sterr using coloring (works in GUI or CLI (matlab -nodesktop)) 
if(verbose_cpp)
	displayStdOut(StdOutErr)
end%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Read output matrices from file
U=zeros(n,r);
V=zeros(n,r);
S=zeros(r);

%% [...]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Back to octave directory
displayCmd(['cd ' initial_dir])
cd(initial_dir)

end%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
