%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = buildAndStoreCovariance(gridz, correlationz, covariance_filename, buildInMatlab)

%% Using Matlab
if(buildInMatlab)

	disp('Using Matlab (Build and store in .txt then convert to .bin in C++)')

	% Build covariance matrix
	n = gridz.size;
	C=zeros(n,n);
	for i = 1:n
		for j = 1:n
		  C(i,j)=evaluateCorrelation(gridz.points(i),gridz.points(j),correlationz.length,correlationz.name);
		end%
	end%

	% Write matrix in .txt file
	% [...]


	% Convert file to binary format
	% [...]


%% Using dedicated C++ routine
else

	disp('Using C++')
	testGenerateAndWriteCovarianceMatrix(gridz.fullfilename, [covariance_filename '.bin'], correlationz.length, correlationz.name);

end%




end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

