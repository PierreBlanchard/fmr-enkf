
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = displayStdOut(text,text_color)


% TODO Download cprintf utility for matlab
%http://www.mathworks.com/matlabcentral/fileexchange/24093-cprintf-display-formatted-colored-text-in-the-command-window

% Use printf trick
set_colors_string=' blue=$(tput setaf 4) && normal=$(tput sgr0)';

%disp([set_colors_string ' && printf "${blue} ' text ' ${normal}" '])

%[output,text]=system([set_colors_string ' && printf "${blue} ' text ' ${normal}" ']);

disp(text)

end%