function root = getPathToFMR()
% Get the FMR root directory
% Useful if you want to do something like reference a file on the
% filesystem in fmr
%
% @retval root path to the root of FMR


persistent myroot;

if (isempty(myroot))
  myroot = fileparts(fileparts(fileparts(fileparts(which('getPathToFMR'))))); % locate this file and take 3rd containing folder
end
root = myroot;