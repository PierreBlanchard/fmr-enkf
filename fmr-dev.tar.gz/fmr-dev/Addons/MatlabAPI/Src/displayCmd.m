
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = displayCmd(text,in_text_type)

if(nargin==1)
	text_type = 'SystemCommands';%default
else
	text_type = in_text_type;
end

% Coloring depend on interface GUI or CLI

if ~usejava('desktop')
    % use CLI

	% Use printf trick
	set_colors_string=' bold=$(tput bold) && blue=$(tput setaf 4) && normal=$(tput sgr0)';

	[output,text]=mySystemCall([set_colors_string ' && printf "${blue} ${bold} $ ' text '\n... ${normal}" ']);
	disp(text)
else
    % use GUI 

	% CPRINTF utility:
	% http://www.mathworks.com/matlabcentral/fileexchange/24093-cprintf-display-formatted-colored-text-in-the-command-window

	cprintf(['*' text_type],['$ ' char(text) '\n...']);
	cprintf('\n'); % apply default style while breaking line


end


end%