%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [] = storeGrid(gridz)

% [TODO] Binary format!!!!!


filename=[gridz.directory '/' gridz.filename '.fma'];

disp(['Write grid in file: ' filename])

fid = fopen(filename, 'wt');

%fprintf(fid, ["# Description: Performances of the algo for HED3D kernel\n"])
%fprintf(fid, ["# using NA" opt_mthd " M2L ops with respect to the interpolation order.\n"])
%fprintf(fid, ["# Unit cube: box" num2str(box) ", Lmax=" num2str(lmax) ", lap=" num2str(lap) "i,\n"])
%fprintf(fid, ["# To be read by PGFPLOT directly in tikz/type/*.tex file.\n\n"]);

fprintf(fid, ['8 4\n']);
fprintf(fid, '%i\n', gridz.size);
fprintf(fid, '%f %f %f %f\n', gridz.width, gridz.center(1), gridz.center(2), gridz.center(3));
for i=1:gridz.size
	fprintf(fid, '%f %f %f %f\n', gridz.points(1,i),  ...
								  gridz.points(2,i),  ...
								  gridz.points(3,i), 0.01); % test rhs vector with cte value
end

fclose(fid);

end%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%