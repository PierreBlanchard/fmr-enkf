function [cmake_text,make_text] = makeExecutable(execname,compile_options)

global verbose_make;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Write makefile
myCmd='cmake ../';
displayCmd(myCmd);
[output, cmake_text] = mySystemCall(myCmd);

if(verbose_make)
	displayStdOut(cmake_text)
end%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compile FMR's RandSVD
myCmd=['make ' execname];
displayCmd(myCmd);
[output, make_text] = mySystemCall(myCmd);

if(verbose_make)
	displayStdOut(make_text)
end%

end%