function [cmake_text,make_text] = makeExecutable(execname,compile_options)

global verbose_make;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Write makefile
disp(['$ cmake ../'])
disp('...')
[output, cmake_text] = mySystemCall(
	['cmake ../ ']
);

if(verbose_make)
	displayStdOut(cmake_text,'red')
end%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compile FMR's RandSVD
disp(['$ make ' execname])
disp('...')
[output, make_text] = mySystemCall(
	['make ' execname]
);

if(verbose_make)
	displayStdOut(make_text,'red')
end%

end%