function [C] = evaluateCorrelation(x, y, l, correlation_function)


switch correlation_function
	case 'Gauss'
	    C=exp(-(abs(x-y)/(2*l))^2); % gaussian decay
	case 'Expo'
		C=exp(-abs(x-y)/l); % exponential  decay
	otherwise
		disp('Invalid correlation_function')
end



end