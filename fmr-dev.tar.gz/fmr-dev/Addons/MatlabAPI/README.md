# Matlab API

Provide all necessary materials for interfacing FMR with Matlab or Octave, i.e. calling FMR funtionnalities from your Matlab program.

###1. INTRODUCTION

####1.1 Why interfacing?

This Matlab/Octave interface is necessary for the users of Matlab/Octave that want to exploits the performance of FMR's features while still using there favorite programming language.

####1.2 How does it work? 

The philosophy of this interface is based on "system calls", which means C++ routines are executed directly via command lines using the Matlab/Octave function
```
system(<command line>)
```

The major **advantage** of this method is that

* makefile are handled by ```cmake```
* compilation is handled by your favorite c++ compiler: ```gcc```, ```icc```, ... 

However, there is a significant **drawback**. In fact, executing C++ from the command line means that 

* input and output data need to be stored on the disk and read from the disk.

This can result in slow ios, therefore the amount of data that is passed from matlab to C++ and the other way around should minimal. 

This philosophy is justified by the nature of the library. Indeed, C++ is specificly used for performing expensive computations (multiplications and factorizations) in a matrix-free approach (if possible). Consequently, the assembly of large matrices should be handled strictly by C++ routines if not completely avoided.

####1.3 Alternatives? 

** Mex ** is an interface system specific to Matlab for calling C++ from Matlab. However it has some major limitations that made its use impossible within FMR. We list them below

* Not compatible with advanced C++ programming (C++11)
* Not compatible with versions of gcc above gcc-4.8 .

Moreover, our interfacing philosophy involves just as little extra code writting as Mex.

** Boost-Python ** Another alternative is to used a python interface such as Boost-Python that is compatible with C++11.

###2. CONTENT

	./Examples           : main files
	./Src                : functions definition
	./Data/              : storage space used by API or Matlab outputs
	./Data/FMAInputGrids : input grids in FMA format (format used by ScalFMM)
	./Data/Matrices/Covariance : covariance matrices (either kernel or experimental covariance) 

###3. GUIDELINES

####3.1 Examples

Currently, ```Examples``` contains 3 Matlab/Octave maibn files:

	./Examples/main_factRandSVD.m             : interface for factorizing a kernel matrix (from a sptail grid)
	./Examples/main_factRandSVD_fromfile.m    : interface for factorizing an arbitrary matrix (stored in file)
	./Examples/main_buildAndStoreCovariance.m : interface for assembling a kernel matrix and storing it in file.

####3.2 Sources

They divide in 2 categories: system calls an standard matlab functions

#####3.2.1 System calls

* **Template** All system calls have the same name as the C++ routine that they interface except that they have a matlab ```.m``` extension. They are based on the same model:
```
function [outputs]=nameOfTheExecutable(input)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Handle global vars and paths
[...]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Executable
[...]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Input -> arguments
[...]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Move to build directory
[...]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compile C++ routine
[...]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Run C++ executable
[...]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Handle ouputs
[...]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Back to octave directory
[...]

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
```

* **List** of all system calls:

	./Src/factRandSVD.m                          : [...]
	./Src/factRandSVD_fromfile.m                 : [...]
	./Src/testGenerateAndWriteCovarianceMatrix.m : [...]


#####3.2.2 Standard Matlab functions

* **Configuration of makefile and compilation of executables** is done using the generic function defined in ```./Src/makeExecutable.m```:

```
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [output,text] = makeExecutable(execname,makefile_options,compile_options)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Write makefile
[...]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compile C++
[...]

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
```

[...]

####3.3 FMA Input Grids

ex:

nb_of_points
bbox_width bbox_center.X bbox_center.Y bbox_center.Z
X_1 Y_1 Z_1 PhysicalValue_1
X_2 Y_2 Z_2 PhysicalValue_2
...
X_n Y_n Z_n PhysicalValue_n
