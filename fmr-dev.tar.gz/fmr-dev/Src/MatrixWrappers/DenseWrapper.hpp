#ifndef DENSEWRAPPER_HPP
#define DENSEWRAPPER_HPP

// standard includes 
#include <stdio.h>
#include <stdlib.h>

// For std::array<> (i.e. for MultiRhs purpose)
//#include <array>

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FBlas.hpp"
#include "Utils/FMath.hpp"
#include "Utils/FTic.hpp"


// FMR includes
#include "Definition/ScalFMMDefines.hpp"

/**
 * @author Pierre Blanchard (pierre.blanchard@inria.fr)
 * @date December 29th, 2015 
 *
 */


/**
 * @brief Dense Wrapper class
 *
 * [TODO] Define wrapper for kernel matrices in different wrapper, eg, KernelWrapper
 * [TODO] Define subsampling in this/each wrapper?
 * 
 */
template<class FReal>
class DenseWrapper {


private:

    // Matrix Dimensions
    const FSize nbRows;
    const FSize nbCols;
    // Symmetric square matrix?
    const bool matrixIsSymmetric;
    // 
    FReal* matrix;

public:

    /*
     * Ctor
     */
    explicit DenseWrapper(const FSize inNbRows, const FSize inNbCols, const FSize inMatrixIsSymmetric = false)
        : nbRows(inNbRows), nbCols(inNbCols), matrixIsSymmetric(inMatrixIsSymmetric), matrix(nullptr)
    {
        // allocate memory for matrix
        matrix = new FReal[nbRows*nbCols];
    }

    /*
     * Copy ctor
     */
    explicit DenseWrapper(const DenseWrapper& other)
        : nbRows(other.nbRows), nbCols(other.nbCols), matrixIsSymmetric(other.matrixIsSymmetric)
    {
        std::cout << "Copy DenseWrapper" << std::endl;
        memcpy(other.matrix,matrix,nbRows*nbCols*sizeof(FReal));

    }

    /*
     * Dtor
     */
    ~DenseWrapper()
    {
        delete [] matrix;
    }

    /*
     * Initialize: Copy matrix!!
     * 
     */
    void init(const FReal* inMatrix) {

        // Copy values from matrix
        FBlas::copy(int(nbRows*nbCols),inMatrix,matrix);

    }

    /*
     * Initialize: Read matrix!!
     * 
     */
    void init(const std::string filename) {

        // Read from file
        FSize tNbRows=nbRows;
        FSize tNbCols=nbCols;
        MatrixIO::read(tNbRows,tNbCols,matrix,filename);
        //
        FAssertLF(nbRows!=tNbRows);
        FAssertLF(nbCols!=tNbCols);

    }

    /*
     * Get wrapper ID
     * 
     */
    int getID() {
        return 1;
    }


    /*
     * Get algorithm timing
     * 
     */
    void getTimes() {
        std::cout << "@tMatMult = " << " TODO " << std::endl;
    }

    /*
     * Get symmetric flag
     * 
     */
    const bool isSymmetric() {
        return matrixIsSymmetric;
    }

    /*
     * multiplyMatrices: This routine performs the product Y=MX where M is the input matrix and W a set of vectors
     */
    void multiplyMatrix(const FSize nbRowsToApply, const FSize nbColsToApply, const FSize rank, FReal* W, FReal* &Y, const bool transposeMatrix = false, const bool applyToTheLeft = false){

        if(!transposeMatrix){
            is_int(nbRowsToApply); is_int(nbColsToApply); is_int(rank);
            FBlas::gemm(int(nbRowsToApply),int(nbColsToApply),int(rank),FReal(1.),
                        matrix,int(nbRows),W,int(nbCols),Y,int(nbRows));            
        }
        else{
            is_int(nbRowsToApply); is_int(nbColsToApply); is_int(rank);
            FBlas::gemtm(int(nbRowsToApply),int(nbColsToApply),int(rank),FReal(1.),
                         matrix,int(nbRows),W,int(nbRows),Y,int(nbCols)); // SURE??
        }
    }

    /*
     * computeError: This routine should not be called because the method is EXACT!
     */
    void computeError(const FSize nbAppliedRows, const FSize nbAppliedCols, const FSize rank, FReal* W, FReal* &Y){

        // Method is exact
        std::cout << "@errorDense_L2  = 0 "<<"\n";
        std::cout << "@errorDense_Inf = 0 "<<"\n";

    }

};

#endif /* FMMWRAPPER_HPP */
