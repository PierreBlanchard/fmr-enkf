#ifndef FFTWRAPPER_HPP
#define FFTWRAPPER_HPP

// standard includes 
#include <stdio.h>
#include <stdlib.h>

// For std::array<> (i.e. for MultiRhs purpose)
#include <array>

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp"
#include "Utils/FMath.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FAlgorithmTimers.hpp"


// FMR includes
#include "Definition/FMRDefines.hpp"
#include "Definition/ScalFMMDefines.hpp"
#include "FFT/CirculantEmbeddor.hpp"


/**
 * @author Pierre Blanchard (pierre.blanchard@inria.fr)
 * @date October 20th, 2014 
 *
 */


/**
 * @brief FFT Wrapper class
 * This class is used to perform MatMatProd by means of FFT for regular grid and irregular grid. 
 * The latter requiring an extra interpolation.
 */
template<class FReal, class MatrixKernelClass>
class FFTWrapper {


private:

    // needed for leafs
    MatrixKernelClass* MatrixKernel;
    FPoint<FReal>* Positions;

    // needed for P2P init
    const FSize _size;

    // Leaf
    LeafClass* Leaf;

    // Uniform interpolator
    typedef FUnifInterpolator<FReal,ORDER,MatrixKernelClass,NVALS> InterpolatorClass;
    InterpolatorClass* S;

    // Embeddor
    typedef CirculantEmbeddor<FReal,3,3> CirculantEmbeddorClass;
    CirculantEmbeddorClass* CircEmb;


    // size of (uniform) interpolation grid
    const unsigned int nnodes = TensorTraits<ORDER>::nnodes;
    // size of embedding
    FSize sizeEmb;
    // Box width
    const FReal BoxWidth;
    // Box center
    const FPoint<FReal> BoxCenter;

    // Other features
    const bool CompareDirectCW;


public:

    /*
     * Ctor
     */
    explicit FFTWrapper(MatrixKernelClass* inMatrixKernel, const FPoint<FReal>* inPositions, const FSize size, 
                        const FReal inBoxWidth, const FPoint<FReal> inBoxCenter,
                        const bool inCompareDirectCW = false)
        : MatrixKernel(inMatrixKernel),
          Positions(new FPoint<FReal>[size]), _size(size), 
          Leaf(NULL), S(NULL), CircEmb(NULL),
          BoxWidth(inBoxWidth), BoxCenter(inBoxCenter),
          CompareDirectCW(inCompareDirectCW)
    {
        // copy grid positions (needed for fmm tree update)
        for ( FSize i=0; i<size; ++i) 
            Positions[i]=FPoint<FReal>(inPositions[i].getX(),
                                       inPositions[i].getY(),
                                       inPositions[i].getZ());

    }

    /*
     * Dtor
     */
    ~FFTWrapper()
    {
        delete [] Positions;
    }

    /*
     * Initialize Circulant Embeddor (size, embedding, fft...) and interpolation operators
     * 
     */
    void init() {

        // Leaf
        Leaf = new LeafClass();

        // Insert particles in leaf
        for(FSize idxPart=0; idxPart<_size; ++idxPart){
           // Convert FReal[NVALS] to std::array<FReal,NVALS>
            std::array<FReal, (1+4*1)*NVALS> physicalState;
            for(int idxVals = 0 ; idxVals < NVALS ; ++idxVals){
                physicalState[0*NVALS+idxVals]=1.0; // dummy value
                physicalState[1*NVALS+idxVals]=0.0;
                physicalState[2*NVALS+idxVals]=0.0;
                physicalState[3*NVALS+idxVals]=0.0;
                physicalState[4*NVALS+idxVals]=0.0;
            }
            // push particle to leafs
            Leaf->push(Positions[idxPart], idxPart, physicalState);

        }

        // Interpolator
        S = new InterpolatorClass();

        // size of grid
        int *sizeGridDir = new int[3];
        sizeGridDir[0]=ORDER;
        sizeGridDir[1]=ORDER;
        sizeGridDir[2]=ORDER;

        // Extract grid nodes position
        FPoint<FReal> NodesCoords[nnodes];
        FUnifTensor<FReal,ORDER>::setRoots(BoxCenter, BoxWidth, NodesCoords);

        // Circulant embeddor
        typedef CirculantEmbeddor<FReal,3,3> CirculantEmbeddorClass;
        CircEmb = new CirculantEmbeddorClass(sizeGridDir, false); // do not allow extra embedding since non-negativity is NOT required
        CircEmb->embedCovariance(MatrixKernel,NodesCoords);

        // Set embedding size
        sizeEmb = CircEmb->getEmbeddingSize();

    }


    void performCW_FFT(const FSize size, const FSize rank, FReal* W, FReal* &Y){
        FReal *C = NULL;
        this->performCW(2,size,rank,C,W,Y);
        //delete [] C;
    }
    /*
     * performCW: This routine performs the product CW where C is the input matrix and W a set of random vectors
     */
    void performCW(const int fRRF, const FSize size, const FSize rank, /*const*/ FReal* C, FReal* W, FReal* &Y){

        if(C==NULL && fRRF<2) throw std::runtime_error("Matrix not explicitely built, please use a different variant to perform CW or build C explicitely.");

        if(fRRF==0){// multiple dense mat-vec products
            is_int(rank*size);
            FBlas::setzero(int(rank*size),Y);
            for ( FSize i=0; i<size; ++i) 
                for ( FSize j=0; j<size; ++j)
                    for ( FSize r=0; r<rank; ++r) 
                        Y[r*size+i] += C[i*size+j]*W[r*size+j];
            
        }
        else if(fRRF==1){// 1 Blas mat-mat product
            is_int(size); is_int(rank);
            FBlas::gemm(int(size),int(size),int(rank),FReal(1.),
                        C,int(size),W,int(size),Y,int(size));

        }
        else if(fRRF==2){// multiple fft mat-vec products

            // Evaluate number of FMM loops to perform
            const FSize NFMM = rank / NVALS; // here the rank is oversampled
            const FSize NOS  = rank % NVALS; // should correspond to oversampling if non-oversampled rank is well adjusted, i.e. it is a multiple of NVALS.
            // Perform extra loop if rank is not multiple of NVALS
            int extraLoop = 0;
            if(NOS) extraLoop = 1;

            // Perform NFMM schemes of size NVALS + one of size p
            for ( FSize idxFMM=0; idxFMM<NFMM+extraLoop; ++idxFMM) {

                // Update number of blocked vectors to be computed
                // For the sake of clarity, ScalFMM only sees blocks of size NVALS
                // but the last block is padded with NVALS-NOS null vectors
                FSize currentNVALS;
                if(idxFMM<NFMM){
                    currentNVALS = NVALS;
                }
                else{
                    currentNVALS = NOS;
                }

                // Set new input vectors (i.e. physical values)
                {
                    FReal*const physicalValues = Leaf->getTargets()->getPhysicalValuesArray();
                    FReal*const potentials = Leaf->getTargets()->getPotentialsArray();
                    const FSize targetsLD  = Leaf->getTargets()->getLeadingDimension();
                    const FSize nbParticlesInLeaf = Leaf->getTargets()->getNbParticles();
                    const FVector<FSize>& indexes = Leaf->getTargets()->getIndexes();
    
                    for(FSize idxVals = 0 ; idxVals < currentNVALS ; ++idxVals){
                        const FSize idxVec = idxFMM*NVALS+idxVals;
                        for(FSize idxPart = 0 ; idxPart < nbParticlesInLeaf ; ++idxPart){
                            const FSize indexPartOrig = indexes[idxPart];
                            const FSize idxPartValue = idxVals*targetsLD+idxPart;
                            physicalValues[idxPartValue] = W[idxVec*size+indexPartOrig];
                            potentials[idxPartValue] = FReal(0.);
                        }
                    }// end currentNVALS
                }

                // Execute algorithm:

                // Anterpolate: W_n = \sum_j^N S(y_j,\bar y_n) * w_j
                FReal* Mult = new FReal[currentNVALS*nnodes]; // multipole expansion
                is_int(currentNVALS*nnodes);
                FBlas::setzero(int(currentNVALS*nnodes),Mult);

                // the multipole expansions are set to 0 in S.applyP2M (not sure of that! Needed to set to zero othzerwise divergence at higher orders...)
                S->applyP2M(BoxCenter, BoxWidth, Mult, Leaf->getTargets()); 

                // Transfer Multipole to Local expansion
                FReal* Loc = new FReal[currentNVALS*nnodes]; // local expansion
                is_int(currentNVALS*nnodes);
                FBlas::setzero(int(currentNVALS*nnodes),Loc);

                // Do either DENSE or FFT variant for M2L application
                const bool denseM2L = false;
                if(denseM2L){
                
                    //// Without Embedding
                    //for(int idxRow = 0 ; idxRow < nnodes  ; ++idxRow){
                    //    for(int idxCol = 0 ; idxCol < nnodes  ; ++idxCol){
                    //
                    //        Loc[idxRow] += M2LOp[idxRow*nnodes+idxCol] * Mult[idxCol];
                    //
                    //    }
                    //}

                }
                else {

                    // loop over NVALS vectors for the sake of simplicity
                    // TODO think about block operations EFFICIENTLY (maybe not that relevant)
                    for(FSize idxVals = 0 ; idxVals < currentNVALS ; ++idxVals){

                        // Pad multipole expansion
                        FReal* PaddedMult = new FReal[sizeEmb]; 
                        is_int(sizeEmb);
                        FBlas::setzero(int(sizeEmb),PaddedMult);
                        int countMask=0;
                        for(int i=0; i<sizeEmb; ++i) 
                            if(CircEmb->getMask()[i]){
                                PaddedMult[i]=Mult[countMask];
                                ++countMask;
                            }

                        // Transform Multipole expansion
                        FComplex<FReal>* TransMult = new FComplex<FReal>[sizeEmb];
                        CircEmb->applyDFT(PaddedMult,TransMult);

                        // Apply M2L in Fourier space
                        FComplex<FReal>* TransLoc = new FComplex<FReal>[sizeEmb];
                        for(int idxRow = 0 ; idxRow < sizeEmb  ; ++idxRow){
                            TransLoc[idxRow] = FComplex<FReal>(CircEmb->getSingularValues()[idxRow]*TransMult[idxRow].getReal(),
                                                        CircEmb->getSingularValues()[idxRow]*TransMult[idxRow].getImag());
                        }

                        // Transform TransLoc back in physical space
                        FReal* PaddedLoc = new FReal[sizeEmb];
                        CircEmb->applyIDFT(TransLoc,PaddedLoc);

                        // Unpad PaddedLoc
                        countMask=0;
                        for(int i=0; i<sizeEmb; ++i) 
                            if(CircEmb->getMask()[i]){
                                Loc[idxVals*nnodes+countMask]=PaddedLoc[i]; 
                                ++countMask;
                            }

                    }

                }

                // Interpolate: l_j = \sum_n^\ell S(x_j,\bar x_n) * L_n
                S->applyL2P(BoxCenter, BoxWidth, Loc, Leaf->getTargets());

                // Update result
                { 
                    const FReal*const potentials = Leaf->getTargets()->getPotentialsArray();
                    const FSize targetsLD  = Leaf->getTargets()->getLeadingDimension();
                    const FSize nbParticlesInLeaf = Leaf->getTargets()->getNbParticles();
                    const FVector<FSize>& indexes = Leaf->getTargets()->getIndexes();
    
                    for(FSize idxVals = 0 ; idxVals < currentNVALS ; ++idxVals){
                        const FSize idxVec = idxFMM*NVALS+idxVals;
                        for(FSize idxPart = 0 ; idxPart < nbParticlesInLeaf ; ++idxPart){
                            const FSize indexPartOrig = indexes[idxPart];
                            // Update output array Y
                            Y[idxVec*size+indexPartOrig]=potentials[idxVals*targetsLD+idxPart];
                        }
                    }// end currentNVALS
                }

            }// end NFMM

        }
    }

    /*
     * This function computes the error committed by computing the first vector of W using the FMM
     */
    void verifyCW(const FSize size, const FSize rank, FReal* W, FReal* &Y){

        // Compute FMM error ||FMM(CW_0)-Direct(CW_0)||
        if(CompareDirectCW){

            // Compute first Mat-Vec Product using direct method (mutual interactions + self interaction)
            FReal* Yd = new FReal[size];
            is_int(size);
            FBlas::setzero(int(size),Yd);
            FReal C_ii = this->MatrixKernel->evaluate(Positions[0],Positions[0]);
            for(FSize idxTarget = 0 ; idxTarget < size ; ++idxTarget){
                // Self-interaction
                Yd[idxTarget] += C_ii * W[idxTarget];
                // Mutual interactions
                for(FSize idxOther = idxTarget + 1 ; idxOther < size ; ++idxOther){
                    FReal C_ij = this->MatrixKernel->evaluate(Positions[idxTarget],Positions[idxOther]);
                    Yd[idxTarget] += C_ij * W[idxOther ];
                    Yd[idxOther ] += C_ij * W[idxTarget];
                }
            }
            // Compute error 
            FMath::FAccurater<FReal> errorFMM;
            for ( FSize r=0; r<rank; ++r) 
              for ( FSize j=0; j<size; ++j)
                errorFMM.add(Yd[/*r*size+*/j],Y[r*size+j]);
            
            std::cout << "@errorFMM_L2  = "<< errorFMM.getRelativeL2Norm() <<"\n";
            std::cout << "@errorFMM_Inf = "<< errorFMM.getRelativeInfNorm() <<"\n";
        }

    }

};

#endif /* FFTWRAPPER_HPP */
