#ifndef CIRCULANTEMBEDDOR_HPP
#define CIRCULANTEMBEDDOR_HPP

#include <stdio.h>
#include <stdlib.h>

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" 
#include "Utils/FMath.hpp"
//#include "Utils/FNoCopyable.hpp"
#include "Utils/FDft.hpp"

// FMR includes
#include "Correlations/CorrelationKernels.hpp"

/**
 * @author Pierre Blanchard (pierre.blanchard@inria.fr)
 * @date March 16th, 2014 
 *
 * TODO Check rectangular grid works
 *
 */



template <class FReal, int DIM, int DIMEMB = DIM>
class CirculantEmbeddor //: FNoCopyable
{
  enum {dim = DIM, //> spatial dimension of problem 
        dimEmb = DIMEMB, //> number of embedded dimensions
        maxdim = 3, //> maximal spatial dimension
        maxdimEmb = 6}; // //> maximum number of embedded dimensions

private:
  int sizeDir_[dimEmb]; // size of grid in each directions
  int size_; // total size of covariance matrix
  int sizeEmbDir_[dimEmb]; // size of initial embedding in each direction
  int sizeEmb_; // current size of embedding matrix
  int sizeInitDir_[dimEmb]; // copy of initial size per direction
  int sizeInit_; // copy of initial size
  int countEmb_; // current number of embeddings
  const int countEmbMax_; // maximum number of embeddings

  // first row of the Circulant matrix (output)
  FReal* EmbeddingRow;

  // mask/padding (output)
  int* Mask;

  // singular values
  FReal* SingularValues;

  // Embedding permutations [0 1 ... N-1 N | N-1 ... 1]
  int *EmbeddingPermutations;

  // Flag to activate or deactivate the extra embedding feature
  // for instance if non negativity is not required
  const bool allowExtraEmbedding_; 

public:
  /**
   * Constructor: Initialize sizes and embedding tools.
   */
  explicit CirculantEmbeddor(const int sizeDir[dimEmb], const bool allowExtraEmbedding = true)
  : countEmb_(0), 
    countEmbMax_(3), // only 2 since extra embedding not ready yet  
    allowExtraEmbedding_(allowExtraEmbedding)
  {
    // init size
    size_=sizeEmb_=1;
    for(int d = 0 ; d < dimEmb ; ++d){ 
      sizeDir_[d]=sizeDir[d];
      size_*=sizeDir_[d];

      // minimal circulant embedding of N\timesN ...
      // ... Toeplitz-Symmetric matrix is 2N-2
      sizeEmbDir_[d] = 2*sizeDir_[d]-2;
//      // ... General Toeplitz matrix is 2N-1
//      sizeEmbDir_[d] = 2*sizeDir_[d]-1; 
      sizeEmb_*=sizeEmbDir_[d];
    }

    // store init size (just in case)
    for(int d = 0 ; d < dimEmb ; ++d)
      sizeInitDir_[d]=sizeDir_[d]; 
    sizeInit_=size_;

    // allocate arrays
    // EmbeddingRow = new FReal[sizeEmb_];
    Mask = new int[sizeEmb_];

    /// Embed 
    // Either using indices node pairs (this alternative was removed cuz inefficient)
    // + easier to visualize and treat non-sym Toeplitz matrix
    // - more evaluations (~x2) than needed in our case of sym Toeplitz matrix
    // Either using embedding permutation [0 1 ... N-1 N | N-1 ... 1]
    // + basic permutation, even size (efficient FFT)
    // - does not extend to toeplitz matrix (is it really a problem?)

    // init embedding permutations [0 1 ... N]
    EmbeddingPermutations = new int[size_]; // init size changed by setEmbed()
    for(int p=0; p<size_; ++p) EmbeddingPermutations[p]=p;
    // set embedding permutations
    setEmbedding();
  }

  /**
   * Destructor: Delete dynamically allocated memory for ...
   */
  ~CirculantEmbeddor()
  {
    delete[] EmbeddingRow;
    delete[] Mask;
    delete[] SingularValues;
    delete[] EmbeddingPermutations;
  }

  /*
   * Diverse accessors
   */
  int getEmbeddingSize()
  {return sizeEmb_;}

  int* getEmbeddingSizeDir()
  {return sizeEmbDir_;}

  FReal* getEmbeddingRow()
  {return EmbeddingRow;}

  FReal* getSingularValues()
  {return SingularValues;}

  int* getMask()
  {return Mask;}

  /* 
   * CirculantEmbeddor::generateFullMatrix()
   *
   * Generate the full block circulant embedding matrix from its first row
   * using a generic implementation (i.e. should work for 1-2-3D)
   *
   */
  void generateFullMatrix(FReal* EmbeddingMat)
  {
    int sizeEmbDir[maxdimEmb];

    for(int d = 0 ; d < maxdimEmb ; ++d){ 
      if(d<dimEmb) {sizeEmbDir[d]=sizeEmbDir_[d];}
      else {sizeEmbDir[d]=1;}
    }

    // precompute circular permutation vector
    // ... for blockwise permutation
    int block_perm[sizeEmbDir[1]];
    for(int p = 0; p<sizeEmbDir[1]; ++p){
      if(p==0) block_perm[p]=sizeEmbDir[1]-1;
      else block_perm[p] = p-1;
    }
    // ... for permutation inside a block
    int sub_perm[sizeEmbDir[0]];
    for(int p = 0; p<sizeEmbDir[0]; ++p){
      if(p==0) sub_perm[p]=sizeEmbDir[0]-1;
      else sub_perm[p] = p-1;
    }

    // generate full matrix
    for(int j = 0; j<sizeEmbDir[1]; ++j) // loop over row-blocks
      for(int i = 0; i<sizeEmbDir[0]; ++i) // idx of row in row-blocks
        for(int q = 0; q<sizeEmbDir[1]; ++q) // idx of col-block
          for(int p = 0; p<sizeEmbDir[0]; ++p){ // idx of col in current block
            if(i==0) {
              if(j==0) {
                // copy first row
                EmbeddingMat[q*sizeEmbDir[0]+p] = 
                  EmbeddingRow[q*sizeEmbDir[0]+p];
              }
              else {
                // permute first row and copy
                EmbeddingMat[j*sizeEmbDir[0]*sizeEmb_+q*sizeEmbDir[0]+p] = 
                  EmbeddingMat[(j-1)*sizeEmbDir[0]*sizeEmb_+block_perm[q]*sizeEmbDir[0]+p];
              }
            }
            else {
              // next row is the circular permutation of each block's previous row
              EmbeddingMat[(j*sizeEmbDir[0]+i)*sizeEmb_+q*sizeEmbDir[0]+p] = 
                EmbeddingMat[(j*sizeEmbDir[0]+(i-1))*sizeEmb_+q*sizeEmbDir[0]+sub_perm[p]];
            }
          }
  }

   /* 
   * CirculantEmbeddor::generateFullMatrix3D()
   *
   * Generate the full 3rd dim block circulant embedding matrix from its first row
   *
   */
  void generateFullMatrix3D(FReal* EmbeddingMat)
  {
    int sizeEmbDir[maxdimEmb];

    for(int d = 0 ; d < maxdimEmb ; ++d){ 
      if(d<dimEmb) {sizeEmbDir[d]=sizeEmbDir_[d];}
      else {sizeEmbDir[d]=1;}
    }

    // precompute circular permutation vector
    // ... for superblock permutation
    int sup_perm[sizeEmbDir[2]];
    for(int p = 0; p<sizeEmbDir[2]; ++p){
      if(p==0) sup_perm[p]=sizeEmbDir[2]-1;
      else sup_perm[p] = p-1;
    }
    // ... for blockwise permutation
    int perm[sizeEmbDir[1]];
    for(int p = 0; p<sizeEmbDir[1]; ++p){
      if(p==0) perm[p]=sizeEmbDir[1]-1;
      else perm[p] = p-1;
    }
    // ... for permutation inside a block
    int sub_perm[sizeEmbDir[0]];
    for(int p = 0; p<sizeEmbDir[0]; ++p){
      if(p==0) sub_perm[p]=sizeEmbDir[0]-1;
      else sub_perm[p] = p-1;
    }

    // generate full matrix
    for(int k = 0; k<sizeEmbDir[2]; ++k) // loop over row-superblocks
    for(int j = 0; j<sizeEmbDir[1]; ++j) // loop over row-blocks
      for(int i = 0; i<sizeEmbDir[0]; ++i) // idx of row in row-blocks
        for(int r = 0; r<sizeEmbDir[2]; ++r) // idx of col-superblock
        for(int q = 0; q<sizeEmbDir[1]; ++q) // idx of col-block
          for(int p = 0; p<sizeEmbDir[0]; ++p){ // idx of col in current block
            const int pos_in_row = r*sizeEmbDir[1]*sizeEmbDir[0]+q*sizeEmbDir[0]+p;
            const int pos_in_col = k*sizeEmbDir[1]*sizeEmbDir[0]+j*sizeEmbDir[0]+i;


            // Test extend 2d version
            if(i==0) {
              if(j==0) {
                if(k==0) {
                    // copy first row
                    EmbeddingMat[pos_in_row] = EmbeddingRow[pos_in_row];

                }
                else { //k!=0
                    // permute first row and copy
                    EmbeddingMat[k*sizeEmbDir[1]*sizeEmbDir[0]*sizeEmb_+pos_in_row] = 
                    EmbeddingMat[(k-1)*sizeEmbDir[1]*sizeEmbDir[0]*sizeEmb_+(sup_perm[r]*sizeEmbDir[1]*sizeEmbDir[0]+q*sizeEmbDir[0]+p)];
                }
              }
              else { //j!=0
                if(k==0) {
                    // permute first row and copy
                    EmbeddingMat[(k*sizeEmbDir[1]*sizeEmbDir[0]+j*sizeEmbDir[0])*sizeEmb_+pos_in_row] = 
                    EmbeddingMat[(k*sizeEmbDir[1]*sizeEmbDir[0]+(j-1)*sizeEmbDir[0])*sizeEmb_+(r*sizeEmbDir[1]*sizeEmbDir[0]+perm[q]*sizeEmbDir[0]+p)];
                }
                else { //k!=0
                    // permute first row and copy
                    EmbeddingMat[(k*sizeEmbDir[1]*sizeEmbDir[0]+j*sizeEmbDir[0])*sizeEmb_+pos_in_row] = 
                    EmbeddingMat[((k-1)*sizeEmbDir[1]*sizeEmbDir[0]+(j-1)*sizeEmbDir[0])*sizeEmb_+(sup_perm[r]*sizeEmbDir[1]*sizeEmbDir[0]+perm[q]*sizeEmbDir[0]+p)];                
                }
              }
            }
            else { //i!=0
                if(j==0){
                    if(k==0) {
                        // next row is the circular permutation of each block's previous row
                        EmbeddingMat[(k*sizeEmbDir[1]*sizeEmbDir[0]+j*sizeEmbDir[0]+i)*sizeEmb_+pos_in_row] = 
                        EmbeddingMat[(k*sizeEmbDir[1]*sizeEmbDir[0]+j*sizeEmbDir[0]+(i-1))*sizeEmb_+(r*sizeEmbDir[1]*sizeEmbDir[0]+q*sizeEmbDir[0]+sub_perm[p])];
                    }
                    else {
                        // next row is the circular permutation of each block's previous row
                        EmbeddingMat[(k*sizeEmbDir[1]*sizeEmbDir[0]+j*sizeEmbDir[0]+i)*sizeEmb_+pos_in_row] = 
                        EmbeddingMat[((k-1)*sizeEmbDir[1]*sizeEmbDir[0]+j*sizeEmbDir[0]+(i-1))*sizeEmb_+(sup_perm[r]*sizeEmbDir[1]*sizeEmbDir[0]+q*sizeEmbDir[0]+sub_perm[p])];
                    }
                }
                else { // j!=0
                    if(k==0){
                        // next row is the circular permutation of each block's previous row
                        EmbeddingMat[(k*sizeEmbDir[1]*sizeEmbDir[0]+j*sizeEmbDir[0]+i)*sizeEmb_+pos_in_row] = 
                        EmbeddingMat[(k*sizeEmbDir[1]*sizeEmbDir[0]+(j-1)*sizeEmbDir[0]+(i-1))*sizeEmb_+(r*sizeEmbDir[1]*sizeEmbDir[0]+perm[q]*sizeEmbDir[0]+sub_perm[p])];
                    }
                    else {
                        // next row is the circular permutation of each block's previous row
                        EmbeddingMat[(k*sizeEmbDir[1]*sizeEmbDir[0]+j*sizeEmbDir[0]+i)*sizeEmb_+pos_in_row] = 
                        EmbeddingMat[((k-1)*sizeEmbDir[1]*sizeEmbDir[0]+(j-1)*sizeEmbDir[0]+(i-1))*sizeEmb_+(sup_perm[r]*sizeEmbDir[1]*sizeEmbDir[0]+perm[q]*sizeEmbDir[0]+sub_perm[p])];
                    }
                }
            }
            
        }
  }

  /* 
   * CirculantEmbeddor::generateFullSquareRoot()
   *
   * Generate the full square root matrix of block circulant embedding matrix 
   * from its first row
   * using a generic implementation (i.e. should work for 1-2-3D)
   * 
   * E^{1/2}=FS^{1/2}F^*
   *
   */
  void generateFullSquareRoot(FReal* SqRtEmbeddingMat)
  {
    // get singular values
    FReal *S = new FReal[sizeEmb_];
    FBlas::copy(sizeEmb_,getSingularValues(),S);

    // compute square root S^{1/2} of singular values S
    FComplex<FReal> *sqrtS = new FComplex<FReal>[sizeEmb_*sizeEmb_]; // store in complex diqgonal matrix
    FBlas::c_setzero(sizeEmb_*sizeEmb_,reinterpret_cast<FReal*>(sqrtS));
    for ( int i=0; i<sizeEmb_; ++i)
      sqrtS[i*sizeEmb_+i] = FComplex<FReal>(sqrt(S[i]),0.);

    delete [] S;

    // init C-valued FFT
    //FCFft<FReal,dimEmb> CFft(sizeEmbDir_); // C-valued FFT
    FFftw<FComplex<FReal>,FComplex<FReal>,dimEmb> CFft(sizeEmb_); // C-valued FFT


    // Compute S^{1/2}F^*=((F^*)^tS^{1/2}^t)^t
    FComplex<FReal> *rtSxF = new FComplex<FReal>[sizeEmb_*sizeEmb_];
    FComplex<FReal> *FxrtS = new FComplex<FReal>[sizeEmb_];

    for ( int i=0; i<sizeEmb_; ++i){
      // perform INVERSE FFT on each row
      FBlas::c_setzero(sizeEmb_,reinterpret_cast<FReal*>(FxrtS));
      CFft.applyIDFTNorm(sqrtS + i*sizeEmb_, FxrtS);

      // transpose result
      for ( int j=0; j<sizeEmb_; ++j)
        rtSxF[j*sizeEmb_+i]=FxrtS[j];
    }
    delete [] FxrtS;
    delete [] sqrtS;

    // Compute F(S^{1/2}F^*)
    FComplex<FReal> *CrtEC = new FComplex<FReal>[sizeEmb_];
    for ( int i=0; i<sizeEmb_; ++i){
      // perform FFT on each row
      FBlas::c_setzero(sizeEmb_,reinterpret_cast<FReal*>(CrtEC));
      CFft.applyDFT(rtSxF + i*sizeEmb_, CrtEC);
      // copy square root matrix while verifying that it is real valued
      for ( int j=0; j<sizeEmb_; ++j)
        if(FMath::Abs(CrtEC[j].getImag())<1e-12)
          SqRtEmbeddingMat[i*sizeEmb_+j]=CrtEC[j].getReal();
        else
          throw std::runtime_error("Square root of embedding is not real valued!");
    }
    delete [] CrtEC;

  }


  /*
   * CirculantEmbeddor::setEmbedding()
   *
   * This function set the permutation vector used to embed a row of size N 
   * (the current size of the matrix) into a block circulant row of size 2*N-2 
   * (size of the new embedding matrix) 
   *
   * TODO: implement recursive version
   */
  void setEmbedding()
  {
    // This is a generic function for dimEmb<dimEmbmax
    int sizeDir[maxdimEmb]; 
    int sizeEmbDir[maxdimEmb];

    for(int d = 0 ; d < maxdimEmb ; ++d){ 
      if(d<dimEmb) {sizeDir[d]=sizeDir_[d]; sizeEmbDir[d]=sizeEmbDir_[d];}
      else {sizeDir[d]=1; sizeEmbDir[d]=1;}
    }

    // copy previous permutations
    int previousEmbeddingPermutations[size_];
    for(int p=0; p<size_; ++p) 
      previousEmbeddingPermutations[p]=EmbeddingPermutations[p];

    // delete previous permutation and reallocate larger array
    delete[] EmbeddingPermutations;
    EmbeddingPermutations = new int[sizeEmb_];

    int lp,mp,np;
    int pp,qp,rp;
    int ido = 0;

    // TODO recursive version for arbitrary dimension
//    int *new_perm;
//    new_perm = new int[sizeEmb_];
//    for(int p=0; p<sizeEmb_; ++p) new_perm[p]=0;
//    setEmbeddingRecursive(0, sizeEmbDir, sizeDir, ido, new_perm);
//    
//    for(int p=0; p<sizeEmb_; ++p) 
//      EmbeddingPermutations[ido] = previousEmbeddingPermutations[new_perm[p]];

    for(int l=0; l<sizeEmbDir[0]; ++l){
      if(l<sizeDir[0]) {lp=l;} else {lp=sizeEmbDir[0]-l;} 
      for(int m=0; m<sizeEmbDir[1]; ++m){
        if(m<sizeDir[1]) {mp=m;} else {mp=sizeEmbDir[1]-m;} 
        for(int n=0; n<sizeEmbDir[2]; ++n){
          if(n<sizeDir[2]) {np=n;} else {np=sizeEmbDir[2]-n;} 

          // local idx of cluster
          int idlmn = lp*sizeDir[1]*sizeDir[2]+mp*sizeDir[2]+np;

          for(int p=0; p<sizeEmbDir[maxdim+0]; ++p){
            if(p<sizeDir[maxdim+0]) {pp=p;} else {pp=sizeEmbDir[maxdim+0]-p;} 
            for(int q=0; q<sizeEmbDir[maxdim+1]; ++q){
              if(q<sizeDir[maxdim+1]) {qp=q;} else {qp=sizeEmbDir[maxdim+1]-q;} 
              for(int r=0; r<sizeEmbDir[maxdim+2]; ++r){
                if(r<sizeDir[maxdim+2]) {rp=r;} else {rp=sizeEmbDir[maxdim+2]-r;} 

                // local idx of interpolation point
                int idpqr = pp*sizeDir[maxdim+1]*sizeDir[maxdim+2]+qp*sizeDir[maxdim+2]+rp;
                // global idx of interpolation point
                int idlmnpqr = idlmn*sizeDir[maxdim+0]*sizeDir[maxdim+1]*sizeDir[maxdim+2] + idpqr;


                // set Permutation
                EmbeddingPermutations[ido] = 
                  previousEmbeddingPermutations[idlmnpqr];
          //              np*sizeDir[0]*sizeDir[1]+mp*sizeDir[0]+lp;

                // set Mask (beware that ok for extra embedding)
                bool flaglmn = bool(n<sizeDir[2] && m<sizeDir[1] && l<sizeDir[0]);
                bool flagpqr = bool(r<sizeDir[maxdim+2] && q<sizeDir[maxdim+1] && p<sizeDir[maxdim+0]);

                if(flaglmn && flagpqr) Mask[ido]=1;
                else Mask[ido]=0;

                ++ido;
              }
            }
          }// end pqr
        }
      }
    }// end lmn
    
    

//    // display embeddor
//    ido = 0;
//    std::cout<<"\n embeddor=[";
//    for(int l=0; l<sizeEmbDir[0]; ++l){
//      for(int m=0; m<sizeEmbDir[1]; ++m){
//        for(int n=0; n<sizeEmbDir[2]; ++n){
//          for(int p=0; p<sizeEmbDir[maxdim+0]; ++p){
//            for(int q=0; q<sizeEmbDir[maxdim+1]; ++q){
//              for(int r=0; r<sizeEmbDir[maxdim+2]; ++r){
//                std::cout << EmbeddingPermutations[ido] << " ";
//                ++ido;
//              }
//            }
//            std::cout << " | ";
//          }
//        }
//      }
//      std::cout<<std::endl;
//    }
//    std::cout<<"]"<<std::endl;
    
  }

//  void setEmbeddingRecursive(const int dir, const int* sizeEmbDir, const int* sizeDir, int &ido, int* perm)
//  {
//    std::cout<< "dir="<< dir << std::endl;
//
//    if(dir<dimEmb)
//      for(int l=0; l<sizeEmbDir[dir]; ++l){
//        int lp;
//        if(l<sizeDir[dir]) {lp=l;} else {lp=sizeEmbDir[dir]-l;}
//        perm[ido]+=lp;
//        if(dir<dimEmb-1) 
//          perm[ido]*=sizeDir[dir];
//
//        if(dir==dimEmb-1) ido++;
//
//        setEmbeddingRecursive(dir+1,sizeEmbDir,sizeDir, ido, perm);
//      }
//    else 
//      std::cout<< "Permutations completed!" << std::endl;
//  }

  /*
   * CirculantEmbeddor::embedCovariance()
   *
   * This function embed covariance matrix in a circulant (1D) 
   * or block circulant (2D) definite positive matrix
   *
   */
  template<class CorrelationKernelClass>
  void embedCovariance(const CorrelationKernelClass* const CorrelationKernel, const FPoint<FReal>* const Grid)
  {
    // Convert points to FReal[][dim]
    FReal t[size_][dim];
    for(int idxCol = 0 ; idxCol < size_ ; ++idxCol){
        t[idxCol][0] = Grid[idxCol].getX();
        t[idxCol][1] = Grid[idxCol].getY();
        t[idxCol][2] = Grid[idxCol].getZ();
    }
    // Call original function
    embedCovariance(CorrelationKernel,t);
  }

  template<class CorrelationKernelClass>
  void embedCovariance(const CorrelationKernelClass* const CorrelationKernel, const FReal Grid[/*sizeDir_*/][dim])
  {
    FReal *currentEmbeddingRow = new FReal[sizeEmb_];

    //  Embed original N x N covariance matrix in 2N-2 x 2N-2 circulant mat
    // NB: if sizeEmb_ is init to 2N-1 then minimal embedding of toeplitz mat is achieved
    // BEWARE! The sym embedding (2N-2) does not work for toeplitz matrix
    // However if the first embedding is 2N-1, since the embedding matrix 
    // remains sym we can switch to the 2N-2 variant.

    /// using Embedding Permutations
    // init embedded row
    FReal *EmbeddedRow = new FReal[size_];
//    for(int idxRow = 0 ; idxRow < size_ ; ++idxRow){
      for(int idxCol = 0 ; idxCol < size_ ; ++idxCol){
        EmbeddedRow[0*size_+idxCol] 
          = CorrelationKernel->evaluate(Grid[0],
                                        Grid[idxCol]);
      }
//    }    

    // set permutation (already done in ctor)

    // apply permutation
    for(int idEmb=0; idEmb<sizeEmb_; ++idEmb)
      currentEmbeddingRow[idEmb] = EmbeddedRow[EmbeddingPermutations[idEmb]];

//    // display current Embedding row
//    std::cout<<"\ncurrentEmbeddingRow=[";
//    for ( int j=0; j<sizeEmbDir_[0]; ++j) {
//      for ( int i=0; i<sizeEmbDir_[dim+0]*sizeEmbDir_[dim+1]*sizeEmbDir_[dim+2]; ++i) {
//        std::cout << currentEmbeddingRow[j*sizeEmbDir_[1]*sizeEmbDir_[2]*sizeEmbDir_[dim+0]*sizeEmbDir_[dim+1]*sizeEmbDir_[dim+2]+i] << " ";
//      }
//      std::cout<<"||"<<std::endl;
//    }
//    std::cout<<"]"<<std::endl;



    // clear memory
    delete[] EmbeddedRow;

    /// increment number of permutations
    ++countEmb_;

    // test if embedding matrix is non-negative
    while(!is_nonnegative(sizeEmb_,currentEmbeddingRow) && allowExtraEmbedding_ && countEmb_<countEmbMax_)
      {// if not perform extra embedding

        /*
         * Size of new matrix to embed is equal to size of previous embedding
         * Delete previous permutation and init/set a new one
         * 
         */
        // for now return run time error!
        throw std::runtime_error("Extra embedding not yet validated!");

        std::cout << "Perform an extra embedding, since current embedding has at least one negative singular value." << std::endl;

        // init extra sizes 
        for(int d = 0 ; d < dimEmb ; ++d)
          sizeDir_[d]=sizeEmbDir_[d]; 
        size_=sizeEmb_;

        // update size of embedding
        sizeEmb_=1;
        for(int d = 0 ; d < dimEmb ; ++d){
          sizeEmbDir_[d]=2*sizeEmbDir_[d]-2; 
          sizeEmb_*=sizeEmbDir_[d];
        }

        // precompute embedding permutations
        setEmbedding();

        // generate first embedded row 
        FReal *extraEmbeddingRow = new FReal[sizeEmb_];
        for(int p = 0; p<sizeEmb_; ++p)
          extraEmbeddingRow[p] = currentEmbeddingRow[EmbeddingPermutations[p]];

        // update size and re(-al)locate current embedding
        delete[] currentEmbeddingRow; // clear old array
        currentEmbeddingRow = new FReal[sizeEmb_];
        FBlas::copy(sizeEmb_,extraEmbeddingRow,currentEmbeddingRow);

        delete[] extraEmbeddingRow; // clear new array
        ++countEmb_;
      }

    std::cout << "Matrix is non-negative after "<< countEmb_ 
              << " embedding(s) (size "<< sizeEmb_ <<")." << std::endl;

    // Allocate and set output EmbeddingRow
    EmbeddingRow = new FReal[sizeEmb_];
    FBlas::copy(sizeEmb_,currentEmbeddingRow,EmbeddingRow);

    // clear memory
    delete[] currentEmbeddingRow;

  }

  /*
   * Evaluate spectrum of embedding matrix via FFT of first row
   * 1D: usual 1D FFT
   * 2D: 2D FFT since embedding is block circulant
   * ...
   */
  bool is_nonnegative(const int sizeEmb, const FReal* currentEmbeddingRow)
  {
    // Applying Discrete Fourier Transform on embedded row 
    // ... returns spectrum of circulant embedding matrix
    // We use the C-valued FFT because the order of the SVals matters 

    // Compute singular values
    FReal *S = new FReal[sizeEmb];
    computeSingularValues(sizeEmb,currentEmbeddingRow,S);

    // set singular values EVEN IF NEGATIVE SV
    SingularValues = new FReal[sizeEmb];
    FBlas::copy(sizeEmb,S,SingularValues);

    // test if embedding matrix is non-negative
    for ( int i=0; i<sizeEmb; ++i)
      if(S[i] < -1e-12) {
        std::cout << "S[" << i << "]=" << S[i] << std::endl;
        return false; 
    }

    return true;
  }


  void computeSingularValues(const int sizeEmb, 
                             const FReal* currentEmbeddingRow,
                             FReal* S)
  {
    // BEWARE! What size for the FFT when extra embedding is required???

    // init C-valued FFT
    //FCFft<FReal,dimEmb> CFft(sizeEmbDir_); // C-valued FFT
    FFftw<FComplex<FReal>,FComplex<FReal>,dimEmb> CFft(sizeEmb_); // C-valued FFT

    // Copy real embedding row in complex array
    FComplex<FReal> *CmplxEmbeddingRow = new FComplex<FReal>[sizeEmb];
    for ( int i=0; i<sizeEmb; ++i)
      CmplxEmbeddingRow[i]=FComplex<FReal>(currentEmbeddingRow[i],0.0);
    
    // Perform C-valued FFT
    FComplex<FReal> *FEmbeddingRow = new FComplex<FReal>[sizeEmb];
    CFft.applyDFT(CmplxEmbeddingRow,FEmbeddingRow);

    // Verify singular values are real valued
    for ( int i=0; i<sizeEmb; ++i)
      if(FMath::Abs(FEmbeddingRow[i].getImag())<1e-12)
        S[i]=FEmbeddingRow[i].getReal();
      else{
        std::cout << "S[" << i << "]=" << FEmbeddingRow[i] << std::endl;
        throw std::runtime_error("Singular values not real valued!");
}
//    // display Singular values
//    std::cout<<"\nS=[";
//    for ( int i=0; i<sizeEmb; ++i) 
//      std::cout << S[i] << " ";
//    std::cout<<"]"<<std::endl;

  }




  void applyDFT(FReal *const Y, FComplex<FReal> *const FY)
  {

    // init C-valued FFT
    //FCFft<FReal,dimEmb> CFft(sizeEmbDir_); // C-valued FFT
    FFftw<FComplex<FReal>,FComplex<FReal>,dimEmb> CFft(sizeEmb_); // C-valued FFT

    // Copy real input array in complex array
    FComplex<FReal> *CmplxY = new FComplex<FReal>[sizeEmb_];
    for ( int i=0; i<sizeEmb_; ++i)
      CmplxY[i]=FComplex<FReal>(Y[i],0.0);
    
    // Perform C-valued FFT
    CFft.applyDFT(CmplxY,FY);

  }

  void applyIDFT(const FComplex<FReal> *const FY, FReal *const Y)
  {

    // init C-valued FFT
    //FCFft<FReal,dimEmb> CFft(sizeEmbDir_); // C-valued FFT
    FFftw<FComplex<FReal>,FComplex<FReal>,dimEmb> CFft(sizeEmb_); // C-valued FFT
    
    // Perform C-valued FFT
    FComplex<FReal> *CmplxY = new FComplex<FReal>[sizeEmb_];
    CFft.applyIDFTNorm(FY,CmplxY);

    // Copy real input array in complex array
    for ( int i=0; i<sizeEmb_; ++i)
      Y[i]=CmplxY[i].getReal();

  }

};

#endif /* CIRCULANTEMBEDDOR_HPP */
