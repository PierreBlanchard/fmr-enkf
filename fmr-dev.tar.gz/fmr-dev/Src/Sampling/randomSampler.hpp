#ifndef RANDOMSAMPLER_HPP
#define RANDOMSAMPLER_HPP


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator
#include <algorithm> // for sort

#include <array> // for std::array initDistribution

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "./Utils/FAssert.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

#include "Utils/MatrixIO.hpp" // for input/output matrix-file
#include "Utils/VectorNorms.hpp" // for leverage scores

#include "Utils/Display.hpp" // In order to display vectors and arrays

// ... for exact leverage scores
#include "StandardLRA/SVD.hpp" 
// ... for approximate leverage scores
#include "Sampling/LeverageScores.hpp"
//#include "RandomizedLRA/AdaptiveRandomizedRangeFinder.hpp"
//#include "RandomizedLRA/RandomizedRangeFinder.hpp"
//#include "RandomizedLRA/RandSVD.hpp"
// ... for Dense Matrix Multiplication
#include "MatrixWrappers/DenseWrapper.hpp"

// ... for residuals
#include "Sampling/Residuals.hpp"


/**
 * @brief The Sampler namespace
 *
*/
namespace randomSampler
{


/*
 * controlMultiplicity
 *
 * Control sampling multiplicity
 * 
 */
static void controlMultiplicity(const FSize size, const FSize rank, FSize* sampledIndices){


    // Sampling multiplicity
    FSize* samplingMultiplicity = new FSize[size];


    // Init permutations
    for (int i=0; i<size; ++i) {
        samplingMultiplicity[i] = FSize(0);
    }

    // Compute sampling multiplicity
    for (int i=0; i<rank; ++i) {
        samplingMultiplicity[sampledIndices[i]] += FSize(1);
    }

    // Display sampling multiplicity in a user friendly way
    for (int i=0; i<rank; ++i){
        if(samplingMultiplicity[sampledIndices[i]]>=2) std::cout << "Index " << sampledIndices[i] << " is sampled " << samplingMultiplicity[sampledIndices[i]] << " times." << std::endl;
    }

    //// Display samplingMultiplicity vector
    //Display::vector(size,samplingMultiplicity,"samplingMultiplicity",10,1);

    // Permutation vector
    // Size of permutation vector
    FSize permSize = 0;
    for (int i=0; i<size; ++i){
        // count number of sampled values (should be equal to rank)
        permSize+=samplingMultiplicity[i];
    }
    if(permSize!=rank) throw std::runtime_error("Number of sampled values (computed from multiplicity) is not equal to rank!");
    for (int i=0; i<size; ++i){
        // count non sampled values
        if(samplingMultiplicity[i]==0)
            permSize++;
    }
    //std::cout << "permSize=" << permSize << std::endl;

    const FSize const_permSize = permSize;
    FSize* permutation = new FSize[const_permSize];

    // Read remaining indices
    int countIndices = 0;
    for (FSize i=0; i<size; ++i) {
        if(samplingMultiplicity[i]==FSize(0)){
            permutation[countIndices] = i;
            countIndices++;
        }

    }
    if(countIndices!=(permSize-rank)) throw std::runtime_error("Number of values not sampled is not equal to permSize-rank!");
    //std::cout << "Number of values that are not sampled: " << countIndices << " over " << size << std::endl;

    // free memory
    delete[] permutation;
    delete [] samplingMultiplicity;
}

/*
 * sampleIndicesGivenProbabilities
 *
 *
 * 
 */
static void sampleIndicesGivenProbabilities(const FSize size, const FReal* samplingProbabilities, const FSize nbSampledIndices, FSize* &sampledIndices, const bool withReplacement){

    FAssertLF(nbSampledIndices<=size);

    // Initialize distribution
    std::vector<FReal> initDistribution(size);
    FReal sumProba=FReal(0.);
    for (FSize i = 0; i < size; ++i)
    {
        initDistribution[i] = samplingProbabilities[i];
        sumProba+=initDistribution[i];
    }
    //
    //Display::vector(rank,samplingProbabilities,"init",10,0);
    // Verify if sum of probabilities equals 1
    //std::cout << "sum(samplingProbabilities) = " << sumProba << std::endl;
    //if(sumProba!=FReal(1.)) throw std::runtime_error("Sum of sampling probabilities not equal to 1.");

    // Random number generator
    std::mt19937_64 generator(std::random_device{}());
    // Discrete Distribution
    std::discrete_distribution<FSize> distribution(initDistribution.begin(),initDistribution.end());
    distribution(generator);
    // Sample nbSampledIndices indices from 0 to size-1
    if(withReplacement){
        // ... with replacement
        for (int i=0; i<nbSampledIndices; ++i) {
            //if(select_mode==0)
            sampledIndices[i] = distribution(generator); // from 0 to size-1
            //else if(select_mode==1)
            //    sampledIndices[i] = i;
        }
    }
    else{
        // ... without replacement
        int countSamples=0;
        while(countSamples<nbSampledIndices){
            FSize tmpSample = distribution(generator);
            // Look for value in 
            bool isAlreadySampled = false;
            for (int i=0; i<countSamples; ++i)
                if(tmpSample==sampledIndices[i]) isAlreadySampled=true;
            if(!isAlreadySampled) {
                sampledIndices[countSamples++]=tmpSample;
            }
        }
    }

}

/*
 * sampleIndices
 *
 * Sample "c" indices from 0 to "size-1" using sampling probabilities: constant or proportionnal to leverage scores.
 * Deterministic column selection is also possible.
 * Expected rank is also passed, in case the algorithm requires it (e.g. ???leverage scores???, near optimal col selection Boutsidis 2011) 
 * 
 */
static void sampleIndices(const FSize size, const FSize rank, /*const*/ FReal* M, const FSize nbSampledIndices, FSize* &sampledIndices, const int samplingTechnique, const bool withReplacement){

    // Subsampled indices
    sampledIndices = new FSize[nbSampledIndices];

    // LS computation method
    const int fSVD = 1; //0: SVD; 1: RandSVD =10% of size
    // Declare sampling probabilities
    FReal* samplingProbabilities = new FReal[size];
    // Compute sampling probabilities
    if(samplingTechnique==0 || samplingTechnique==2){ // uniform sampling 
        for (FSize i = 0; i < size; ++i)
            samplingProbabilities[i]=FReal(1.)/FReal(size);
    }
    else if(samplingTechnique==1){ // lev scores sampling
        // ... compute leverage scores
        LeverageScores::computeScoresOnly(size,nbSampledIndices,M,samplingProbabilities,fSVD); // [TODO] Do we need to pass the target rank??
        // ... scale leverage scores
        for (FSize i = 0; i < size; ++i)
            samplingProbabilities[i]/=FReal(nbSampledIndices);
    }
    else 
        throw std::runtime_error("Invalid flag for sampling technique.");

    // Sample given probabilities
    sampleIndicesGivenProbabilities(size,samplingProbabilities,nbSampledIndices,sampledIndices,withReplacement);

    // Sort subsampled indices
    std::sort(sampledIndices,sampledIndices+nbSampledIndices);

    //// Display sampledIndices
    //Display::vector(rank,sampledIndices,"sampledIndices",10,1);

    // Control multiplicity
    controlMultiplicity(size,nbSampledIndices,sampledIndices);

    // Display sampledIndices
    Display::vector(nbSampledIndices,sampledIndices,"sampledIndices",10,1);

    // Free memory
    delete [] samplingProbabilities;

}


/*
 * sampleIndicesAdaptively
 *
 * Sample "rank" indices from 0 to "size-1" using sampling probabilities: constant or proportionnal to leverage scores.
 *
 * 
 */
static void sampleIndicesAdaptively(const FSize size, const FSize rank, /*const*/ FReal* M, const FSize nbInitSampledIndices, const FSize nbExtraSampledIndices, FSize* &sampledIndices, const int samplingTechnique, const bool withReplacement){

    FAssertLF(rank<=size);
    //
    const FSize nbSampledIndices = nbInitSampledIndices + nbExtraSampledIndices;
    //
    FAssertLF(nbSampledIndices<=rank);

    // Subsampled indices
    sampledIndices = new FSize[nbSampledIndices];

    // Compute initial sampled indices
    FSize* initSampledIndices = NULL;
    //
    sampleIndices(size,rank, M, nbInitSampledIndices, initSampledIndices,samplingTechnique,withReplacement);
    //
    // Copy init sampled indices and delete
    for (FSize i = 0; i < nbInitSampledIndices; ++i)
        sampledIndices[i]=initSampledIndices[i];
    delete[] initSampledIndices;

    // Adaptive sampling (Perform new sampling with probabilities proportionnal to the residuals of previous selection)

    // [TODO] Fix adaptive sampling
    // 1: How do we setup nbInitSampledIndices and nbExtraSampledIndices??
    // 2: Do we eliminate duplicates??
    // 3: Beware! This adaptive sampling seems to be designed for the improved Nystrom decomposition (U=(C^+)M(C^+)T), 
    // it actually gives a better col selection such that CC^+M close to M. Hence, if matrix is symmetric then CC^+M(CC^+)^T also close to M.
    // Does it also applies to U=W^+
    // [TODO] Find a way to return C^+ (or C^+M), since it is needed for the intersection matrix.
    // [TODO] Implement near optimal col selection (Uses random projection!!!)

    // Declare sampling probabilities
    FReal* samplingProbabilities = new FReal[size];

    // Compute residuals 
    Residuals::compute(size,size,M,nbInitSampledIndices,sampledIndices,samplingProbabilities);

    // ... scale residuals
    for (FSize i = 0; i < size; ++i)
        samplingProbabilities[i]/=FReal(size);

    // Sample given probabilities
    FSize* extraSampledIndices = new FSize[nbExtraSampledIndices];
    sampleIndicesGivenProbabilities(size,samplingProbabilities,nbExtraSampledIndices,extraSampledIndices,withReplacement);

    // Display sampledIndices
    Display::vector(nbExtraSampledIndices,extraSampledIndices,"extraSampledIndices",10,1);

    // copy indices
    for (FSize i = 0; i < nbExtraSampledIndices; ++i)
        sampledIndices[nbInitSampledIndices+i]=extraSampledIndices[i];

    // Sort subsampled indices
    std::sort(sampledIndices,sampledIndices+nbSampledIndices);

    // Avoid duplicates? 
    // ...

    // Display sampledIndices
    Display::vector(nbSampledIndices,sampledIndices,"sampledIndices",10,1);

    // Free memory
    delete [] samplingProbabilities;

}



/*
 * sampleIndicesUniformly
 *
 * Sample "rank" indices from 0 to "size-1" uniformly at random.
 * 
 */
static void sampleIndicesUniformlyAtRandom(const FSize size, const FSize nbSampledIndices, FSize* &sampledIndices, const bool withReplacement){

    const FSize dummy_rank = 0;
    sampleIndices(size, dummy_rank, NULL /*matrix not needed for uniform sampling*/, nbSampledIndices, sampledIndices, 0 /*uniform sampling*/, withReplacement);

}




};


#endif // RANDOMSAMPLER_HPP
