#ifndef RESIDUALS_HPP
#define RESIDUALS_HPP


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator
#include <algorithm> // for sort

#include <array> // for std::array initDistribution

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

#include "Utils/MatrixIO.hpp" // for input/output matrix-file
#include "Utils/VectorNorms.hpp" // for leverage scores

#include "Utils/Display.hpp" // In order to display vectors and arrays

#include "Sampling/Extractor.hpp" // for columns extraction

#include "StandardLRA/PseudoInverse.hpp" // for C^+ 

//// ... for exact leverage scores
//#include "StandardLRA/SVD.hpp" 
//// ... for approximate leverage scores
//#include "RandomizedLRA/AdaptiveRandomizedRangeFinder.hpp"
//#include "RandomizedLRA/RandomizedRangeFinder.hpp"
//#include "RandomizedLRA/RandSVD.hpp"
//// ... for Dense Matrix Multiplication
//#include "MatrixWrappers/DenseWrapper.hpp"



/**
 * @brief The Residuals namespace
 *
*/
namespace Residuals
{



/*
 * compute()
 *
 * Compute residuals. 
 * Return array containing residuals
 * 
 */
static void compute(const FSize nbRows, const FSize nbCols, /*const*/ FReal* M, const FSize nbSampledCols, const FSize* sampledColsIdx, FReal* &residuals){

    std::cout << "\nCompute sampling probabilities based on residuals, d_i=||D_i||_2^2 ... ";

    // Allocate memory
    residuals = new FReal[nbCols];

    // Extract sampled columns
    FTic timeExtractC;
    double tExtractC;

    std::cout << "\nExtract C... ";
    timeExtractC.tic();

    FReal* sampledCols = new FReal[nbRows*nbSampledCols];

    Extractor::extractCols(nbRows,nbCols,M,nbSampledCols,sampledColsIdx,sampledCols); 

    tExtractC = timeExtractC.tacAndElapsed();
    std::cout << "... took @tExtractC = "<< tExtractC <<"\n";

    // Compute I-CC^+
    FTic timeD;
    double tD;

    std::cout << "\nCompute residual matrix D=(I-CC^+)M... ";
    timeD.tic();

    // Compute C^+, pseudo inverse of C
    FReal *const sampledColsPlus = new FReal [nbSampledCols*nbRows];
    // C^+ contains rank first columns 
    FSize rank = PseudoInverse::compute(nbRows,nbSampledCols,sampledCols,sampledColsPlus);
    // Compute C^+M
    FReal *const CPlusM = new FReal[/*nbSampledCols*/rank*nbCols];
    FBlas::setzero(int(/*nbSampledCols*/rank*nbCols),CPlusM);
    for ( FSize i=0; i</*nbSampledCols*/rank; ++i)
        for ( FSize j=0; j<nbCols; ++j)
            for ( FSize k=0; k<nbRows; ++k)
                CPlusM[i+j*nbSampledCols]+=sampledColsPlus[i+k*nbSampledCols]*M[k+j*nbRows];     

    // D = (I-CC^+)M
    FReal *const D = new FReal[nbRows*nbCols];
    FBlas::setzero(int(nbRows*nbCols),D);
    for ( FSize i=0; i<nbRows; ++i)
        for ( FSize j=0; j<nbCols; ++j)
        {
            D[i+j*nbRows]=M[i+j*nbRows];
            for ( FSize k=0; k<rank/*nbSampledCols*/; ++k)
                D[i+j*nbRows]-=sampledCols[i+k*nbRows]*CPlusM[k+j*nbSampledCols];
        }
    tD = timeD.tacAndElapsed();
    std::cout << "... took @tD = "<< tD <<"\n";

    // Display projection
    Display::matrix(nbRows,nbCols,D,"D=(I-CC^+)M",10);

    // Compute residuals norm
    FTic timeNormD;
    double tNormD;
    std::cout << "\nCompute norm of the rows of D ... ";
    timeNormD.tic();
    // Compute norms of each line of U^T
    VectorNorms<FReal>* colsNorm = new VectorNorms<FReal>[nbCols];
    FReal squaredFrobNormD = FReal(0.);
    for (int j = 0; j < nbCols; ++j){ // For each col D_j of D
        // reset vector norm
        colsNorm[j].reset();
        // Compute the norm of D_j
        for (FSize i = 0; i < nbRows; ++i) 
        {
            colsNorm[j].add(D[i+j*nbRows]);
        }
        residuals[j]=colsNorm[j].getTwo();
        squaredFrobNormD+=residuals[j];
    }
    for (int j = 0; j < nbCols; ++j)
        residuals[j]/=squaredFrobNormD;
    
    tNormD = timeNormD.tacAndElapsed();
    std::cout << "... took @tNormD = "<< tNormD <<"\n";

    //if(verbose){
    const int displaySize=10;
    Display::vector(nbCols,residuals,"res",displaySize,1);
    //}

    // free memory
    delete [] CPlusM;
    delete [] D;

}

};


#endif // RESIDUALS_HPP

