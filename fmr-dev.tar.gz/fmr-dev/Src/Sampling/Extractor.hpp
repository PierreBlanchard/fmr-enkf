#ifndef EXTRACTOR_HPP
#define EXTRACTOR_HPP


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator
#include <algorithm> // for sort

#include <array> // for std::array initDistribution

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

#include "Utils/MatrixIO.hpp" // for input/output matrix-file
#include "Utils/VectorNorms.hpp" // for leverage scores

#include "Utils/Display.hpp" // In order to display vectors and arrays

// ... for exact leverage scores
#include "StandardLRA/SVD.hpp" 
// ... for approximate leverage scores
#include "Sampling/LeverageScores.hpp"
//#include "RandomizedLRA/AdaptiveRandomizedRangeFinder.hpp"
//#include "RandomizedLRA/RandomizedRangeFinder.hpp"
//#include "RandomizedLRA/RandSVD.hpp"
// ... for Dense Matrix Multiplication
#include "MatrixWrappers/DenseWrapper.hpp"



/**
 * @brief The Extractor namespace
 *
*/
namespace Extractor
{


    /*
     * extractWAndC
     *
     * Returns W=SMS^T and C=MS^T if S is the Sampling matrix corresponding to input permutations.
     * 
     */
    void extractWAndC(const FSize size, const FSize rank, const FReal* M, FReal* &C, FReal* &W, const FSize* permutation){
     
        // Extract submatrix W
        W = new FReal[rank*rank];
        for (int i = 0; i < rank; ++i)
            for (int j = 0; j < rank; ++j)
            {
                W[i+j*rank] = M[permutation[i]+permutation[j]*size];
            }

        // Extract sampled columns WITHOUT reordering rows
        C = new FReal[rank*size];  
        for (int j = 0; j < rank; ++j)
            FBlas::copy(int(size),M+permutation[j]*size,C+j*size);

        //// Display W
        //const FSize displaySize = FSize(10);
        //Display::matrix(rank,rank,W,"W",displaySize);
        //// Display C
        //Display::matrix(size,rank,C,"sampledCols",displaySize);

    }

    /*
     * extractW
     *
     * Returns set of uniformly sampled rows. Columns are reordered!
     * 
     */
    void extractW(const FSize size, const FSize rank, const FReal* M, FReal* &sampledRows, const FSize* permutation){

        // Extract submatrix W
        sampledRows = new FReal[rank*size];  
        for (int i = 0; i < rank; ++i)
            for (int j = 0; j < size; ++j)
            {
                sampledRows[i+j*rank] = M[permutation[i]+permutation[j]*size];
            }

    }


    /*
     * extractRows
     *
     * Returns R=SM if S is the sampling matrix corresponding to the input permutation vector.
     * 
     */
    void extractRows(const FSize nbRows, const FSize nbCols, const FReal* M, const FSize nbSampledRows, const FSize* permutation, FReal* &sampledRows){
     
        // Extract sampled rows WITHOUT reordering cols
        sampledRows = new FReal[nbSampledRows*nbCols];  
        for (int i = 0; i < nbSampledRows; ++i)
            for (int j = 0; j < nbCols; ++j)
                sampledRows[i+j*nbSampledRows]=M[permutation[i]+j*nbRows];

        //// Display sampled rows
        //Display::matrix(nbSampledRows,nbCols,sampledRows,"sampledRows",displaySize);

    }

    /*
     * extractCols
     *
     * Returns C=MS^T if S is the sampling matrix corresponding to the input permutation vector.
     * 
     */
    void extractCols(const FSize nbRows, const FSize /*nbCols*/, const FReal* M, const FSize nbSampledCols, const FSize* permutation, FReal* &sampledCols){
     
        // Extract sampled rows WITHOUT reordering cols
        sampledCols = new FReal[nbRows*nbSampledCols];
        for (int i = 0; i < nbRows; ++i)
            for (int j = 0; j < nbSampledCols; ++j)
                sampledCols[i+j*nbRows]=M[i+permutation[j]*nbRows];

        //// Display sampled rows
        //Display::matrix(nbRows,nbSampledCols,sampledCols,"sampledCols",displaySize);

    }

};


#endif // EXTRACTOR_HPP
