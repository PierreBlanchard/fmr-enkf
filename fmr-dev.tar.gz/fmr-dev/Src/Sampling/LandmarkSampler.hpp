#ifndef LANDMARKSAMPLER_HPP
#define LANDMARKSAMPLER_HPP


#include "Utils/FGlobal.hpp"
#include "Utils/FLog.hpp"

#include "SimpleSamplers.hpp"
#include "deterministicSampler.hpp"



/**
* @author Pierre Blanchard (pierre.blanchard@inria.fr)
* @class LandmarkSampler
* @brief This class defines a method to sample column indices 
* using centroids returned by a k-cluster algorithm, a.k.a. the landmark sampling.
*
* 
* 
*/

// probably not extendable
enum DATA_TYPE {DISTANCE, GRID};

template<class FReal, class FSize, DATA_TYPE TYPE> class LandmarkSampler;

template<class FReal, class FSize, GRID>
class LandmarkSampler : public SimpleSamplers<FReal,FSize> {
    typedef SimpleSamplers<FReal,FSize> AbstractBaseClass;
protected:
    // Various dimensions
    const FSize nbRows;
    const FSize nbCols;
    const FSize rank;
    const FSize nbSampledIndices;
    // Various options
    //const bool withReplacement;  //< 0: without; 1: with
    // Arrays
    //FReal* samplingProbabilities;
public:
    /** Default ctor */
    LandmarkSampler(const FSize in_nbRows, const FSize in_nbCols, const FSize in_rank, const FSize in_nbSampledIndices, const FReal* in_Grid)
    : AbstractBaseClass(in_nbRows,in_nbCols,in_rank,in_nbSampledIndices), 
      nbRows(in_nbRows), nbCols(in_nbCols), rank(in_rank), nbSampledIndices(in_nbSampledIndices)//, withReplacement(in_withReplacement)
    {
        // Allocate memory for sampledIndices
//        samplingProbabilities = new FReal[nbCols];
    }

    /** Default destructor */
    ~LandmarkSampler(){
        // free memory
        
    }

    /**
    * sampleIndices
    * Select row/column indices.
    * @param 
    *
    * [TODO] Sample from Distance matrix using k-medoids
    * [TODO] Sample from Grid using k-means or efficient k-means (How do we get centroid?)
    * 
    * 
    */
    void sampleIndices(){}
   

    void sampleIndices(FReal* D){

        std::cout<< "Perform clustering using K-Medoids: " ;
        FTic timeKMedoids;
        double tKMedoids;
        timeKMedoids.tic();

        const int nbPasses = 5;
        const int nbPartitions = int(nbSampledIndices);
        const int nbElements = int(nbCols);

        /// Run k-medoids
        FCCLKCluster<ValueClass> partitioner(nbPartitions, nbElements, D, nbPasses);

        /// Get important columns using partitions centroids

        // Get centroids
        std::unique_ptr<int[]> centroidsIdx(new int[nbElements]);
        partitioner.getCentroidsIdx(nbElements,centroidsIdx.get());
        // Copy centroids indices into sorted centroids indices
        int* sortedCentroidsIdx = new int[nbElements];
        for (FSize i = 0; i < nbElements; ++i)
            sortedCentroidsIdx[i]=int(centroidsIdx.get()[i]);
        // Sort centroid indices
        std::sort(sortedCentroidsIdx,sortedCentroidsIdx+nbElements);

        // Copy centroids into sampled indices
        sampledIndices[0]=sortedCentroidsIdx[0];
        int countPartitions=1;
        for (FSize i = 1; i < nbElements; ++i){
            if(sortedCentroidsIdx[i]!=sortedCentroidsIdx[i-1]){
                sampledIndices[countPartitions++]=FSize(sortedCentroidsIdx[i]);
            }
        }
        FAssertLF(nbPartitions == countPartitions);

        tKMedoids = timeKMedoids.tacAndElapsed();
        std::cout << "... took @tKMedoids = "<< tKMedoids <<"\n";

    }

};


#endif // LANDMARKSAMPLER_HPP