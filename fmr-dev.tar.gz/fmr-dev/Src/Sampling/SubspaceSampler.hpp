#ifndef SUBSPACESAMPLER_HPP
#define SUBSPACESAMPLER_HPP


#include "Utils/FGlobal.hpp"
#include "Utils/FLog.hpp"

#include "SimpleSamplers.hpp"
#include "UniformSampler.hpp"
#include "randomSampler.hpp"

// ... for approximate leverage scores
#include "Sampling/LeverageScores.hpp"

/**
* @author Pierre Blanchard (pierre.blanchard@inria.fr)
* @class SubspaceSampler
* @brief This class defines a method to sample column indices 
* with probabilitiesorportionnal to leverage scores, a.k.a. the subspace sampling.
*
* NB: lev scores are approximated using randSVD with a prescribed rank = N/10 ? rank ?
*
* [TODO] Return indices with largest probabilities and evaluate probability to select one of these.
* 
*/
template<class FReal, class FSize>
class SubspaceSampler : public UniformSampler<FReal,FSize> {
    typedef UniformSampler<FReal,FSize> UniformSamplerClass;
protected:
    // Various dimensions
    const FSize nbRows;
    const FSize nbCols;
    const FSize rank;
    const FSize nbSampledIndices;
    // Various options
    const bool withReplacement;  //< 0: without; 1: with
    // Arrays

public:
    /** Default ctor */
    SubspaceSampler(const FSize in_nbRows, const FSize in_nbCols, const FSize in_rank, const FSize in_nbSampledIndices, const bool in_withReplacement)
    : UniformSamplerClass(in_nbRows,in_nbCols,in_rank,in_nbSampledIndices,in_withReplacement),
      nbRows(in_nbRows), nbCols(in_nbCols), rank(in_rank), nbSampledIndices(in_nbSampledIndices), withReplacement(in_withReplacement)
    {
        // samplingProbabilities are declared in UniformClass ([TODO] Define an AbstractRandomSamplerClass)
        // sampledIndices are declare in SimpleSamplerClass
    }

    /**
    * updateProbabilities
    * Update probabilities, set to constant value.
    * @param 
    * 
    * [TODO] Provide matrix wrapper in order to handle fast randSVD (e.g. parallel, subsampled or FMM)    
    
    */
    void updateProbabilities(/*const*/ FReal* dataMatrix) {
        // ... compute leverage scores
        LeverageScores::computeScoresOnly(nbCols,nbSampledIndices,dataMatrix,UniformSamplerClass::samplingProbabilities,1/*ranSVD*/); // [TODO] Do we need to pass the target rank??
        // ... scale leverage scores
        for (FSize i = 0; i < nbCols; ++i)
            UniformSamplerClass::samplingProbabilities[i]/=FReal(nbSampledIndices);
    }

};


#endif //SUBSPACESAMPLER_HPP