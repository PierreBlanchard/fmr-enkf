#ifndef UNIFORMSAMPLER_HPP
#define UNIFORMSAMPLER_HPP


#include "Utils/FGlobal.hpp"
#include "Utils/FLog.hpp"

#include "SimpleSamplers.hpp"
#include "randomSampler.hpp"


/**
* @author Pierre Blanchard (pierre.blanchard@inria.fr)
* @class UniformSampler
* @brief This class defines a method to sample column indices 
* with constant probabilities, a.k.a. the uniform sampling.
*
*/
template<class FReal, class FSize>
class UniformSampler : public SimpleSamplers<FReal,FSize> {
    typedef SimpleSamplers<FReal,FSize> AbstractBaseClass;
protected:
    // Various dimensions
    const FSize nbRows;
    const FSize nbCols;
    const FSize rank;
    const FSize nbSampledIndices;
    // Various options
    const bool withReplacement;  //< 0: without; 1: with
    // Arrays
    FReal* samplingProbabilities;
public:
    /** Default ctor */
    UniformSampler(const FSize in_nbRows, const FSize in_nbCols, const FSize in_rank, const FSize in_nbSampledIndices, const bool in_withReplacement)
    : AbstractBaseClass(in_nbRows,in_nbCols,in_rank,in_nbSampledIndices), 
      nbRows(in_nbRows), nbCols(in_nbCols), rank(in_rank), nbSampledIndices(in_nbSampledIndices), withReplacement(in_withReplacement)
    {
        // Allocate memory for sampledIndices
        samplingProbabilities = new FReal[nbCols];
    }

    /** Default destructor */
    ~UniformSampler(){
        // free memory
        delete [] samplingProbabilities;
    }

    /**
    * updateProbabilities
    * Update probabilities, set to constant value.
    * @param 
    * 
    */
    void updateProbabilities() {
        // Compute sampling probabilities
        for (FSize i = 0; i < nbCols; ++i)
            samplingProbabilities[i]=FReal(1.)/FReal(nbCols);
    }

    /**
    * sampleIndices
    * Select row/column indices.
    * @param 
    * 
    */
    void sampleIndices(){

        // Sample given probabilities
        randomSampler::sampleIndicesGivenProbabilities(nbCols,samplingProbabilities,nbSampledIndices,AbstractBaseClass::sampledIndices,withReplacement);

        // Sort subsampled indices
        std::sort(AbstractBaseClass::sampledIndices,AbstractBaseClass::sampledIndices+nbSampledIndices);

        //// Display sampledIndices
        //Display::vector(rank,sampledIndices,"sampledIndices",10,1);

        // Control multiplicity
        randomSampler::controlMultiplicity(nbCols,nbSampledIndices,AbstractBaseClass::sampledIndices);

        // Display sampledIndices
        Display::vector(nbSampledIndices,AbstractBaseClass::sampledIndices,"sampledIndices",10,1);

    }

};


#endif //UNIFORMSAMPLER_HPP