#ifndef SIMPLESAMPLERS_HPP
#define SIMPLESAMPLERS_HPP


#include "Utils/FGlobal.hpp"
#include "Utils/FLog.hpp"

#include "Utils/FSmartPointer.hpp"

#include "AbstractSamplers.hpp"

/**
* @author Pierre Blanchard (pierre.blanchard@inria.fr)
* @class SimpleSamplers
* @brief This class defines what any sampler has to implement,
* that does not depend on the sampling technique, e.g. accessor to/dtor of/writer of vector of sampled indices
*
* 
* It is better to inherit from this class even if it is not obligatory thanks to
* the templates. But inheriting will force your class to have the correct parameters
* especially if you use the override keyword.
*
* You can find an example of implementation in FBasicSamplers.
*/
template<class FReal, class FSize>
class SimpleSamplers : public AbstractSamplers<FReal,FSize> {
protected:
    const FSize nbRows; //< number of rows in input matrix
    const FSize nbCols; //< number of cols in input matrix
    const FSize rank; //< rank of low-rank approximation ([TODO] Define only in required samplers, e.g. LevScores, NearOpt, ...)
    const FSize nbSampledIndices;
    FSize* sampledIndices;

public:
    /** Default ctor */
    SimpleSamplers(const FSize in_nbRows, const FSize in_nbCols, const FSize in_rank, const FSize in_nbSampledIndices)
    : nbRows(in_nbRows), nbCols(in_nbCols), rank(in_rank), nbSampledIndices(in_nbSampledIndices) 
    {
        // Allocate memory for sampledIndices
        sampledIndices = new FSize[nbSampledIndices];
    }

    /** Default destructor */
    ~SimpleSamplers(){
        // free memory
        delete [] sampledIndices;
    }

    /**
    * sampleIndices
    * Select row/column indices.
    * @param 
    * 
    */
    virtual void sampleIndices() = 0;

    /**
    * getSampledIndices
    * Get sampled indices
    * @param  
    * 
    */
    const FSize* getSampledIndices(){
        return sampledIndices;
    }

    /**
    * writeIndices
    * Write indices in file.
    * @param 
    *
    */
    void writeIndices(const std::string filename){
        
        std::ofstream file(filename);

        // Write header SINGVALS
        file << "IDX" << "\n";

        // Write sampled indices
        for(int row = 0; row < nbSampledIndices; ++row)
        {
            file << sampledIndices[row] << "\n";
        }
        file.close();
    }

};


#endif //SIMPLESAMPLERS_HPP