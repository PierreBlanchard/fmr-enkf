#ifndef DETERMINISTIC_SAMPLER_HPP
#define DETERMINISTIC_SAMPLER_HPP


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator
#include <algorithm> // for sort

#include <array> // for std::array initDistribution

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

#include "Utils/MatrixIO.hpp" // for input/output matrix-file
#include "Utils/VectorNorms.hpp" // for leverage scores

#include "Utils/Display.hpp" // In order to display vectors and arrays

// ... for uniform sampling of indices
#include "Sampling/randomSampler.hpp"
#include "Sampling/Extractor.hpp"
// ... for QRD
#include "StandardLRA/QRD.hpp"
// ... for Dense Matrix Multiplication
#include "MatrixWrappers/DenseWrapper.hpp"


// HMAT specific includes for local landmarks (kcluster and kmedoids)
#include "ScalFmm/HMat/Src/Clustering/FCCLKCluster.hpp"
#include "ScalFmm/HMat/Src/Utils/FMatrixIO.hpp"
#include "ScalFmm/HMat/Src/Containers/FPartitionsMapping.hpp"
#include "ScalFmm/HMat/Src/Utils/FSvgRect.hpp"
#include "ScalFmm/HMat/Src/Viewers/FDenseBlockWrapper.hpp"
#include "ScalFmm/HMat/Src/Blocks/FDenseBlock.hpp"


/**
 * @brief The deterministicSampler namespace
 *
 * Those samplin routines are deterministic in the sense that they produce indices based on determinisitic techniques. 
 * Though, they may involve randomized techniques such as random subsampling (uniform for Engquist), they don't purely rely on drawing indices using sampling probabilities.
 *
*/
namespace deterministicSampler
{

/*
 * alternatePivotedQRD
 *
 * Select important columns in M (m x n) by applying algorithm from Engquist and Ying [REF]
 * 
 * 1) Get important columns. 
 * Uniformly sample r rows from M , and denote the index set as Γ_r . 
 * Apply a pivoted QR factorization on M Γ r ,: to get the top r important column indices, denoted as Π c . 
 * 2) Get important rows. 
 * Uniformly sample l columns, and denote the index set as Γ c . 
 * Update Π c = Γ c ∪ Π c . 
 * Apply a pivoted LQ factorization on M :,Π c to get the top r + l important row index set, denoted as Π r . 
 * 3) Update important columns. 
 * Uniformly sample l rows, and denote the index set as Γ r. 
 * Update Π r = Π r ∪ Γ r . 
 * Apply a pivoted QR factorization on M Π r ,: to get the top r important columns.
 * 
 */
static void alternatePivotedQRD(const FSize nbRows, const FSize nbCols, /*const*/ FReal* M, const FSize nbSampledIndices, FSize* &sampledIndices){

    // Set oversampling to nbSampledIndices or less
    const FSize overSampling = nbSampledIndices;
    const FSize osNbSampledIndices=nbSampledIndices+overSampling;
    // Get Important Columns
    std::cout << "\nGet important cols...";
    // ... sample r rows uniformly
    FSize* Gamma_r = NULL;// new FSize[nbSampledIndices]; 
    randomSampler::sampleIndicesUniformlyAtRandom(nbRows,nbSampledIndices,Gamma_r,0); // uniformly at random without replacement
    // ... extract sampled rows
    FReal* sampledRows = NULL;
    Extractor::extractRows(nbRows,nbCols,M,nbSampledIndices,Gamma_r,sampledRows);
    // ... apply pivoted QR to sampled matrix 
    FSize* tmpPi_c = NULL;//new FSize[osNbSampledIndices];
    QRD<FReal>::computePivotedQRD(nbSampledIndices,nbCols,sampledRows,nbSampledIndices,tmpPi_c);

    // Get Important Rows
    std::cout << "\nGet important rows...";
    // ... sample os cols uniformly
    FSize* Gamma_c = NULL;// new FSize[overSampling];
    randomSampler::sampleIndicesUniformlyAtRandom(nbCols,overSampling,Gamma_c,0); // uniformly at random without replacement
    // Beware!!! What if some indices are sampled twice?? Avoid that?? e.g. using multiplicity concept.
    // ... update Pi_c
    FSize* Pi_c = new FSize[osNbSampledIndices];
    for (FSize i = 0; i < nbSampledIndices; ++i)
        Pi_c[i]=tmpPi_c[i];
    for (FSize i = 0; i < overSampling; ++i)
        Pi_c[nbSampledIndices+i]=Gamma_c[i];
    std::sort(Pi_c,Pi_c+osNbSampledIndices);
    //Display::vector(osNbSampledIndices,Pi_c,"Pi_c",10,1);
    // Free memory
    delete [] Gamma_c;
    delete [] tmpPi_c;
    // ... extract sampled cols
    FReal* sampledCols = NULL;
    Extractor::extractCols(nbRows,nbCols,M,osNbSampledIndices,Pi_c,sampledCols);
    // Free memory
    delete [] Pi_c;
    // ... transpose sampled cols
    FReal* transposedSampledCols = new FReal[osNbSampledIndices*nbRows];

    for (FSize i = 0; i < osNbSampledIndices; ++i)
        for (FSize j = 0; j < nbRows; ++j)
            transposedSampledCols[i+j*osNbSampledIndices]=sampledCols[j+i*nbRows];
    // free memory
    delete [] sampledCols;
    // ... apply pivoted QR to transposed sampled cols 
    FSize* tmpPi_r = NULL;//new FSize[osNbSampledIndices];
    QRD<FReal>::computePivotedQRD(osNbSampledIndices,nbRows,transposedSampledCols,osNbSampledIndices,tmpPi_r);
    // free memory
    delete [] transposedSampledCols;

    // Update Important Columns
    std::cout << "\nUpdate important cols...";
    // ... sample os rows uniformly
    delete [] Gamma_r;
    Gamma_r = NULL;// new FSize[os];
    randomSampler::sampleIndicesUniformlyAtRandom(nbRows,overSampling,Gamma_r,0); // uniformly at random without replacement
    // ... update Pi_r
    FSize* Pi_r = new FSize[osNbSampledIndices];
    for (FSize i = 0; i < nbSampledIndices; ++i)
        Pi_r[i]=tmpPi_r[i];
    for (FSize i = 0; i < overSampling; ++i)
        Pi_r[nbSampledIndices+i]=Gamma_r[i];
    std::sort(Pi_r,Pi_r+osNbSampledIndices);
    //Display::vector(osNbSampledIndices,Pi_r,"Pi_r",10,1);
    // Free memory
    delete [] Gamma_r;
    delete [] tmpPi_r;
    // ... extract sampled rows
    delete [] sampledRows;
    sampledRows = NULL;
    Extractor::extractRows(nbRows,nbCols,M,nbSampledIndices,Pi_r,sampledRows);
    // ... apply pivoted QR to sampled matrix 
    QRD<FReal>::computePivotedQRD(osNbSampledIndices,nbCols,sampledRows,nbSampledIndices,sampledIndices);

    // Free memory
    delete [] Pi_r;
    delete [] sampledRows;

}



/*
 * localLandmarks
 *
 * Select k columns corresponding to the k centroids of a k-clusters algorithm (based on distance matrix or distance computed from data)
 *
 * Our MDS applications usually involves integer valued distances, therefore we templatized with respect to ValueClass (single or double floats). 
 * TODO implement my own integer valued k-means (Based on eff_kmeans from Wang Matlab tuto) or k-medoids
 * 
 */
template<class ValueClass>
static void localLandmarks(const FSize size, /*const*/ ValueClass* D, const FSize nbSampledIndices, FSize* &sampledIndices){


        std::cout<< "Perform clustering using K-Medoids: " ;
        FTic timeKMedoids;
        double tKMedoids;
        timeKMedoids.tic();

        const int nbPasses = 5;
        const int nbPartitions = int(nbSampledIndices);
        const int nbElements = int(size);

        /// Run k-medoids
        FCCLKCluster<ValueClass> partitioner(nbPartitions, nbElements, D, nbPasses);

        /// Get important columns using partitions centroids

        // Get centroids
        std::unique_ptr<int[]> centroidsIdx(new int[nbElements]);
        partitioner.getCentroidsIdx(nbElements,centroidsIdx.get());
        // Copy centroids indices into sorted centroids indices
        int* sortedCentroidsIdx = new int[nbElements];
        for (FSize i = 0; i < nbElements; ++i)
            sortedCentroidsIdx[i]=int(centroidsIdx.get()[i]);
        // Sort centroid indices
        std::sort(sortedCentroidsIdx,sortedCentroidsIdx+nbElements);

        // Copy centroids into sampled indices
        sampledIndices[0]=sortedCentroidsIdx[0];
        int countPartitions=1;
        for (FSize i = 1; i < nbElements; ++i){
            if(sortedCentroidsIdx[i]!=sortedCentroidsIdx[i-1]){
                sampledIndices[countPartitions++]=FSize(sortedCentroidsIdx[i]);
            }
        }
        FAssertLF(nbPartitions == countPartitions);

        tKMedoids = timeKMedoids.tacAndElapsed();
        std::cout << "... took @tKMedoids = "<< tKMedoids <<"\n";

}



/*
 * sampleIndices (dispatcher)
 *
 * Sample "rank" indices from 0 to "size-1" using deterministic algorithm: 
 * - [DONE] Engquist & Ying: random subsampling + alternatePivotedQRD
 * - [DONE] Zhang: k-means (local landmarks)
 * - [TODO] Stewart incremental
 * 
 */
static void sampleIndices(const FSize size, const FSize /*rank*/, /*const*/ FReal* M, const FSize nbSampledIndices, FSize* &sampledIndices, const int samplingTechnique){

    // Subsampled indices
    sampledIndices = new FSize[nbSampledIndices];

    // Compute sampling probabilites
    if(samplingTechnique==2){ // Engquist & Ying 
        alternatePivotedQRD(size,size,M,nbSampledIndices,sampledIndices);
    }
    else if(samplingTechnique==3){ // Local Landmarks (i.e. K-means or K-medoids)
        localLandmarks(size,M,nbSampledIndices,sampledIndices);
    }
    else if(samplingTechnique==4){ // Stewart
        // [TODO]
    }
    else 
        throw std::runtime_error("Invalid flag for sampling technique.");


    // Display sampledIndices
    Display::vector(nbSampledIndices,sampledIndices,"sampledIndices",10,1);

}


};


#endif // DETERMINISTIC_SAMPLER_HPP
