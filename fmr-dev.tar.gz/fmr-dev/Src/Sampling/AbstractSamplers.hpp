#ifndef ABSTRACTSAMPLERS_HPP
#define ABSTRACTSAMPLERS_HPP


#include "Utils/FGlobal.hpp"
#include "Utils/FLog.hpp"

/**
* @author Pierre Blanchard (pierre.blanchard@inria.fr)
* @class FAbstractSamplers
* @brief This class defines what any sampler has to implement.
*
* 
* It is better to inherit from this class even if it is not obligatory thanks to
* the templates. But inheriting will force your class to have the correct parameters
* especially if you use the override keyword.
*
* You can find an example of implementation in FBasicSamplers.
*/
template<class FReal, class FSize>
class AbstractSamplers{
public:
    /** Default destructor */
    virtual ~AbstractSamplers(){}

    /**
    * sampleIndices
    * Select row/column indices.
    * @param 
    * 
    */
    virtual void sampleIndices() = 0;

    /**
    * getSampledIndices
    * Get sampled indices
    * @param  
    * 
    */
    virtual const FSize* getSampledIndices() = 0;

    /**
    * writeIndices
    * Write indices in file.
    * @param 
    *
    */
    virtual void writeIndices(const std::string filename) = 0;

};


#endif //ABSTRACTSAMPLERS_HPP