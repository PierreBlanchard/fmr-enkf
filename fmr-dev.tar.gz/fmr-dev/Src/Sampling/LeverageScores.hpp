#ifndef LEVERAGESCORES_HPP
#define LEVERAGESCORES_HPP


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator
#include <algorithm> // for sort

#include <array> // for std::array initDistribution

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

#include "Utils/MatrixIO.hpp" // for input/output matrix-file
#include "Utils/VectorNorms.hpp" // for leverage scores

#include "Utils/Display.hpp" // In order to display vectors and arrays

// ... for exact leverage scores
#include "StandardLRA/SVD.hpp" 
// ... for approximate leverage scores
#include "RandomizedLRA/AdaptiveRandomizedRangeFinder.hpp"
#include "RandomizedLRA/RandomizedRangeFinder.hpp"
#include "RandomizedLRA/RandSVD.hpp"
// ... for Dense Matrix Multiplication
#include "MatrixWrappers/DenseWrapper.hpp"

/**
 * @brief The LeverageScores namespace
 *
 * [TODO] rectangular matrices!
 * 
*/
namespace LeverageScores
{



/*
 * compute()
 *
 * Compute leverage scores. Using either SVD or RandSVD (approx leverage scores).
 * Return scores, stats and singular vectors.
 *
 * [TODO] rectangular matrices!
 * 
 */
static void computeU(const FSize size, const FSize rank, /*const*/ FReal* C, FReal* &U, const int fSVD){

    // Allocate memory
    FReal* Sigma = NULL;

    if(fSVD==0){ // Full SVD
        std::cout << "\n... using full SVD... ";
        U = new FReal[size*size];
        Sigma = new FReal[size];
        SVD<FReal>::computeSYMSVD(size,C,Sigma,U);
    }
    else if(fSVD==1){ // Randomized SVD (Fixed rank)
        std::cout << "\n... using randomized SVD... ";
        typedef DenseWrapper<FReal> DenseWrapperClass;
        typedef RRF<FReal,DenseWrapperClass> Dense_RRFClass;
        //typedef AdaptiveRRF<FReal,DenseWrapperClass> Dense_ARRFClass;

        std::cout << "\nInit Randomized SVD ... \n";
        FTic timeInitRandSVD;
        double tInitRSVD;
        timeInitRandSVD.tic();
        //
        // Init RRF algorithm
        // 
        // Dense Wrapper
        DenseWrapperClass* DenseMatrixWrapper = new DenseWrapperClass(size,size,true);
        DenseMatrixWrapper->init(C);
        // RRF
        Dense_RRFClass RandRangeFinder(DenseMatrixWrapper,rank,rank,0/*qRSI*/,false); // oversampling = rank, no subspace iteration, do not verif MMP (since direct MMP)
        RandSVD<FReal,Dense_RRFClass> RSVD(size,size,&RandRangeFinder);
        tInitRSVD = timeInitRandSVD.tacAndElapsed();
        std::cout << "... took @tInitRSVD = "<< tInitRSVD <<"\n";
        //
        std::cout << "\nPerform Randomized SVD ... ";
        // RandSVD
        const bool readW=false;
        const FSize orank = RSVD.computeFACT(readW/*readW*/);
        if(orank!=rank) throw std::runtime_error("Output rank different from input rank...");
        // Get approx. singular values
        Sigma = new FReal[rank];
        FBlas::copy(int(rank),RSVD.getApproxSingularValues(),Sigma);
        // Get approx. singular vectors
        U = new FReal[size*rank];
        FBlas::copy(int(size*rank),RSVD.getApproxU(),U);
    }
    else throw std::runtime_error("Invalid choice for the fSVD option!");

    // free memory
    delete [] Sigma;

}

/*
 * compute()
 *
 * Compute leverage scores. Using either SVD or RandSVD (approx leverage scores).
 * Return scores, stats and singular vectors.
 * 
 */
static void computeAll(const FSize size, const FSize rank, /*const*/ FReal* C, FReal* &leverageScores, FReal coherence[4], FReal* &U, const int fSVD){

    std::cout << "\nCompute sampling probabilities based on leverage scores, l_i=|U_i|_2^2 ... ";

    // Allocate memory
    leverageScores = new FReal[size];

    FTic timeSVD;
    double tSVD;

    std::cout << "\nCompute left singular vectors U... ";
    timeSVD.tic();

    computeU(size,rank,C,U,fSVD);

    tSVD = timeSVD.tacAndElapsed();
    std::cout << "... took @tSVD = "<< tSVD <<"\n";

    // Compute Leverage scores
    FTic timeNormU;
    double tNormU;
    std::cout << "\nCompute norm of the rows of U ... ";
    timeNormU.tic();
    // Compute norms of each line of U^T
    VectorNorms<FReal>* rowsNorm = new VectorNorms<FReal>[size];
    // init coherence
    FReal minLS=FReal(1.);
    FReal maxLS=FReal(0.);
    FReal avgLS=FReal(0.);
    FReal devLS=FReal(0.);
    //
    for (int i = 0; i < size; ++i){ // For each row U_i of U
        // reset vector norm
        rowsNorm[i].reset();
        // Compute the norm of U_i
        for (FSize j = 0; j < rank; ++j) 
        {
            rowsNorm[i].add(U[i+j*size]);
        }
        leverageScores[i]=rowsNorm[i].getTwo();
        // Coherence: min, max, mean and std dev of leverage score
        minLS=FMath::Min(minLS,leverageScores[i]);
        maxLS=FMath::Max(maxLS,leverageScores[i]);
        avgLS+=leverageScores[i];
        devLS+=leverageScores[i]*leverageScores[i];

    }
    avgLS/=FReal(size);
    devLS=FMath::Sqrt(devLS/FReal(size)-avgLS*avgLS);
    //for (int i = 0; i < size; ++i)
    //    stdLS+=(leverageScores[i]-meanLS)*(leverageScores[i]-meanLS);
    coherence[0]=minLS;
    coherence[1]=maxLS;
    coherence[2]=avgLS;
    coherence[3]=devLS;
    tNormU = timeNormU.tacAndElapsed();
    std::cout << "... took @tNormU = "<< tNormU <<"\n";

    //if(verbose){
        const int displaySize=10;
        Display::vector(size,leverageScores,"lev",displaySize,1);
        //Display::vector(size,coherence,"coh",displaySize,0);
    //}

    // free memory
    delete [] rowsNorm;

}

/*
 * compute()
 *
 * Compute leverage scores. Using either SVD or RandSVD (approx leverage scores).
 * Return scores only.
 */
static void computeScoresOnly(const FSize size, const FSize rank, /*const*/ FReal* C, FReal* &leverageScores, const int fSVD){

    FReal* U = NULL;
    FReal coherence[4];

    computeAll(size,rank,C,leverageScores,coherence,U,fSVD);

    delete [] U;
    //delete [] coherence;

}


};


#endif // LEVERAGESCORES_HPP

