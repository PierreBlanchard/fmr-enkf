#ifndef FACTDEFINES_HPP
#define FACTDEFINES_HPP

// Provide some very basic includes
#include "Utils/MatrixDimensions.hpp" // for checks before calls to FBlas

// Value type (single, double...)
typedef float FReal;


#endif // FACTDEFINES_HPP
