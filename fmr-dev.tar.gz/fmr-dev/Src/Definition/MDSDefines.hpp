#ifndef MDSDEFINES_HPP
#define MDSDEFINES_HPP

// Provide some very basic includes
#include "Utils/MatrixDimensions.hpp" // for checks before calls to FBlas

// Value type (single, double...)
typedef float FReal;

// Value type specific to distances
typedef unsigned short FDist;

#endif // MDSDEFINES_HPP
