#ifndef SCALFMMDEFINES_HPP
#define SCALFMMDEFINES_HPP


#include "Components/FSimpleLeaf.hpp"
#include "Containers/FOctree.hpp"
#include "Kernels/Uniform/FUnifCell.hpp"
#include "Kernels/P2P/FP2PParticleContainerIndexed.hpp"

// FMR includes



// NVALS (should not exceed 10 for the sake of memory consumption)
// for Classic  RRF: NVALS should be specified such that rank=NFMM*NVALS
// for Adaptive RRF: NVALS should be specified such that rbal=NVALS=10
const int NVALS = 10 ;
// NRHS = NLHS = 1
const int NRHS = 1 ;
const int NLHS = 1 ;
// Container
typedef FP2PParticleContainerIndexed<FReal,NRHS,NLHS,NVALS> ContainerClass;
// Leaf
typedef FSimpleLeaf<FReal,ContainerClass> LeafClass;
// ORDER
const int ORDER = 4 ;
// Cell
typedef FUnifCell<FReal,ORDER,NRHS,NLHS,NVALS> CellClass;
// Octree
typedef FOctree<FReal,CellClass,ContainerClass,LeafClass> OctreeClass;

#endif // SCALFMMDEFINES_HPP
