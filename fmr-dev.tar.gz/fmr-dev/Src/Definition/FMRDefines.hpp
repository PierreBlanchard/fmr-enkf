#ifndef FMRDEFINES_HPP
#define FMRDEFINES_HPP

// Provide some very basic includes
#include "Utils/MatrixDimensions.hpp" // for checks before calls to FBlas

// Value type (single, double...)
typedef double FReal;

#endif // FMRDEFINES_HPP
