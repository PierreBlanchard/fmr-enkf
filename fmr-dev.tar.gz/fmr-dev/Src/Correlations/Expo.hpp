#ifndef EXPO_HPP
#define EXPO_HPP

#include <stdlib.h>
#include <math.h> // for exp

// ScalFMM includes
#include "Utils/FNoCopyable.hpp"
#include "Utils/FMath.hpp"
#include "Utils/FPoint.hpp"
// for identifiers and types
#include "Kernels/Interpolation/FInterpMatrixKernel.hpp"


/// Generic Exponential decay correlation function (separable anisotropic version)
/// Special case of Matern function with $\nu \rightarrow \infty$ 
template<class FReal, int DIM>
struct CK_Expo : AbstractCorrelationKernel<FReal>
{
  static const unsigned int CID = 0;
  static const KERNEL_FUNCTION_TYPE Type = NON_HOMOGENEOUS;
  static const CORRELATION_SUPPORT_EXTENSION Extension = INFINITE;
  static const unsigned int NCMP = 1; //< number of components
  static const unsigned int NPV  = 1; //< dim of physical values
  static const unsigned int NPOT = 1; //< dim of potentials
  static const unsigned int NRHS = 1; //< dim of mult exp
  static const unsigned int NLHS = 1; //< dim of loc exp

  FReal lengthScale_[DIM];

  CK_Expo(const FReal* lengthScale)
  {
    for(int d=0; d<DIM; ++d)
      lengthScale_[d]=lengthScale[d];

    std::cout<< "Exponential decay " << DIM <<"D"
             << ", i.e. r(x)=exp(-sqrt((x_i/l_i)^2)) with l=";
    if(DIM==1) 
      std::cout<< lengthScale_[0] <<std::endl; 
    if(DIM==2) 
      std::cout<< "(" << lengthScale_[0]
               << "," << lengthScale_[1] << ")" <<std::endl; 
    if(DIM==3) 
      std::cout<< "(" << lengthScale_[0] << "," << lengthScale_[1]
               << "," << lengthScale_[2] << ")" <<std::endl;
  }


  // copy ctor
  CK_Expo(const CK_Expo& /*other*/)
  {}

  // ID accessor
  static const unsigned int getID() { return CID; }

  /*
   * returns length scale
   */
  FReal getLengthScale() const
  {
    return lengthScale_[0];
  }

  /*
   * r(x)=exp(-||x_t-x_s||/l)
   */
  FReal evaluate(const FReal* xt, const FReal* xs) const
  {
    FReal dist2 = 0.0;
    for(int d=0; d<DIM; ++d){
      FReal distX = FMath::Abs(xt[d]-xs[d]) / lengthScale_[d];
      dist2 += distX*distX;
    }
    FReal dist = FMath::Sqrt(dist2);

    FReal res = FMath::Exp(-dist);

    return res;
  }

  // evaluate interaction
  template <class ValueClass>
  ValueClass evaluate(const ValueClass& xt, const ValueClass& yt, const ValueClass& zt,
                      const ValueClass& xs, const ValueClass& ys, const ValueClass& zs) const
  {
    const ValueClass diff[3] = {(xt-xs),(yt-ys),(zt-zs)};

    ValueClass dist2 = FMath::Zero<ValueClass>();
    for(int d=0; d<DIM; ++d){
      const ValueClass distX = diff[d] / FMath::ConvertTo<ValueClass,FReal>(lengthScale_[d]);
      dist2 += distX*distX;
    }

    // TODO implement SSE exponential
    return FMath::Exp(-FMath::Sqrt(dist2));
  }

  // evaluate interaction (blockwise)
  template <class ValueClass>
  void evaluateBlock(const ValueClass& xt, const ValueClass& yt, const ValueClass& zt,
                     const ValueClass& xs, const ValueClass& ys, const ValueClass& zs, ValueClass* block) const
  {
    block[0]=this->evaluate(xt,yt,zt,xs,ys,zs);
  }

  // evaluate interaction and derivative (blockwise)
  template <class ValueClass>
  void evaluateBlockAndDerivative(const ValueClass& xt, const ValueClass& yt, const ValueClass& zt,
                                  const ValueClass& xs, const ValueClass& ys, const ValueClass& zs,
                                  ValueClass block[1], ValueClass blockDerivative[3]) const
  {
    block[0]=this->evaluate(xt,yt,zt,xs,ys,zs);
    // derivative not needed
    blockDerivative[0] = FMath::Zero<ValueClass>();
    blockDerivative[1] = FMath::Zero<ValueClass>();
    blockDerivative[2] = FMath::Zero<ValueClass>();
  }

  /*
   * scaling (for ScalFMM)
   */
  FReal getScaleFactor(const FReal, const int) const
  {
    // return 1 because non homogeneous kernel functions cannot be scaled!!!
    return FReal(1.);
  }

  FReal getScaleFactor(const FReal) const
  {
    // return 1 because non homogeneous kernel functions cannot be scaled!!!
    return FReal(1.);
  }

  // returns position in reduced storage
  int getPosition(const unsigned int) const
  {return 0;} 

  FReal evaluate(const FPoint<FReal>& p1, const FPoint<FReal>& p2) const{
    return evaluate<FReal>(p1.getX(), p1.getY(), p1.getZ(), p2.getX(), p2.getY(), p2.getZ());
  }
  void evaluateBlock(const FPoint<FReal>& p1, const FPoint<FReal>& p2, FReal* block) const{
    evaluateBlock<FReal>(p1.getX(), p1.getY(), p1.getZ(), p2.getX(), p2.getY(), p2.getZ(), block);
  }
  void evaluateBlockAndDerivative(const FPoint<FReal>& p1, const FPoint<FReal>& p2,
                                  FReal block[1], FReal blockDerivative[3]) const {
    evaluateBlockAndDerivative<FReal>(p1.getX(), p1.getY(), p1.getZ(), p2.getX(), p2.getY(), p2.getZ(), block, blockDerivative);
  }

};


#endif /* EXPO_HPP */
