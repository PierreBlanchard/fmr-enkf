#ifndef CORRELATIONKERNEL_HPP
#define CORRELATIONKERNEL_HPP


#include <stdlib.h>
#include <math.h> // for exp

// ScalFMM includes
#include "Utils/FNoCopyable.hpp"
#include "Utils/FMath.hpp"
#include "Utils/FPoint.hpp"
// for identifiers and types
#include "Kernels/Interpolation/FInterpMatrixKernel.hpp"



/**
 * @author Pierre Blanchard (pierre.blanchard@inria.fr)
 * @date March 13th, 2014 
 */

// not extendable
enum CORRELATION_SUPPORT_EXTENSION{INFINITE,FINITE};

// TOADD
// bounded support correlation functions:
// * power model
// hole effect correlation (nonstrictly decreasing)
// Whittle model? (slow decay => important constraint on size of grid / length)
template <class FReal>
struct AbstractCorrelationKernel : FNoCopyable
{ 
  virtual ~AbstractCorrelationKernel(){}
  virtual FReal evaluate(const FReal*, const FReal*) const = 0;

};

/**
 * @class CORRELATIONKERNEL
 *
 * The following classes provide the evaluators for the correlation function listed below:
 * Exponential decay (Matern for $\nu=1/2$): not smooth AT ALL, actually very rough. Application to Brownian motion.
 * Gaussian decay (Matern for $\nu=\infty$): infinitely smooth 
 * Spherical correlation: not smooth AT ALL, but FINITE support! It is proportionnal to the intersecting area 
 * of 2 disks of radius $\ell$ whose centers are separated from $r$.
 * 
 * TODO Explicit version of Matern for $\nu=3/2$ and $\nu=5/2$ (application to machine learning)
 * Smaller values of $\nu$ lead to rough behaviours (already covered by exponential) 
 * while larger $\nu$ ($\leq 7/2$) are hard to differentiate from the Gaussian decay.
 * 
 * TODO Generic Matern for an arbitrary $\nu$ (evaluator involve Bessel functions and spectral density involves Gamma functions)
 * 
 * @tparam NAME description \f$latex symbol\f$
 */
#include "Gauss.hpp"
//#include "Matern.hpp" // TODO
#include "Expo.hpp"
#include "Spherical.hpp"
#include "OseenGauss.hpp"

#endif /* CORRELATIONKERNEL_HPP */
