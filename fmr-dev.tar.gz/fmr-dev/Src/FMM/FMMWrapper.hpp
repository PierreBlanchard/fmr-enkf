#ifndef FMMWRAPPER_HPP
#define FMMWRAPPER_HPP

// standard includes 
#include <stdio.h>
#include <stdlib.h>

// For std::array<> (i.e. for MultiRhs purpose)
#include <array>

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp"
#include "Utils/FMath.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FAlgorithmTimers.hpp"


// FMR includes
#include "Definition/ScalFMMDefines.hpp"

/**
 * @author Pierre Blanchard (pierre.blanchard@inria.fr)
 * @date October 20th, 2014 
 *
 */


/**
 * @brief FMM Wrapper class
 *
 */
template<class FReal, class OctreeClass, class MatrixKernelClass, class FmmKernelClass, class FmmAlgoClass>
class FMMWrapper {


private:

    // needed for FMM
    OctreeClass* Tree;
    MatrixKernelClass* MatrixKernel;
    FmmKernelClass* FmmKernel;
    FmmAlgoClass* FmmAlgo;
    FPoint<FReal>* Positions;
    // needed for P2P init
    const FSize matrixSize;
    // maximum memory (that should be used for the storage of P2P and M2L operators)
    const FSize memoryLimit;
    // Various flags
    const bool ApproximateNearfield; //< 0: ufmm; 1: smooth-ufmm

public:

    /*
     * Ctor
     */
    explicit FMMWrapper(OctreeClass* inTree, MatrixKernelClass* inMatrixKernel, const FPoint<FReal>* inPositions, const FSize inMatrixSize, const bool inApproximateNearfield = false)
        : Tree(inTree), MatrixKernel(inMatrixKernel), FmmKernel(nullptr), FmmAlgo(nullptr), 
          Positions(new FPoint<FReal>[inMatrixSize]), matrixSize(inMatrixSize), memoryLimit(50e9),
          ApproximateNearfield(inApproximateNearfield)
    {
        // copy grid positions (needed for fmm tree update)
        for ( FSize i=0; i<matrixSize; ++i) 
            Positions[i]=FPoint<FReal>(inPositions[i].getX(),
                                       inPositions[i].getY(),
                                       inPositions[i].getZ());
    }

    /*
     * Copy ctor
     */
    explicit FMMWrapper(const FMMWrapper& other)
        : Tree(other.Tree), MatrixKernel(other.MatrixKernel), FmmKernel(nullptr), FmmAlgo(nullptr), 
          Positions(other.Positions), matrixSize(other.matrixSize), memoryLimit(other.memoryLimit),
          ApproximateNearfield(other.ApproximateNearfield)
    { }

    /*
     * Dtor
     */
    ~FMMWrapper()
    {
        delete [] Positions;
        delete FmmKernel;
        delete FmmAlgo;
    }

    /*
     * Initialize flags, FMM kernel and FMM algorithm
     * 
     */
    void init() {

        // Display FMM variant
        if(ApproximateNearfield){
            std::cout << "  FMM variant: Approximation of NF interactions." << std::endl;
        }
        else{
            std::cout << "  FMM variant: Standard (direct NF/ approx FF, based on well separation)." << std::endl;
        }

        // build Uniform kernel
        std::cout << "  Build FMM kernel: ";
        this->FmmKernel = new FmmKernelClass(Tree->getHeight(),
                                             Tree->getBoxWidth(),
                                             Tree->getBoxCenter(),
                                             this->MatrixKernel,
                                             (ApproximateNearfield ? -1 : 1));
    

        /// Fill Tree
        std::cout << "  Insert (dummy) particles in tree... \n";
        FTic timeInitTree;
        timeInitTree.tic();
        // insert particles with dummy physical values
        for(FSize idxPart = 0 ; idxPart < matrixSize ; ++idxPart){
            // Convert FReal[NVALS] to std::array<FReal,NVALS>
            std::array<FReal, (1+4*1)*NVALS> physicalState;
            for(int idxVals = 0 ; idxVals < NVALS ; ++idxVals){
                physicalState[0*NVALS+idxVals]=1.0; // dummy value
                physicalState[1*NVALS+idxVals]=0.0;
                physicalState[2*NVALS+idxVals]=0.0;
                physicalState[3*NVALS+idxVals]=0.0;
                physicalState[4*NVALS+idxVals]=0.0;
            }
            Tree->insert(Positions[idxPart], idxPart, physicalState);
        }
        double tInitTree= timeInitTree.tacAndElapsed();
        std::cout << "  ... took @tInitTree = " << tInitTree <<"\n";

        /// Set algorithm
        this->FmmAlgo = new FmmAlgoClass(this->Tree,this->FmmKernel,(ApproximateNearfield ? -1 : 1)) ;

        /// Set P2P (if needed)
        std::cout << "  Precompute P2P?\n";
        if(ApproximateNearfield){
            std::cout << "  NO P2P assembly because P2P is approximated!" << std::endl;
        } else {
            // Estimate memory requirement
            std::cout << "    Estimate memory ...\n";
            this->FmmAlgo->execute(FFmmNearField);
            // Return estimate of memory requirements
            std::cout << "      Memory: @mM2L = " << this->FmmKernel->getMemoryM2L()*FReal(1.e-6) <<"MB\n";
            std::cout << "      Memory: @mP2P = " << this->FmmKernel->getMemoryP2P()*FReal(1.e-6) <<"MB\n";
            std::cout << "      Memory: @mTOT = " << this->FmmKernel->getMemoryP2PandM2L()*FReal(1.e-6) <<"MB\n";
            // IF memory limit NOT exceeded 
            // THEN precompute P2P operators 
            // ELSE stop computation and change depth
            if(this->FmmKernel->getMemoryP2PandM2L() < memoryLimit){
                std::cout << "    Build P2P ...\n";
                FTic timeAssP2P;
                timeAssP2P.tic();
                //
                this->FmmAlgo->execute(FFmmNearField);
                //
                double tAssP2P = timeAssP2P.tacAndElapsed();
                    std::cout << "    ... took @tAssP2P = " << tAssP2P <<"\n";
            }
            else
                throw std::runtime_error("P2P and M2L require more than the memory limit. Tips: Use a larger TreeHeight!");
        }

    }

    /* 
     * This function evaluate the minimal FMM level that actually need to be computed 
     * considering that correlation function decrease very fast and might reach machine
     * precision within the width of a FMM cell.
     */
    int computeMinimumLevel(){
        int level=Tree->getHeight();
        FReal largestCorrelation = FReal(1.);
        while(level>1 && largestCorrelation>FReal(1.e-13))
        {
            --level;
            const FReal CellWidth(Tree->getBoxWidth() / FReal(FMath::pow(2, level))); 
            largestCorrelation = this->MatrixKernel->evaluate(FReal(0.),FReal(0.),FReal(0.),CellWidth,FReal(0.),FReal(0.));
            std::cout << "Level:" << level << " - CellWidth:" << CellWidth << " - largestCorrelation:" << largestCorrelation << std::endl;
        }
        return level+1; // stop M2Ls at next level
    }

    /*
     * Get wrapper ID
     * 
     */
    int getID() {
        return 2;
    }

    /*
     * Get algorithm timing
     * 
     */
    void getTimes() {
        std::cout << "@tP2M = " << this->FmmAlgo->getTime(FAlgorithmTimers::P2MTimer) << std::endl;
        std::cout << "@tM2M = " << this->FmmAlgo->getTime(FAlgorithmTimers::M2MTimer) << std::endl;
        std::cout << "@tM2L = " << this->FmmAlgo->getTime(FAlgorithmTimers::M2LTimer) << std::endl;
        std::cout << "@tL2L = " << this->FmmAlgo->getTime(FAlgorithmTimers::L2LTimer) << std::endl;
        std::cout << "@tNear = " << this->FmmAlgo->getTime(FAlgorithmTimers::NearTimer) << std::endl;
        // L2P and P2P are not easily measured separately therefore we use the timing for the directPass
    }

    /*
     * Get symmetric flag
     *
     * FMM is always used for symmetric square matrices so far
     * 
     */
    const bool isSymmetric() {
        return true;
    }

    /*
     * multiplyMatrix: This routine performs the product CW where C is the input matrix and W a set of random vectors
     */
        void multiplyMatrix(const FSize nbRows, const FSize nbCols, const FSize rank, FReal* W, FReal* &Y, const bool transposeMatrix = false){

        // ensure matrix is square! TODO extend to rectangular matrices!
        FAssertLF(nbRows==nbCols); 

        // Set size
        const FSize size = nbRows;

        // Evaluate number of FMM loops to perform
        const FSize NFMM = rank / NVALS; // here the rank is oversampled
        const FSize NOS  = rank % NVALS; // should correspond to oversampling if non-oversampled rank is well adjusted, i.e. it is a multiple of NVALS.
        // Perform extra loop if rank is not multiple of NVALS
        int extraLoop = 0;
        if(NOS) extraLoop = 1;

        // Perform NFMM schemes of size NVALS + one of size p
        for ( FSize idxFMM=0; idxFMM<NFMM+extraLoop; ++idxFMM) {

            // Update number of blocked vectors to be computed
            // For the sake of clarity, ScalFMM only sees blocks of size NVALS
            // but the last block is padded with NVALS-NOS null vectors
            FSize currentNVALS;
            if(idxFMM<NFMM){
                currentNVALS = NVALS;
            }
            else{
                currentNVALS = NOS;
            }

            // Reset cells (expansions and potentials)
            if(!Tree->isEmpty())
                Tree->forEachCell([&](CellClass* cell){
                    cell->resetToInitialState();
            });

            // Set new input vectors (i.e. physical values)
            Tree->forEachLeaf([&](LeafClass* leaf){

                FReal*const physicalValues = leaf->getTargets()->getPhysicalValuesArray();
                FReal*const potentials = leaf->getTargets()->getPotentialsArray();
                const FSize targetsLD  = leaf->getTargets()->getLeadingDimension();
                const FSize nbParticlesInLeaf = leaf->getTargets()->getNbParticles();
                const FVector<FSize>& indexes = leaf->getTargets()->getIndexes();

                for(FSize idxVals = 0 ; idxVals < currentNVALS ; ++idxVals){
                    const FSize idxVec = idxFMM*NVALS+idxVals;
                    for(FSize idxPart = 0 ; idxPart < nbParticlesInLeaf ; ++idxPart){
                        const FSize indexPartOrig = indexes[idxPart];
                        const FSize idxPartValue = idxVals*targetsLD+idxPart;
                        physicalValues[idxPartValue] = W[idxVec*size+indexPartOrig];
                        potentials[idxPartValue] = FReal(0.);
                    }
                }// end currentNVALS
            });

            // Execute algorithm
            if(ApproximateNearfield) // if nearfield is approximated then only apply P2M2ML2L2P
                this->FmmAlgo->execute(FFmmFarField);
            else // if nearfield computed densely then execute all operations P2M2ML2L2P + P2P
                this->FmmAlgo->execute();

            // Update result
            Tree->forEachLeaf([&](LeafClass* leaf){

                const FReal*const potentials = leaf->getTargets()->getPotentialsArray();
                const FSize targetsLD  = leaf->getTargets()->getLeadingDimension();
                const FSize nbParticlesInLeaf = leaf->getTargets()->getNbParticles();
                const FVector<FSize>& indexes = leaf->getTargets()->getIndexes();

                for(FSize idxVals = 0 ; idxVals < currentNVALS ; ++idxVals){
                    const FSize idxVec = idxFMM*NVALS+idxVals;
                    for(FSize idxPart = 0 ; idxPart < nbParticlesInLeaf ; ++idxPart){
                        const FSize indexPartOrig = indexes[idxPart];
                        // Update output array Y
                        Y[idxVec*size+indexPartOrig]=potentials[idxVals*targetsLD+idxPart];
                    }
                }// end currentNVALS
            });       

        }// end NFMM

    }

    /*
     * This function computes the error committed by computing the first vector of W using the FMM
     */
    void computeError(const FSize nbRows, const FSize nbCols, const FSize rank, FReal* W, FReal* &Y){

        // ensure matrix is square! TODO extend to rectangular matrices!
        FAssertLF(nbRows==nbCols); 

        // Set size
        const FSize size = nbRows;

        // Compute FMM error ||FMM(CW_0)-Direct(CW_0)||

        // Compute first Mat-Vec Product using direct method (mutual interactions + self interaction)
        FReal* Yd = new FReal[size];
        is_int(size);
        FBlas::setzero(int(size),Yd);
        FReal C_ii = this->MatrixKernel->evaluate(Positions[0],Positions[0]);
        for(FSize idxTarget = 0 ; idxTarget < size ; ++idxTarget){
            // Self-interaction
            Yd[idxTarget] += C_ii * W[idxTarget];
            // Mutual interactions
            for(FSize idxOther = idxTarget + 1 ; idxOther < size ; ++idxOther){
                FReal C_ij = this->MatrixKernel->evaluate(Positions[idxTarget],Positions[idxOther]);
                Yd[idxTarget] += C_ij * W[idxOther ];
                Yd[idxOther ] += C_ij * W[idxTarget];
            }
        }
        // Compute error 
        FMath::FAccurater<FReal> errorFMM;
        //for ( int r=0; r<rank; ++r) 
          for ( FSize j=0; j<size; ++j)
            errorFMM.add(Yd[/*r*size+*/j],Y[/*r*size+*/j]);
        
        std::cout << "\n";
        std::cout << "@errorFMM_L2  = "<< errorFMM.getRelativeL2Norm() <<"\n";
        std::cout << "@errorFMM_Inf = "<< errorFMM.getRelativeInfNorm() <<"\n";

        delete [] Yd;

    }

};

#endif /* FMMWRAPPER_HPP */
