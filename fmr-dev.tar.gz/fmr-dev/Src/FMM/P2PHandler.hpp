#ifndef FP2PHANDLER_HPP
#define FP2PHANDLER_HPP

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FBlas.hpp"

template <class FReal>
class FP2PHandler : FNoCopyable
{

  /// Tree Height
  const int TreeHeight;
  /// Max number of leafs
  const MortonIndex maxNbLeafs;

  /// Memory allocated for P2P operators
  FSize memoryCounter;
  /// Array of flags needed by memory estimation
  bool* memoryFlags;

  /// M2L Operators (stored in Fourier space for each component of tensor)
  FSmartPointer< FReal***,FSmartArrayMemory> C;

public:

    FP2PHandler(const int inTreeHeight)
    : TreeHeight(inTreeHeight), maxNbLeafs(FMath::pow(8,TreeHeight-1)), memoryCounter(0)
    {

        // allocate C
        C = new FReal***[1];
        C[0] = new FReal**[maxNbLeafs];
        for (MortonIndex idxLeaf=0; idxLeaf<maxNbLeafs; ++idxLeaf){
          C[0][idxLeaf] = new FReal*[27];
          for (int idxNeigh=0; idxNeigh<27; ++idxNeigh)
            C[0][idxLeaf][idxNeigh]=nullptr;
        }

        // allocate and init memoryFlags
        memoryFlags = new bool[maxNbLeafs];
        for (MortonIndex idxLeaf=0; idxLeaf<maxNbLeafs; ++idxLeaf)
            memoryFlags[idxLeaf] = false;

    }


	~FP2PHandler()
	{
        // delete precomputed P2P operators
        for (MortonIndex idxLeaf=0; idxLeaf<maxNbLeafs; ++idxLeaf){
            for (int idxNeigh=0; idxNeigh<27; ++idxNeigh)
                if (C[0][idxLeaf][idxNeigh] != NULL) delete [] C[0][idxLeaf][idxNeigh];
        }
        // delete memoryFlags
        delete [] memoryFlags;
    }

    // Go through each neighbours and return true if one interaction is computed
    const bool isPrecomputed(const MortonIndex idxLeaf, const int neighborPositions[], const int limiteNeighbors) const {

        for (int idxExistingNeighbors=0; idxExistingNeighbors<limiteNeighbors; ++idxExistingNeighbors){
            const int idxNeigh = neighborPositions[idxExistingNeighbors];

            if(this->C[0][idxLeaf][idxNeigh]!=nullptr) return true;
        }
        return false;
    }

    template <typename ContainerClass>
    void estimateMemory(const MortonIndex idxLeaf,
                        ContainerClass* const FRestrict targets,
                        const ContainerClass* const directNeighbors[],
                        const int limiteNeighbors)
    {

        // number of targets
        const FSize nbTargetParticles = targets->getNbParticles();

        // Allocate set of arrays for current leaf
        for (int idxExistingNeighbors=0; idxExistingNeighbors<limiteNeighbors; ++idxExistingNeighbors){

            // number of sources
            const FSize nbSourceParticles = directNeighbors[idxExistingNeighbors]->getNbParticles();

            // count memory
            memoryCounter += nbSourceParticles*nbTargetParticles;

        }

        // add contribution of self interaction
        memoryCounter += nbTargetParticles*nbTargetParticles;

        // Turn corresponding memory flag ON
        memoryFlags[idxLeaf] = true;

    }

    bool isMemoryEstimated(const MortonIndex idxLeaf) {
        return memoryFlags[idxLeaf];
    }

    FSize getMemory() {
  
        return memoryCounter*sizeof(FReal);
  
    }

    template <typename ContainerClass, typename MatrixKernelClass>
    void Precompute(const MortonIndex idxLeaf,
                    ContainerClass* const FRestrict targets,
                    const ContainerClass* const directNeighbors[],
                    const int neighborPositions[],
                    const int limiteNeighbors,
                    const MatrixKernelClass *const MatrixKernel)
    {
        const FSize nbTargetParticles = targets->getNbParticles();
        const FReal*const targetsX = targets->getPositions()[0];
        const FReal*const targetsY = targets->getPositions()[1];
        const FReal*const targetsZ = targets->getPositions()[2];

        // Allocate set of arrays for current leaf
        for (int idxExistingNeighbors=0; idxExistingNeighbors<limiteNeighbors; ++idxExistingNeighbors){
            const int idxNeigh = neighborPositions[idxExistingNeighbors];

            // Allocate current P2P operator
            const FSize nbSourceParticles = directNeighbors[idxExistingNeighbors]->getNbParticles();
            const FReal*const sourcesX = directNeighbors[idxExistingNeighbors]->getPositions()[0];
            const FReal*const sourcesY = directNeighbors[idxExistingNeighbors]->getPositions()[1];
            const FReal*const sourcesZ = directNeighbors[idxExistingNeighbors]->getPositions()[2];

            // allocate
            C[0][idxLeaf][idxNeigh] = new FReal[nbSourceParticles*nbTargetParticles];

            // Compute all interactions with neighbors (EXCEPT self interaction, since not in neighbors list)
            for (FSize idxTarget=0; idxTarget<nbTargetParticles; ++idxTarget){
                const FPoint<FReal> targetPoint(targetsX[idxTarget],targetsY[idxTarget],targetsZ[idxTarget]);
                for (FSize idxSource=0; idxSource<nbSourceParticles; ++idxSource){
                    const FPoint<FReal> sourcePoint(sourcesX[idxSource],sourcesY[idxSource],sourcesZ[idxSource]);

                    C[0][idxLeaf][idxNeigh][idxTarget+idxSource*nbTargetParticles]=MatrixKernel->evaluate(targetPoint,sourcePoint);
                
                }
            }

        }

        // Compute inner interaction operator here since current leaf is not included in neighbors list
        C[0][idxLeaf][13] = new FReal[nbTargetParticles*nbTargetParticles];
        for (FSize idxTarget=0; idxTarget<nbTargetParticles; ++idxTarget){
            const FPoint<FReal> targetPoint(targetsX[idxTarget],targetsY[idxTarget],targetsZ[idxTarget]);
            for (FSize idxSource=0; idxSource<nbTargetParticles; ++idxSource){
                const FPoint<FReal> sourcePoint(targetsX[idxSource],targetsY[idxSource],targetsZ[idxSource]);

                C[0][idxLeaf][13][idxTarget+idxSource*nbTargetParticles]=MatrixKernel->evaluate(targetPoint,sourcePoint);

            }
        }

    }




    // Apply mutual leaf interactions (without inner leaf interactions) to NVALS vectors
    // Here we apply the interactions for only NVALS input vectors
    // 
    template <typename ContainerClass>
    void applyMutual(const MortonIndex idxLeaf,
                     ContainerClass* const FRestrict targets,
                     ContainerClass* const directNeighbors[],
                     const int neighborPositions[],
                     const int limiteNeighbors)
    {

        const FSize nbTargetParticles = targets->getNbParticles();
        FReal* targetsPhysicalValues = targets->getPhysicalValuesArray(); // for Blas
        FReal*const targetsPotentials = targets->getPotentialsArray();
        const FSize targetsLD  = targets->getLeadingDimension();
        const int nVals = targets->getNVALS();
        //
        // Interaction on the Neighbor cells
        //
        for (int idxExistingNeighbors=0; idxExistingNeighbors<limiteNeighbors; ++idxExistingNeighbors){
            const int idxNeigh = neighborPositions[idxExistingNeighbors];

            const FSize nbSourceParticles = directNeighbors[idxExistingNeighbors]->getNbParticles();
            FReal* sourcesPhysicalValues = directNeighbors[idxExistingNeighbors]->getPhysicalValuesArray(); // for Blas

            FReal*const sourcesPotentials = directNeighbors[idxExistingNeighbors]->getPotentialsArray();
            const FSize sourcesLD  = directNeighbors[idxExistingNeighbors]->getLeadingDimension();
            //
            // Do matrix-to-matrix product using Blas functions
            //
            is_int(nbSourceParticles); is_int(nbTargetParticles); is_int(sourcesLD); is_int(targetsLD);
            FBlas::gemma(int(nbTargetParticles),int(nbSourceParticles),nVals,FReal(1.),
                          C[0][idxLeaf][idxNeigh],int(nbTargetParticles),sourcesPhysicalValues,int(sourcesLD),targetsPotentials,int(targetsLD));
            FBlas::gemtma(int(nbTargetParticles),int(nbSourceParticles),nVals,FReal(1.),
                         C[0][idxLeaf][idxNeigh],int(nbTargetParticles),targetsPhysicalValues,int(targetsLD),sourcesPotentials,int(sourcesLD));

        }

    }


    // Apply inner leaf interactions (without self particles interactions) to NVALS vectors
    // Here we apply the interactions for only NVALS input vectors
    // 
    template <typename ContainerClass>
    void applyInner(const MortonIndex idxLeaf,
                  ContainerClass* const FRestrict targets)
    {

        const FSize nbTargetParticles = targets->getNbParticles();
        FReal* targetsPhysicalValues = targets->getPhysicalValuesArray(); // for Blas
        FReal*const targetsPotentials = targets->getPotentialsArray();
        const FSize targetsLD  = targets->getLeadingDimension();
        const int nVals = targets->getNVALS();
        //
        // Interaction on the current cell
        //
        is_int(nbTargetParticles); is_int(targetsLD);
        FBlas::gemma(int(nbTargetParticles),int(nbTargetParticles),nVals,FReal(1.),
                     C[0][idxLeaf][13],int(nbTargetParticles),targetsPhysicalValues,int(targetsLD),targetsPotentials,int(targetsLD));

    }


    // Apply remote leaf interactions (without self particles interactions) to NVALS vectors
    // Here we apply the interactions for only NVALS input vectors
    // 
    template <typename ContainerClass>
    void applyRemote(const MortonIndex idxLeaf,
                     ContainerClass* const FRestrict targets,
                     const ContainerClass* const directNeighbors[],
                     const int neighborPositions[],
                     const int limiteNeighbors)
    {

        const FSize nbTargetParticles = targets->getNbParticles();
        FReal*const targetsPotentials = targets->getPotentialsArray(); // for Blas
        const FSize targetsLD  = targets->getLeadingDimension();
        const int nVals = targets->getNVALS();
        //
        // Interaction on the Neighbor cells
        //
        for (int idxExistingNeighbors=0; idxExistingNeighbors<limiteNeighbors; ++idxExistingNeighbors){
            const int idxNeigh = neighborPositions[idxExistingNeighbors];

            const FSize nbSourceParticles = directNeighbors[idxExistingNeighbors]->getNbParticles();
            FReal* sourcesPhysicalValues = const_cast<FReal*>(directNeighbors[idxExistingNeighbors]->getPhysicalValuesArray()); // for Blas
            const FSize sourcesLD  = directNeighbors[idxExistingNeighbors]->getLeadingDimension();
            //
            // Do matrix-to-matrix product using Blas functions
            //
            is_int(nbSourceParticles); is_int(nbTargetParticles); is_int(sourcesLD); is_int(targetsLD);
            FBlas::gemma(int(nbTargetParticles),int(nbSourceParticles),nVals,FReal(1.),
                         C[0][idxLeaf][idxNeigh],int(nbTargetParticles),sourcesPhysicalValues,int(sourcesLD),targetsPotentials,int(targetsLD));

        }


    }

};


#endif
