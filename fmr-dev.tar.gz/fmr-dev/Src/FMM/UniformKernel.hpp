

/*
 * UniformKernel.hpp
 *
 *  Created on: Mar 24th, 2014
 *      Author: Pierre Blanchard
 */

#ifndef _UNIFORMKERNEL_HPP_
#define _UNIFORMKERNEL_HPP_


// ScalFMM
#include "Utils/FGlobal.hpp"
#include "Kernels/Uniform/FAbstractUnifKernel.hpp"
#include "Kernels/Uniform/FUnifTensorialM2LHandler.hpp"
// FMR
#include "FMM/P2PHandler.hpp" 

template< class FReal,
          class CellClass, class ContainerClass, 
          class MatrixKernelClass, int ORDER, int NVALS = 1>
class UniformKernel
  : public FAbstractUnifKernel<FReal,CellClass,ContainerClass,
                               MatrixKernelClass,ORDER,NVALS>
{
    enum {nRhs = MatrixKernelClass::NRHS,
          nLhs = MatrixKernelClass::NLHS};

    typedef FAbstractUnifKernel<FReal,CellClass,ContainerClass,
                                MatrixKernelClass,ORDER,NVALS> AbstractBaseClass;

	// private types
    typedef FUnifTensorialM2LHandler<FReal,ORDER,MatrixKernelClass,MatrixKernelClass::Type> M2LHandlerClass;

    /// Needed for P2P and M2L operators
    const MatrixKernelClass *const MatrixKernel;

    /// Needed for M2L operator
    const M2LHandlerClass M2LHandler;

    /// Leaf level separation criterion
    const int LeafLevelSeparationCriterion;

    /// Needed for P2P operator
    typedef FP2PHandler<FReal> P2PHandlerClass;
    P2PHandlerClass P2PHandler; // not constant since needs to be updated during first pass

  // no specific Interpolator needed since the one in abstract kernel is enough
//	typedef UniformInterpolator<ORDER,MatrixKernelClass,ContainerClass> InterpolatorClass;
//	/// Needed for P2M and L2P operators
//	const FSmartPointer<InterpolatorClass,
//                      FSmartPointerMemory> UnifInterpolator;

    // The 2 following are needed by the copy constructor
    /// Tree height
    const int TreeHeight;
    /// Box width
    const double BoxWidth;
    /// Memory counter
    unsigned long long memoryCounter;

public:
    /// Nearfield approximation flag
    const bool ApproxNearfield;

  //============================================================
  // UniformKernel::UniformKernel
  //------------------------------------------------------------
  /**
   * Default constructor. 
   * All parameters are set to zero. 
   * Don't forget to call SetParam method before using it.
   * Since the matrix kernel is built here, the CoreWidth still needs to be passed 
   */
  //============================================================
  UniformKernel(const int inTreeHeight,
                const FReal inBoxWidth,
                const FPoint<FReal>& inBoxCenter,
                const MatrixKernelClass *const inMatrixKernel,
                const int inLeafLevelSeparationCriterion)
    :  FAbstractUnifKernel<FReal,CellClass,ContainerClass,
                           MatrixKernelClass,ORDER,NVALS>
       (inTreeHeight,inBoxWidth,inBoxCenter),
       MatrixKernel(inMatrixKernel),
       M2LHandler(MatrixKernel,
                  inTreeHeight,
                  inBoxWidth,
                  0.,
                  inLeafLevelSeparationCriterion),
       LeafLevelSeparationCriterion(inLeafLevelSeparationCriterion),
       P2PHandler(inTreeHeight),
       TreeHeight(inTreeHeight), 
       BoxWidth(inBoxWidth),
       ApproxNearfield(inLeafLevelSeparationCriterion==-1 ? 1 : 0)
  { }

  //============================================================
  // UniformKernel::UniformKernel
  //------------------------------------------------------------
  /** 
   *   Copy constructor 
   */
  //============================================================
  UniformKernel(const UniformKernel& other)
  :  FAbstractUnifKernel<FReal,CellClass,ContainerClass,
                         MatrixKernelClass,ORDER,NVALS> (other),
     MatrixKernel(other.MatrixKernel),
     M2LHandler(other.M2LHandler),
     LeafLevelSeparationCriterion(other.LeafLevelSeparationCriterion),
     P2PHandler(other.P2PHandler),
     TreeHeight(other.TreeHeight),
     BoxWidth(other.BoxWidth),
     ApproxNearfield(other.ApproxNearfield)
  { }


    unsigned long long getMemoryM2L(){
        return M2LHandler.getMemory();
    }
    unsigned long long getMemoryP2P(){
        return P2PHandler.getMemory();
    }
    unsigned long long getMemoryP2PandM2L(){
        return this->getMemoryP2P()+this->getMemoryM2L();
    }

    //============================================================
    // UniformKernel::P2P
    //------------------------------------------------------------
    /**
     *   Particles to particles
     * @param inLeafPosition tree coordinate of the leaf
     * @param targets current box targets particles
     * @param sources current box sources particles (can be == to targets)
     * @param directNeighbors the particles from direct neighbors (this is an array of list)
     * @param size the number of direct neighbors
     */
    //============================================================
    void P2P(const FTreeCoordinate& inLeafPosition,
             ContainerClass* const FRestrict targets, 
             const ContainerClass* const FRestrict sources,
             ContainerClass* const directNeighbors[], 
             const int neighborPositions[],
             const int size)
    {
        if(!ApproxNearfield){
    
            const MortonIndex idxLeaf = inLeafPosition.getMortonIndex(TreeHeight-1);
            //
            // 1) Estimate memory requirement (if not yet done) 
            //
            if(!P2PHandler.isMemoryEstimated(idxLeaf)) {
                P2PHandler.estimateMemory(idxLeaf,targets,directNeighbors,size);
            }
            else { // "else" means the P2P is not applied at the first FMM exec !!!
                //
                // 2) Precompute P2P (if not yet done)
                //
                if(!P2PHandler.isPrecomputed(idxLeaf,neighborPositions,size)) {
                    P2PHandler.Precompute(idxLeaf,targets,directNeighbors,neighborPositions,size,MatrixKernel);
                }
                else{ // "else" means the P2P is not applied at the first neither at the second FMM exec !!!
                    //
                    // 3) Apply P2P one NVALS block at a time
                    //
                    if(targets == sources){
                        P2POuter(inLeafPosition, targets, directNeighbors, neighborPositions, size);
                        P2PHandler.applyInner(idxLeaf,targets);
                    }
                    else{
                        const ContainerClass* const srcPtr[1] = {sources};
                        P2PHandler.applyRemote(idxLeaf,targets,srcPtr,neighborPositions,1);
                        P2PHandler.applyRemote(idxLeaf,targets,directNeighbors,neighborPositions,size);
                    }

                }
            }
        }
    };

    //============================================================
    // UniformKernel::P2POuter
    //------------------------------------------------------------
    /**
     *   Particles to particles (outer version)
     * @param inLeafPosition tree coordinate of the leaf
     * @param targets current box targets particles
     * @param sources current box sources particles (can be == to targets)
     * @param directNeighbors the particles from direct neighbors (this is an array of list)
     * @param size the number of direct neighbors
     */
    //============================================================
    void P2POuter(const FTreeCoordinate& inLeafPosition,
             ContainerClass* const FRestrict targets, 
             ContainerClass* const directNeighbors[], const int neighborPositions[], const int size)
    {
        if(!ApproxNearfield){
    
            const MortonIndex idxLeaf = inLeafPosition.getMortonIndex(TreeHeight-1);
            //
            // 1) Estimate memory requirement (if not yet done) 
            //
            if(!P2PHandler.isMemoryEstimated(idxLeaf)) {
                P2PHandler.estimateMemory(idxLeaf,targets,directNeighbors,size);
            }
            else { // "else" means the P2P is not applied at the first FMM exec !!!
                //
                // 2) Precompute P2P (if not yet done)
                //
                if(!P2PHandler.isPrecomputed(idxLeaf,neighborPositions,size)){
                    // Keep precomputation here, if P2POuter is called from P2P then precomputation is already done, otherwise it should be done!
                    P2PHandler.Precompute(idxLeaf,targets,directNeighbors,neighborPositions,size,MatrixKernel);
                }
                else{ // "else" means the P2P is not applied at the first neither at the second FMM exec !!!
                    //
                    // 3) Apply P2P one NVALS block at a time
                    //
                    int nbNeighborsToCompute = 0;
                    while(nbNeighborsToCompute < size
                          && neighborPositions[nbNeighborsToCompute] < 14){
                        nbNeighborsToCompute += 1;
                    }
                    P2PHandler.applyMutual(idxLeaf,targets,directNeighbors,neighborPositions,nbNeighborsToCompute);

                }
            }
        }
    };


    //============================================================
    // UniformKernel::P2PRemote
    //------------------------------------------------------------
    /**
     *   Particles to particles (remote version)
     * @param inLeafPosition tree coordinate of the leaf
     * @param targets current box targets particles
     * @param sources current box sources particles (can be == to targets)
     * @param directNeighbors the particles from direct neighbors (this is an array of list)
     * @param size the number of direct neighbors
     */
    //============================================================
    void P2PRemote(const FTreeCoordinate& inLeafPosition,
                   ContainerClass* const FRestrict targets, 
                   const ContainerClass* const FRestrict /*sources*/,
                   const ContainerClass* const directNeighbors[], 
                   const int neighborPositions[],
                   const int size)
    {
        if(!ApproxNearfield){
    
            const MortonIndex idxLeaf = inLeafPosition.getMortonIndex(TreeHeight-1);
            //
            // 1) Estimate memory requirement (if not yet done) 
            //
            if(!P2PHandler.isMemoryEstimated(idxLeaf)) {
                P2PHandler.estimateMemory(idxLeaf,targets,directNeighbors,size);
            }
            else { // "else" means the P2P is not applied at the first FMM exec !!!
                //
                // 2) Precompute P2P (if not yet done)
                //
                if(!P2PHandler.isPrecomputed(idxLeaf,neighborPositions,size)){
                    P2PHandler.Precompute(idxLeaf,targets,directNeighbors,neighborPositions,size,MatrixKernel);
                }
                else{ // "else" means the P2P is not applied at the first neither at the second FMM exec !!!
                    //
                    // 3) Apply P2P one NVALS block at a time
                    //
                    P2PHandler.applyRemote(idxLeaf,targets,directNeighbors,neighborPositions,size);

                }
            }
        }
    };

  //============================================================
  // UniformKernel::P2M
  //------------------------------------------------------------
  /**
   * particles to multipole
   * @param pole the multipole to fill using the particles
   * @param particles the particles from the same spacial boxe
   */
  //============================================================
  void P2M(CellClass* const LeafCell,
           const ContainerClass* const SourceParticles)
  {// COPY FROM SCALFMM
    const FPoint<FReal> LeafCellCenter(AbstractBaseClass::getLeafCellCenter(LeafCell->getCoordinate())); 


      // 1) apply Sy
      AbstractBaseClass::Interpolator->applyP2M(LeafCellCenter, AbstractBaseClass::BoxWidthLeaf,
                                                LeafCell->getMultipole(0), SourceParticles);

    for(int idxV = 0 ; idxV < NVALS ; ++idxV){

        // 2) apply Discrete Fourier Transform
        M2LHandler.applyZeroPaddingAndDFT(LeafCell->getMultipole(idxV), 
                                          LeafCell->getTransformedMultipole(idxV));

    }// NVALS
  }


  //============================================================
  // UniformKernel::M2M
  //------------------------------------------------------------
  /**
   * Multipole to multipole
   * @param pole the father (the boxe that contains other ones)
   * @param child the boxe to take values from
   * @param the current computation level
   * the child array has a size of 8 elements (address if exists or 0 otherwise).
   * You must test if a pointer is 0 to know if an element exists inside this array
   */
  //============================================================
  void M2M(CellClass* const FRestrict ParentCell,
           const CellClass*const FRestrict *const FRestrict ChildCells,
           const int /*TreeLevel*/)
  {// COPY FROM SCALFMM
    for(int idxV = 0 ; idxV < NVALS ; ++idxV){

        // 1) apply Sy
        FBlas::scal(AbstractBaseClass::nnodes, FReal(0.), ParentCell->getMultipole(idxV));
        for (unsigned int ChildIndex=0; ChildIndex < 8; ++ChildIndex){
          if (ChildCells[ChildIndex]){
            AbstractBaseClass::Interpolator->applyM2M(ChildIndex, ChildCells[ChildIndex]->getMultipole(idxV),
                                                      ParentCell->getMultipole(idxV));
          }
        }
        // 2) Apply Discete Fourier Transform
        M2LHandler.applyZeroPaddingAndDFT(ParentCell->getMultipole(idxV), 
                                           ParentCell->getTransformedMultipole(idxV));
    }// NVALS
  }

  //============================================================
  // UniformKernel::M2L
  //------------------------------------------------------------
  /**
   * M2L
   * Multipole to local
   * @param local the element to fill using distant neighbors
   * @param distantNeighbors is an array containing fathers's direct neighbors's child - direct neigbors
   * @param neighborPositions indices of the non-empty neighbors
   * @param inSize the number of neighbors
   * @param inLevel the current level of the computation
   */
  //============================================================
  void M2L(CellClass* const FRestrict TargetCell,
           const CellClass* SourceCells[],
           const int neighborPositions[],
           const int inSize,
           const int TreeLevel)
  {// COPY FROM SCALFMM
    const FReal CellWidth(AbstractBaseClass::BoxWidth / FReal(FMath::pow(2, TreeLevel)));
    const FReal scale(MatrixKernel->getScaleFactor(CellWidth));

    for(int idxV = 0 ; idxV < NVALS ; ++idxV){
        // load transformed local expansion
        FComplex<FReal> *const TransformedLocalExpansion = TargetCell->getTransformedLocal(idxV);

        for(int idxExistingNeigh = 0 ; idxExistingNeigh < inSize ; ++idxExistingNeigh){
            const int idxNeigh = neighborPositions[idxExistingNeigh];
            M2LHandler.applyFC(idxNeigh, TreeLevel, scale, 0,
                               SourceCells[idxExistingNeigh]->getTransformedMultipole(idxV),
                               TransformedLocalExpansion);

        }
    }// NVALS
  }


  //============================================================
  // UniformKernel::finishedLevelM2L
  //------------------------------------------------------------
  /** This method can be optionnaly inherited
   * It is called at the end of each computation level during the M2L pass
   * @param level the ending level
   */
  //============================================================
  void finishedLevelM2L(const int /*level*/) {};

  //============================================================
  // UniformKernel::L2L
  //------------------------------------------------------------
  /**
   * L2L
   * Local to local
   * @param local the father to take value from
   * @param child the child to downward values (child may have already been impacted by M2L)
   * @param inLevel the current level of computation
   * the child array has a size of 8 elements (address if exists or 0 otherwise).
   * Children are ordering in the morton index way.
   * You must test if a pointer is 0 to know if an element exists inside this array
   */
  //============================================================
  void L2L(const CellClass* const FRestrict ParentCell,
           CellClass* FRestrict *const FRestrict ChildCells,
           const int /*TreeLevel*/)
  {// COPY FROM SCALFMM
    for(int idxV = 0 ; idxV < NVALS ; ++idxV){
        // 1) Apply Inverse Discete Fourier Transform
        M2LHandler.unapplyZeroPaddingAndDFT(ParentCell->getTransformedLocal(idxV),
                                             const_cast<CellClass*>(ParentCell)->getLocal(idxV));
        // 2) apply Sx
        for (unsigned int ChildIndex=0; ChildIndex < 8; ++ChildIndex){
          if (ChildCells[ChildIndex]){
            AbstractBaseClass::Interpolator->applyL2L(ChildIndex, ParentCell->getLocal(idxV), ChildCells[ChildIndex]->getLocal(idxV));
          }
        }
    }// NVALS
  }

    //============================================================
    // UniformKernel::L2P
    //------------------------------------------------------------
    /**
     * L2P
     * Local to particles
     * @param local the leaf element (smaller boxe local element)
     * @param particles the list of particles inside this boxe
     */
    //============================================================
    void L2P(const CellClass* const LeafCell,
             ContainerClass* const TargetParticles)
    {// COPY FROM SCALFMM

        const FPoint<FReal> LeafCellCenter(AbstractBaseClass::getLeafCellCenter(LeafCell->getCoordinate()));

        for(int idxV = 0 ; idxV < NVALS ; ++idxV){
            // 1)  Apply Inverse Discete Fourier Transform
            M2LHandler.unapplyZeroPaddingAndDFT(LeafCell->getTransformedLocal(idxV), 
                                                const_cast<CellClass*>(LeafCell)->getLocal(idxV));
        }// NVALS

        // 2.a) apply Sx
        AbstractBaseClass::Interpolator->applyL2P(LeafCellCenter, AbstractBaseClass::BoxWidthLeaf,
                                                  LeafCell->getLocal(0), TargetParticles);

    }
  //
  //
private:


};


#endif /* _UNIFORMKERNEL_HPP_ */
