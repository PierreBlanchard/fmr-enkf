#ifndef AdaptiveRRF_HPP
#define AdaptiveRRF_HPP

// standard includes 
#include <stdio.h>
#include <stdlib.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // necessary?
#include "Utils/FMath.hpp"

// FMR includes
#include "Definition/ScalFMMDefines.hpp"


/**
 * @author Pierre Blanchard (pierre.blanchard@inria.fr)
 * @date July 1st, 2014 
 *
 */


/**
 * @brief The Adaptive Random Range Finder class
 */
template<class FReal, class MatrixWrapperClass>
class AdaptiveRRF {

private:

    // needed for FMM
    MatrixWrapperClass* MatrixWrapper;
    // Prescribed accuracy
    const FReal epsilon;
    // Balance parameter
    const int rbal;
    // maximum rank allowed to be computed
    const FSize max_rank;
    // number of power iterations
    const int qPOW;
    // final rank (only needed to get range size with a generic function)
    FSize final_rank;
    // verify matrix multiplication?
    const bool verifyMultiplication;
public:

    /*
     * Ctor
     */
    explicit AdaptiveRRF(MatrixWrapperClass* inMatrixWrapper, const int in_magnitude, const int in_rbal, const FSize in_max_rank, const int in_qPOW = int(0), const bool in_verifyMultiplication = false)
    : MatrixWrapper(inMatrixWrapper), epsilon(FReal(FMath::pow(FReal(.1),FReal(in_magnitude)))), rbal(in_rbal), max_rank(in_max_rank), qPOW(in_qPOW), verifyMultiplication(in_verifyMultiplication)
    {}

    /*
     * Copy ctor
     */
    explicit AdaptiveRRF(const AdaptiveRRF& other)
    : MatrixWrapper(other.MatrixWrapper), epsilon(other.epsilon), rbal(other.rbal), max_rank(other.max_rank), qPOW(other.qPOW), verifyMultiplication(other.verifyMultiplication)
    { }

    /*
     * Dtor
     */
    ~AdaptiveRRF()
    {}

    FSize getRangeSize() { return final_rank; }

    /*
     * multiplyMatrix: This allows the multiplyMatrix() function from MatrixWrapper to be called from RRF. Needed by RandLowRank Algo
     */
    void multiplyMatrix(const FSize nbRows, const FSize nbCols, const FSize rank, FReal* W, FReal* Y, const bool transposeMatrix = false){

        MatrixWrapper->multiplyMatrix(nbRows,nbCols,rank,W,Y,transposeMatrix);
        
    }

    const bool isMatrixSymmetric(){

        return MatrixWrapper->isSymmetric();
        
    }

    /*
     * computeError: This allows the computeError() function from MatrixWrapper to be called from RRF. Needed by RandLowRank Algo
     */
    void computeError(const FSize nbRows, const FSize nbCols, const FSize rank, FReal* W, FReal* Y){

        MatrixWrapper->computeError(nbRows,nbCols,rank,W,Y);
        
    }

    /*
     * updateMaxNormYbal:
     */
    void updateMaxNormYbal(const FSize nbRows, FReal* Y, FReal& max_norm_Ybal, FReal& norm_Y){

        FReal tmp_Y, norm_Yr;

        // r=0
        norm_Yr=FReal(0.);
        for ( FSize i=0; i<nbRows; ++i) {
            tmp_Y = Y[i];
            norm_Yr+=tmp_Y * tmp_Y;
        }
        // update norm of full Y matrix [nbRows*offset]
        norm_Y+=norm_Yr;
        // initialize maximum norm of last rbal vectors
        max_norm_Ybal=FMath::Sqrt(norm_Yr);

        // r>0
        for ( int r=1; r<rbal; ++r) {
            norm_Yr=FReal(0.);
            for ( FSize i=0; i<nbRows; ++i) {
                tmp_Y = Y[r*nbRows+i];
                norm_Yr+=tmp_Y * tmp_Y;
            }

            // update maximum norm of last rbal vectors
            max_norm_Ybal=FMath::Max(FMath::Sqrt(norm_Yr),max_norm_Ybal);
        }

        // normalize maximum norm of last rbal vectors by norm of full matrix Y
        max_norm_Ybal/=FMath::Sqrt(norm_Y);
    }


    /*
     * Find the range of the input matrix with or without explicit C (if C is not assembled explicitely then C=NULL) 
     * using the adaptative variant of RRF algo (Halko).
     * Parameter rank is used as output in order to return the size of the computed range
     * but also as input to specify an upper bound for this rank.
     */
    FSize findRange(const bool readW, const FSize nbRows, const FSize nbCols, FReal* &Q){

        /// Init random number generator (can be moved to ctor)
        //std::default_random_engine generator(/*no seed*/);
        std::default_random_engine generator(std::random_device{}());
        std::normal_distribution<double> distribution(0.0,1.0);
        distribution(generator); // init

        /// Draw $r$ standards gaussian vectors w
        std::cout << "\nGenerate white noise W... \n";
        FTic timeNoise;
        timeNoise.tic();
        FReal *W = new FReal[nbCols*rbal];
        for ( int i=0; i<nbCols; ++i) 
            for ( FSize j=0; j<rbal; ++j)
                W[i+j*nbCols] = FReal(distribution(generator));
        double tNoise = timeNoise.tacAndElapsed();
        std::cout << "... took @tNoise = "<< tNoise <<"\n";

        /// Prepare FMM MMPs
        // Test wether rbal is equal to NVALS 
        // rq: rbal=10 (almost always) and 10 is a good choice for NVALS
        // (besides the first MMP is of size: rbals*size).
        // On the other hand the sampling period should be set to a few NVALS (but NEVER less than NVALS)
        // FMM MMPs will be divided in several NVALS*size MMPs !
        if(MatrixWrapper->getID()==2 && rbal!=NVALS)
            throw std::runtime_error("The adaptive balance parameter rbal and NVALS should be equal! Preferably equal to 10.");
        // The sampling period allows for performing the sampling of C (i.e. the CW MMPS) occuring inside the loop in a blocked way.
        FSize sampling_period=10;
        if(MatrixWrapper->getID()==2 && sampling_period<NVALS)
            throw std::runtime_error("The sampling period should be superior or equal to NVALS! Preferably equal to NVALS.");


        /// Compute Y=CW
        std::cout << "\nPerform Y=CW... \n";
        FTic timeCW;
        timeCW.tic();
        // The maximum rank should be choosen adequatly given N the size of the problem 
        // Better off with a fixed value ~100 rather than a fixed fraction of N
        FReal *Y = new FReal[nbRows*(max_rank+rbal+sampling_period)];
        is_int(int(nbRows*(max_rank+rbal+sampling_period)));
        FBlas::setzero(int(nbRows*(max_rank+rbal+sampling_period)),Y);
        multiplyMatrix(nbRows,nbCols,rbal,W,Y);
        double tCW = timeCW.tacAndElapsed();
        std::cout << "... took @tCW = "<< tCW <<"\n";

        if(verifyMultiplication){
            std::cout << "\nError ||Y-Direct(CW)||\n";
            FTic timeErrorCW;
            timeErrorCW.tic();
            computeError(nbRows,nbCols,rbal,W,Y);
            double tErrorCW = timeErrorCW.tacAndElapsed();
            std::cout << "... took @tErrorCW = "<< tErrorCW <<"\n";
        }

        /// If power iterations required
        // test q=1
        for ( int i=0; i<qPOW; ++i) {
            FReal* CTy = new FReal[nbCols*rbal];
            // Apply C^t to (CW)
            multiplyMatrix(nbRows,nbCols,rbal,Y,CTy,true);
            // Apply C to C^t(CW)
            multiplyMatrix(nbRows,nbCols,rbal,CTy,Y);            
            delete [] CTy;
        }

        /// Init algo
        std::cout << "\nPerform Q=adapQRD(Y)... \n";
        FTic timeAQR;
        timeAQR.tic();
        // counter
        int offset = 0; // $j$ in algo 4.2 of Halko
        // temporary arrays
        FReal *q = new FReal[nbRows];
        FReal *fullQ = new FReal[nbRows*(max_rank+rbal)]; // temporary Q has maximal size
        FReal *w = new FReal[sampling_period*nbCols];

        // output criterion
        const FReal scaled_epsilon = epsilon * FMath::Sqrt(FMath::FPi<FReal>()/FReal(200.));//~ epsilon * 0.125
        FReal max_norm_Ybal(0.); FReal norm_Y(0.);
        this->updateMaxNormYbal(nbRows,Y,max_norm_Ybal,norm_Y);
//    std::cout << "Initial Max_r(|y_r|)="<< max_norm_Ybal << std::endl;

        /// loop until maximum norm of family of $r$ consecutive $y$ reaches prescribed norm 
        /// This ensures the error bound 4.3 in Halko
        while(max_norm_Ybal > scaled_epsilon && offset<max_rank) {

            //// Display current rank
            //std::cout << "offset="<< offset << "\r";
            //std::cout.flush();

            // Overwrite Y_j by (I-Q_{j-1}Q_{j-1}*)Y_j
            if(offset>=1){
                // apply -QQ*
                // ... apply Q*
                FReal *QTy = new FReal[offset];
                is_int(nbRows); is_int(offset); 
                FBlas::gemtv(int(nbRows),int(offset),FReal(1.),fullQ,Y+offset*nbRows,QTy);
                // ... apply Q
                FBlas::gemva(int(nbRows),int(offset),FReal(-1.), fullQ,QTy,Y+offset*nbRows);
                // ...free QTy
                delete [] QTy;
            }
            else{/* nothing to overwrite in Y_j*/}

            // write normalized Y_j in q
            is_int(nbRows);
            FBlas::copy(int(nbRows),Y+offset*nbRows,q); // q = Y_j
            FReal normq=0.;
            for ( int i=0; i<nbRows; ++i) 
              normq+=q[i]*q[i];
            normq=FMath::Sqrt(normq);
            is_int(nbRows);
            FBlas::scal(int(nbRows),FReal(1.)/normq,q); // q /= |q|
            // update matrix Q by adding 1 column.
            is_int(nbRows);
            FBlas::copy(int(nbRows),q,fullQ+offset*nbRows);


            // Blocked random sampling
            if(offset%sampling_period==0) {

                // Draw a set of standard gaussian vectors w_{j+r}
                for ( int r=0; r<sampling_period; ++r)
                    for ( int i=0; i<nbCols; ++i)
                        w[r*nbCols+i] = FReal(distribution(generator));

                // Apply C to the set of vectors w_{j+r} 
                multiplyMatrix(nbRows,nbCols,sampling_period,w,Y+(offset+rbal)*nbRows);
                

                // Do power iterations if required
                for ( int i=0; i<qPOW; ++i) {
                    FReal* CTy = new FReal[nbCols*sampling_period];
                    // Apply C^t to (CW)
                    multiplyMatrix(nbRows,nbCols,sampling_period,Y+(offset+rbal)*nbRows,CTy,true);
                    // Apply C to C^t(CW)
                    multiplyMatrix(nbRows,nbCols,sampling_period,CTy,Y+(offset+rbal)*nbRows);            
                    delete [] CTy;
                }
            
            } // end blocked random sampling

            // Compute Y_{j+r} = (I-Q_{j}Q_{j}*)z ...
            // ... apply Q*
            FReal *QTz = new FReal[offset+1]; 
            is_int(nbRows); is_int(offset+1); 
            FBlas::gemtv(int(nbRows),int(offset+1),FReal(1.),fullQ,Y+(offset+rbal)*nbRows,QTz);
            // ... apply Q
            is_int(nbRows); is_int(offset+1); 
            FBlas::gemva(int(nbRows),int(offset+1),FReal(-1.),fullQ,QTz,Y+(offset+rbal)*nbRows);
            // ...free QTz
            delete [] QTz;

            // for i in [j+1,j+r-1] overwrite Y_i by Y_i - q * <q,Y_i> 
            for ( FSize i=offset+1; i<offset+rbal; ++i){
                // compute <q,Y_i>
                is_int(nbRows);
                FReal qdoty = FBlas::scpr(int(nbRows),q,Y+i*nbRows);
                // compute Y_i = Y_i - q * <q,Y_i>
                is_int(nbRows);
                FBlas::axpy(int(nbRows),-qdoty,q,Y+i*nbRows);
            }

            // update max of Y norms
            this->updateMaxNormYbal(nbRows,Y+(offset+1)*nbRows,max_norm_Ybal,norm_Y);

            // increment offset
            offset++;

        } // end while
        double tAQR = timeAQR.tacAndElapsed();
        std::cout << "... took @tAQR = "<< tAQR <<"\n";

        // Inform user if loop ended because we reached the maximum rank
        if(offset==max_rank) std::cout << "Prescribed accuracy NOT reached for rank=max_rank=" << max_rank << "\n";

        /// Copy Q_j in output matrix Q
        final_rank=offset;
        
        Q = new FReal[final_rank*nbRows];
        // If matvec products are performed with Blas then do not reorder
        is_int(final_rank*nbRows);
        FBlas::copy(int(final_rank*nbRows),fullQ,Q);

        std::cout << "(eps="<< scaled_epsilon << " - max_r(|y_r|)=" << max_norm_Ybal << " - rank=" << final_rank << ")";

        // free memory
        delete [] W;
        delete [] Y;
        delete [] q;
        delete [] w;
        delete [] fullQ;

        // return rank
        return final_rank;

    }


};

#endif /* AdaptiveRRF_HPP */
