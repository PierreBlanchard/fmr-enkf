#ifndef NYSTROM_HPP
#define NYSTROM_HPP

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"
#include "Utils/Display.hpp"

// FMR includes
#include "StandardLRA/PseudoInverse.hpp" // for C^+ or W^+

#include "StandardLRA/SVD.hpp"
#include "Sampling/deterministicSampler.hpp"
#include "Sampling/randomSampler.hpp"
#include "Sampling/Extractor.hpp"

#include "Utils/MatrixNorms.hpp" // for frobenius error computation (DBG improved Nystrom)


/**
 * @brief The Nystrom class
 * 
 * Subsample r columns/rows of M and store subblock in W
 * Then represent M as CW^+C^T with C^T=[W M_{21}^T] and W^+ pseudo-inverse of W
 * M = [  W         M_{21}^T     ]
 *     [M_{21} M_{21}W^+M_{21}^T ]
 */
template<class FReal>
class Nystrom {

private:

    const FSize size;
    const FSize prescribed_rank;
    const int nb_samples_over_rank;
    const int sampling_technique; //< 0: uniform prob; 1: lev scores prob; 2: pivoted QR; 3; k-means (local landmarks)
    const bool with_replacement;  //< 0: without; 1: with
    const int adaptive_sampling;  //< 0: no; 1: standard (initial sampling depend on sampling_technique and with_replacement); 2: [TODO] near-optimal (Uses Random Projection)
    const bool improved_decomposition; //< 0: U=W^+;1: U=(C^+)M(C^+)^T
    // Permutations vector
    FSize* Permutations;
    // Singular values of intersection matrix: "Pseudo" singular values of W if B=W^+, Singular values of (C^+)M(C^+)^T if B=(C^+)M(C^+)^T
    FReal* SigmaB;

public:
    /*
     * Ctor
     */
    explicit Nystrom(const FSize in_size, const FSize in_prescribed_rank, const int in_nb_samples_over_rank, const int in_sampling_technique, const bool in_with_replacement, const int in_adapative_sampling, const bool in_improved_decomposition)
    : size(in_size), prescribed_rank(in_prescribed_rank), nb_samples_over_rank(in_nb_samples_over_rank), sampling_technique(in_sampling_technique), with_replacement(in_with_replacement), adaptive_sampling(in_adapative_sampling), improved_decomposition(in_improved_decomposition), Permutations(nullptr), SigmaB(nullptr)
    {}

    /*
     * Dtor
     */
    ~Nystrom()
    {
        delete [] Permutations;
        delete [] SigmaB;
    }

    FSize* getPermutations() 
    {
        return Permutations;
    }

    FReal* getSigmaB() 
    {
        return SigmaB;
    }

    FSize computeSQRT(/*const*/ FReal* C, FReal* &sqrtC)
    {
        return compute(0, C, sqrtC);
    }


    FSize computeFACT(/*const*/ FReal* C, FReal* &sqrtC)
    {
        return compute(1, C, sqrtC);
    }

    FSize compute(const int fFACT, /*const*/ FReal* C, FReal* &sqrtC)
    {

        // Initial rank
        const FSize init_rank = prescribed_rank;
        // Final rank (initialization)
        FSize rank = prescribed_rank;

        // Number of sampled columns
        const FSize nb_samples = nb_samples_over_rank * prescribed_rank;

        ////////////////////////////////////////////////////////////////////
        /// Sample indices 
        FTic timeSample;
        timeSample.tic();
        std::cout << "\nSample "<< prescribed_rank <<" rows out of the " << size << " rows of C ... \n";
        std::cout << "\n   (Seaking for a rank "<< prescribed_rank <<" approximation of C)\n";
        
        FReal* W = NULL; // W allocated in subsampling routine
        FReal* sampledCols = NULL; // sampledCols allocated in subsampling routine

        // Sample indices wrt sampling technique
        // [TODO] Use a Sampler class instead of a namespace in order to 
        //        - dispatch in a cleaner way
        //        - allow initialization of sampler (with distance matrix or grid for local landmarks; input matrix or filename/fSVD for lev scores; input matrix or filename for adaptive sampling ...)
        //        - uniform random sampling in abstract class or stays
        //        - should implement following methods: sampleCols(), (sampleColsAndRows(),) writeSampledIndices(), getSampledIndices() (called at end of test when writing outputs/stats), 
        if(sampling_technique<=1)
        {
            if(sampling_technique==0) std::cout << " ... uniformly at random.\n";
            else if(sampling_technique==1) std::cout << " ... with probabilities prop. to leverage scores.\n";
            else throw std::runtime_error("Invalid flag for random sampling technique!");
            // ... Random column selection (with or without replacement)
            // 0: uniformly at random (C not required)
            // 1: with proba prop to leverage scores

            if(adaptive_sampling)
            {
                const FSize nb_init_samples = nb_samples;
                const FSize nb_extra_samples = nb_samples;
                randomSampler::sampleIndicesAdaptively(size, rank, C, nb_init_samples, nb_extra_samples, Permutations, sampling_technique, with_replacement);
            }
            else
            {
                randomSampler::sampleIndices(size, rank, C, nb_samples, Permutations, sampling_technique, with_replacement); // discrete distribution of prob, with cte or lev scores proba
            }
        }
        else if(sampling_technique<=4)
        {
            if(sampling_technique==2) std::cout << " ... using random subsampling + alternate pivoted QR on rows/cols.\n";
            else if(sampling_technique==3) std::cout << " ... using k-medoids clustering algorithm (local landmarks).\n";            
            else throw std::runtime_error("Other deterministic sampling techniques are not implemented YET!");
            // ... Deterministic columns selection
            // 2: Random subsampling + alternatePivotedQR
            // 3: Local Landmarks
            // 4: TODO
            deterministicSampler::sampleIndices(size, rank/*NOT USED BY CURRENTLY IMPLEMENTED ALGOS*/, C, nb_samples, Permutations, sampling_technique);
        }
        double tSample = timeSample.tacAndElapsed();
        std::cout << "\n... took @tSample = "<< tSample <<"\n";
        
        // Display sampledIndices
        Display::vector(rank,Permutations,"Permutations",10,1);

        ////////////////////////////////////////////////////////////////////
        /// Extract W and sampled columns
        FTic timeExtract;
        timeExtract.tic();
        std::cout << "\nExtract data... \n";

        // From array
        Extractor::extractWAndC(size,init_rank,C,sampledCols,W,Permutations); // rows are NOT reordered!
        // From file
        // TODO extract values directly from file!!

        double tExtract = timeExtract.tacAndElapsed();
        std::cout << "\n... took @tExtract = "<< tExtract <<"\n";


        //// Display C
        //Display::matrix(size,rank,C,"sampledCols",displaySize);

        ////////////////////////////////////////////////////////////////////
        /// Compute intersection matrix B
        FTic timeIntersection;
        timeIntersection.tic();
        FReal *const B = new FReal [init_rank*init_rank];
        FReal *const S = new FReal [init_rank];

        if(improved_decomposition){

            ////////////////////////////////////////////////////////////////////
            /// Improved Nystrom variant: M~CBC^T with B=(C^+)M(C^+)^T
            ///  
            // Compute C^+, pseudo inverse of C
            FReal *const sampledColsPlus = new FReal [size*init_rank];
            //
            rank = PseudoInverse::compute(size,init_rank,sampledCols,sampledColsPlus);
            // Display sampledColsPlus = C^+
            Display::matrix(size,init_rank,sampledColsPlus,"C^+",10);

            // Assemble B=(C^+)M(C^+)^T
            FReal *const MCPlusT = new FReal[size*init_rank];

            FBlas::setzero(int(size*init_rank),MCPlusT);
            for ( FSize i=0; i<size; ++i)
                for ( FSize j=0; j<init_rank; ++j)
                    for ( FSize k=0; k<size; ++k)
                        MCPlusT[i+j*size]+=C[i+k*size]*sampledColsPlus[j+k*init_rank];

            FReal *const CplusMCPlusT = new FReal[init_rank*init_rank];

            FBlas::setzero(int(init_rank*init_rank),CplusMCPlusT);
            for ( FSize i=0; i<init_rank; ++i)
                for ( FSize j=0; j<init_rank; ++j)
                    for ( FSize k=0; k<size; ++k)
                        CplusMCPlusT[i+j*init_rank]+=sampledColsPlus[i+k*init_rank]*MCPlusT[k+j*size];

            delete [] MCPlusT;

            // Display CplusMCPlusT
            Display::matrix(init_rank,size,CplusMCPlusT,"(C^+)M(C^+)^T",10);

            // TMP: BEGIN 
            // Reconstruct M
            FReal *const CB = new FReal[size*init_rank];
            
            FBlas::setzero(int(size*init_rank),CB);
            for ( FSize i=0; i<size; ++i)
                for ( FSize j=0; j<init_rank; ++j)
                    for ( FSize k=0; k<init_rank; ++k)
                        CB[i+j*size]+=sampledCols[i+k*size]*CplusMCPlusT[k+j*init_rank];

            FReal *const Mapprox = new FReal[size*size];
            
            FBlas::setzero(int(size*size),Mapprox);
            for ( FSize i=0; i<size; ++i)
                for ( FSize j=0; j<size; ++j)
                    for ( FSize k=0; k<init_rank; ++k)
                        Mapprox[i+j*size]+=CB[i+k*size]*sampledCols[j+k*size];


            // Display sampledCols
            Display::matrix(size,size,C,"M",10);
            // Display sampledColsApprox
            Display::matrix(size,size,Mapprox,"Mapprox=C(C^+)M(C^+)^TC^T",10);

            // TMP: END

            // Factorize B=CplusMCPlusT in SVD form
            // Either:
            // - Compute US^{1/2}, i.e. the SVD::SQRT of B
            // - Compute U and S,  i.e. the SVD::SYMSVD of B
            if(fFACT==0)
                std::cout << "\nCompute B^{1/2}, the SVD-SQRT of small intersection matrix B... \n";
            else if(fFACT==1)
                std::cout << "\nCompute B=[U,S], the SVD-FACT of small intersection matrix B... \n";
            else 
                throw std::runtime_error("fFACT has invalid value!");

            FTic timeSmallSVD;
            timeSmallSVD.tic();
            FBlas::setzero(int(init_rank),S);
            if(fFACT==0)
                SVD<FReal>::computeSQRT_withSV(init_rank,CplusMCPlusT,B,S); // if B=USigmaU' then B=US^{1/2} and S=Sigma
            else if(fFACT==1) {
                SVD<FReal>::computeSYMSVD(init_rank,CplusMCPlusT,S,B); // if B=USigmaU' then B=U and S=Sigma
                //////////////////////////////////////////////////////////////////////
                ///// Copy singular values to local array
                //ApproxSingularValues = new FReal[rank];
                //is_int(rank); 
                //FBlas::copy(int(rank),S,ApproxSingularValues);
            
            }
            else throw std::runtime_error("fFACT has invalid value!");

            delete [] CplusMCPlusT;


        }
        else {
            ////////////////////////////////////////////////////////////////////
            /// Standard Nystrom variant: M~CBC^T with B=W^+
            ///  
            /// Compute W^+, the pseudo-inverse of W, in SVD form

            // Display W
            const FSize displaySize = FSize(10);
            Display::matrix(rank,rank,W,"W",displaySize);

            // Compute SVD of W
            // Either:
            // - Compute US^{+/2}, i.e. the SVD::SQRTINV of W
            // - Compute U and S,  i.e. the SVD::SYMSVD of W
            if(fFACT==0)
                std::cout << "\nCompute B=W^+=US^{+/2}, the SVD-SQRTINV of small W matrix... \n";
            else if(fFACT==1)
                std::cout << "\nCompute B=[U,S,S^+], the SVD-FACT of small W matrix... \n";
            else 
                throw std::runtime_error("fFACT has invalid value!");

            FTic timeSmallSVD;
            timeSmallSVD.tic();
            if(fFACT==0){ // Compute pseudo inverse W^+=USigma^{-1/2}
                rank = SVD<FReal>::computeSQRTINV_withSV(init_rank,W,B,S); // if W=USigmaU' then B=US^{-1/2} and S=Sigma
            }
            else if(fFACT==1) {// Compute SVD of symmetric matrix W
                SigmaB = new FReal[rank];
                rank = SVD<FReal>::computeFACT_withSVandSVp(init_rank,W,B,S,SigmaB); // if W=USigmaU' then B=U, S=Sigma, SigmaB=Sigma^{+}
            }
            else 
                throw std::runtime_error("fFACT has invalid value!");
            // Return rank and compare with init_rank
            std::cout << "Rank after inversion of singular values: "<< rank << "(init_rank=" << init_rank << ")" << std::endl;

            double tSmallSVD = timeSmallSVD.tacAndElapsed();
            std::cout << "... took @tSmallSVD = "<< tSmallSVD <<"\n";

        }
        double tIntersection = timeIntersection.tacAndElapsed();
        std::cout << "... took @tIntersection = "<< tIntersection <<"\n";
        //// Display singular values
        //Display::vector(init_rank,S,"S",10,1);

        //// Display B (W^+ if fact=0; U if fact=1)
        // Display::matrix(init_rank,init_rank,B,"B=",10);

        double tAssSQRT = 0;
        ////////////////////////////////////////////////////////////////////
        /// C ~ sampledCols W^+ sampledCols^T -> C^{1/2}~sampledCols W^{+/2}
        FTic timeAssSQRT;
        timeAssSQRT.tic();

        // Allocate sqrtC
        if(!sqrtC) sqrtC = new FReal[size*init_rank];
        else throw std::runtime_error("sqrtC NOT empty!");

        // Compute approximate square root: C^{1/2} ~ sampledCols B^{1/2}
        FBlas::gemm(int(size),int(init_rank),int(rank),FReal(1.),
                     sampledCols,int(size),B,int(init_rank),sqrtC,int(size));
        tAssSQRT = timeAssSQRT.tacAndElapsed();
        std::cout << "... took @tAssSQRT = "<< tAssSQRT <<"\n";

        //// Ensure unicity of sqrt
        //// by imposing first line to be positive
        //ensureUnicityOfSqrt(rank,sqrtC);


        ////////////////////////////////////////////////////////////////////
        /// display results and timings
        std::cout << "\nDetailled timings of RSVD: \n";
        std::cout << "@tSample = "<< tSample <<"\n";
        std::cout << "@tIntersection = "<< tIntersection <<"\n";
        std::cout << "@tAssSQRT = "<< tAssSQRT <<"\n";

        /// free memory
        delete[] sampledCols;
        delete[] W;
        delete[] B;
        delete[] S;

        // return rank
        return rank;

  }

    /*
     * Ensure
     */
    void ensureUnicityOfSqrt(const FSize rank, FReal* &sqrtC)
    {
        for ( FSize j=0; j<rank; ++j)
        {
            // if first entry of line is negative then change sign of entire column
            if (sqrtC[0+j*size]<0) 
                for ( FSize i=0; i<size; ++i)
                    sqrtC[i+j*size]*=-FReal(1.);
        }
    }

};


#endif // NYSTROM_HPP
