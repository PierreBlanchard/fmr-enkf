#ifndef RANDSVD_HPP
#define RANDSVD_HPP

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

// FMR includes
#include "StandardLRA/SVD.hpp"
#include "RandomizedLRA/RandomizedRangeFinder.hpp"
#include "RandomizedLRA/AdaptiveRandomizedRangeFinder.hpp"

/**
 * @brief The RandSVD class
 *
 * TODO had ctor dtor ptr to eigen vectors U and values S
 * TODO possibly writers to file for SQRT, U and S
 * 
 */
template<class FReal, class RandomizedRangeFinderClass>
class RandSVD {

private:

    // Dimensions
    const FSize nbRows;
    const FSize nbCols;
    // Range finder based on random projection
    RandomizedRangeFinderClass* RandRangeFinder;
    // Approximate singular vectors
    FReal* ApproxU;
    FReal* ApproxVT;
    // Approximate singular values
    FReal* ApproxSingularValues;
    // Estimators
    FReal energy2;
    FReal estimator_order_approx;

public:

    /*
     * Ctor
     */
    explicit RandSVD(const FSize inNbRows, const FSize inNbCols, /*const*/ RandomizedRangeFinderClass *const inRandRangeFinder)
    : nbRows(inNbRows), nbCols(inNbCols), RandRangeFinder(inRandRangeFinder), ApproxU(nullptr), ApproxVT(nullptr), ApproxSingularValues(nullptr), energy2(0.0), estimator_order_approx(0.0)
    {}

    /*
     * Dtor
     */
    ~RandSVD()
    {
        delete [] ApproxU;
        delete [] ApproxVT;
        delete [] ApproxSingularValues;
    }

    FReal* getApproxSingularValues() 
    {
        return ApproxSingularValues;
    }

    FReal* getApproxU() 
    {
        return ApproxU;
    }

    FReal* getApproxVT() 
    {
        return ApproxVT;
    }

    FReal getEnergy2() 
    {
        return energy2;
    }

    FReal getApproxBaselineSpec() 
    {
        return estimator_order_approx;
    }

    FSize computeSQRT(const bool readW)
    {
        return compute(0, readW);
    }


    FSize computeFACT(const bool readW)
    {
        return compute(1, readW);
    }


    FSize compute(const int fFACT, const bool readW)
    {

    // Is matrix symmetric? Ask randomized range finder, he knows matrix pretty well.
    const bool matrixIsSymmetric = RandRangeFinder->isMatrixSymmetric();

    ////////////////////////////////////////////////////////////////////
    /// Find range of C
    FTic timeRRF;
    timeRRF.tic();
    std::cout << "\nFind range of C... \n";
    FReal* Q = NULL; // Q allocated in range finder's QRD
    const FSize rank = RandRangeFinder->findRange(readW,nbRows,nbCols,Q); // Q()
    double tRRF = timeRRF.tacAndElapsed();
    std::cout << "\n... took @tRRF = "<< tRRF <<"\n";

    // get size of range (os_rank for RRF, final rank for ARRF)
    const FSize init_rank = RandRangeFinder->getRangeSize();

    FReal* S; FReal* B;
    if(!matrixIsSymmetric)
    {
        ////////////////////////////////////////////////////////////////////
        /// NON SYMMETRIC CASE
        ////////////////////////////////////////////////////////////////////
        std::cout << "\nCompute the SVD-FACT of small CQ matrix... \n";
        ////////////////////////////////////////////////////////////////////
        /// Compute Q^tC ([TODO] for FMM, how to I compute Q^tC? directly? C^tQ then transpose?)
        FTic timeCTQ;
        timeCTQ.tic();
        std::cout << "\nForm CTQ... \n";
        // form CQ 
        FReal *CTQ = new FReal[nbCols*init_rank];
        RandRangeFinder->multiplyMatrix(nbRows,nbCols,init_rank,Q,CTQ,true);
        double tCTQ = timeCTQ.tacAndElapsed();
        std::cout << "... took @tCTQ = "<< tCTQ <<"\n";   

        // Either perform SVD of QTC: pb need to transpose

        // Transposing CTQ, returns (CTQ)^T=QTC
        FReal *QTC = new FReal[init_rank*nbCols];
        for ( int i=0; i<nbCols; ++i) 
            for ( int j=0; j<init_rank; ++j) 
                QTC[j+i*init_rank] = CTQ[i+j*nbCols];
        delete [] CTQ;

        // SVD(r<n): QTC^(r x n)= U^(r x r=min(r,n)) S^(r=min(r,n)) VT^(r=min(r,n) x n) 
        std::cout << "\nCompute SVD of small matrix Q^TC... \n";
        FTic timeSmallSVD;
        timeSmallSVD.tic();
        const FSize minMR = std::min(nbCols,init_rank);
        FAssertLF(minMR==init_rank);
        B = new FReal[init_rank*minMR];
        S = new FReal[minMR];
        FReal* VT = new FReal[minMR*nbCols];
        SVD<FReal>::computeSVD(init_rank,nbCols,QTC,S,B,VT); // call to gesvd, hence first init_rank rows of V'(CQ) in VT
        double tSmallSVD = timeSmallSVD.tacAndElapsed();
        std::cout << "... took @tSmallSVD = "<< tSmallSVD <<"\n";
        // Truncate VT at prescribed rank
        ApproxVT = new FReal[rank*nbCols];
        for ( int i=0; i<rank; ++i)
            for ( int j=0; j<nbCols; ++j) 
                ApproxVT[i+j*rank] = VT[i+j*init_rank];

        delete [] VT;

    }
    else 
    {
        ////////////////////////////////////////////////////////////////////
        /// SYMMETRIC CASE
        ////////////////////////////////////////////////////////////////////
    
        ////////////////////////////////////////////////////////////////////
        /// Compute CQ [TODO]try to compute QtCQ at once
        FTic timeCQ;
        timeCQ.tic();
        std::cout << "\nForm CQ... \n";
        // form CQ 
        FReal *CQ = new FReal[nbRows*init_rank];
        RandRangeFinder->multiplyMatrix(nbRows,nbCols,init_rank,Q,CQ);
        double tCQ = timeCQ.tacAndElapsed();
        std::cout << "... took @tCQ = "<< tCQ <<"\n";        
        ////////////////////////////////////////////////////////////////////
        /// Compute Q^tCQ using dense Q
        FTic timeQTCQ;
        //
        timeQTCQ.tic();
        std::cout << "\nForm QTCQ... ";
        // form Q^T(CQ)
        FReal* QTCQ = new FReal[init_rank*init_rank];
        is_int(nbRows); is_int(init_rank); 
        FBlas::gemtm(int(nbRows),int(init_rank),int(init_rank),FReal(1.),
                     Q,int(nbRows),CQ,int(nbRows),QTCQ,int(init_rank));
        double tQTCQ = timeQTCQ.tacAndElapsed();
        std::cout << "... took @tQCQ = "<< tQTCQ <<"\n";
        delete[] CQ;

        ////////////////////////////////////////////////////////////////////
        /// Compute SVD of small matrix Q^tCQ (sym.) or CQ (no sym.)
        // Either:
        // - Compute US^{1/2}, i.e. the SVD::SQRT of Q^tCQ
        // - Compute U and S,  i.e. the SVD::SYMSVD of Q^tCQ (sym.)
        // - Compute U and S,  i.e. the SVD::SVD of CQ (no sym.)
        if(fFACT==0)
            std::cout << "\nCompute B, the SVD-SQRT of small QtCQ matrix... \n";
        else if(fFACT==1)
            std::cout << "\nCompute B, the SVD-FACT of small QtCQ matrix... \n";
        else 
            throw std::runtime_error("fFACT has invalid value!");

        B = new FReal [init_rank*init_rank];
        is_int(init_rank*init_rank); 
        FBlas::setzero(int(init_rank*init_rank),B);
        S = new FReal [init_rank];
        FTic timeSmallSVD;
        timeSmallSVD.tic();
        if(fFACT==0)
            SVD<FReal>::computeSQRT_withSV(init_rank,QTCQ,B,S); // if QTCQ=USigmaU' then B=US^{1/2} and S=Sigma
        else if(fFACT==1) {
            SVD<FReal>::computeSYMSVD(init_rank,QTCQ,S,B); // if QTCQ=USigmaU' then B=U and S=Sigma
        }
        else 
            throw std::runtime_error("fFACT has invalid value!");
        double tSmallSVD = timeSmallSVD.tacAndElapsed();
        std::cout << "... took @tSmallSVD = "<< tSmallSVD <<"\n";

        // free memory
        delete[] QTCQ;

    }

    ////////////////////////////////////////////////////////////////////
    /// Assemble final factorization:
    /// If symmetric:
    /// - square root of C=QUS^{1/2} or simply QU if only eigenvectors are required.
    /// else
    /// - ApproxU=QU for SVD factorization of rectangular matrix
    FTic timeQB;
    timeQB.tic();
    std::cout << "\nAssemble final factorization/sqrt... ";
    // Allocate sqrtC
    if(!ApproxU) ApproxU = new FReal[nbRows*rank];
    else throw std::runtime_error("sqrtC NOT empty!");
    // Form QB=Q(Q^tCQ)^{1/2} or QU
    is_int(nbRows); is_int(init_rank); is_int(rank); 
    FBlas::gemm(int(nbRows),int(init_rank),int(rank),FReal(1.),
                Q,int(nbRows),B,int(init_rank),ApproxU,int(nbRows));

    double tQB = timeQB.tacAndElapsed();
    std::cout << "... took @tQB = "<< tQB <<"\n";

    // Ensure unicity of sqrt
    // by imposing first line to be positive
    if(matrixIsSymmetric) ensureUnicityOfSqrt(rank,ApproxU);

    delete[] B;

    ////////////////////////////////////////////////////////////////////
    /// Copy singular values to local array
    ApproxSingularValues = new FReal[rank];
    is_int(rank); 
    FBlas::copy(int(rank),S,ApproxSingularValues);


    ////////////////////////////////////////////////////////////////////
    /// Error estimation
    
    // Compute frobenius norm of C_(k) (i.e. energy norm) 
    energy2 = FReal(0.);
    for ( FSize i=0; i<rank; ++i)
        energy2 += S[i]*S[i];

    // Beware! This is NOT the estimator baseline of Halko!!
    // This is just a test! To verify that this value can be used as estimator.
    // Compute an APPROXIMATE error estimator order in spectral norm
    // The baseline $\sigma_{k+1}$ introduced by Halko is a singular value of C,
    // here we take the $k+1$-th SV of $C_{(k)}$. Which approximates the 
    // $k+1$-th SV of $C$. As the oversampling grows, both value converges.
    /*if(oversampling) */estimator_order_approx = S[rank];

    /// free memory
    delete[] Q;
    delete[] S;

    // return rank
    return rank;

  }

    /*
     * Ensure
     */
    void ensureUnicityOfSqrt(const FSize rank, FReal* &sqrtC)
    {
        for ( FSize j=0; j<rank; ++j)
        {
            // if first entry of line is negative then change sign of entire column
            if (sqrtC[0+j*nbRows]<0) 
                for ( FSize i=0; i<nbRows; ++i)
                    sqrtC[i+j*nbRows]*=-FReal(1.);
        }
    }

};


#endif // RANDSVD_HPP
