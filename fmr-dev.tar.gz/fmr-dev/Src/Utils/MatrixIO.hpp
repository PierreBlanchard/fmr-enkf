#ifndef MATRIXIO_HPP
#define MATRIXIO_HPP

// std includes
#include <numeric>
#include <stdexcept>
#include <string>
#include <sstream>
#include <fstream>
#include <typeinfo>

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

// FMR includes


/**
 * @brief The MatrixIO class
 * Beware! Only handles problem sizes representable by int32. 
 */
class MatrixIO {

public:

    template<class ValueType>
    static void write(const FSize size, const FSize rank, ValueType* C, const std::string filename){

        // store into binary file
        std::ofstream stream(filename.c_str(),
                             std::ios::out | std::ios::binary | std::ios::trunc);
        if (stream.good()) {
            stream.seekp(0);
            // 1) write size of problem
            is_int(size);
            int _size = int(size);
            stream.write(reinterpret_cast<char*>(&_size), sizeof(int));
            // 2) write low rank (int)
            is_int(rank);
            int _rank = int(rank);
            stream.write(reinterpret_cast<char*>(&_rank), sizeof(int));
            // 1) write C
            stream.write(reinterpret_cast<char*>(C), sizeof(ValueType)*size*rank);
        }   
        else throw std::runtime_error("File could not be opened to write");
        stream.close();

    }

    // size is updated with the value read in the file
    // rank  is updated with the value read in the file
    template<class ValueType>
    static void read(FSize &size, FSize &rank, ValueType* &C, const std::string filename){

        // start reading process
        if (C) throw std::runtime_error("Matrix C is already set!");

        std::ifstream stream(filename.c_str(),
                             std::ios::in | std::ios::binary | std::ios::ate);
        const std::ifstream::pos_type filesize = stream.tellg();
        if (filesize<=0) {
            std::cout << "Info: The requested binary file " << filename
                      << " does not yet exist. Compute it now ... " << std::endl;
            return;
        } 
        if (stream.good()) {
            stream.seekg(0);
            // 1) read size of problem (int)
            int _size;
            stream.read(reinterpret_cast<char*>(&_size), sizeof(int));
            size=_size;
            // 2) read low rank (int)
            int _rank;
            stream.read(reinterpret_cast<char*>(&_rank), sizeof(int));
            is_int(rank);
            rank=_rank;
            std::cout << "About to read an " << size << " by " << rank << " matrix..." << std::endl;
            // 1) read C
            C = new ValueType[size*rank];
            stream.read(reinterpret_cast<char*>(C), sizeof(ValueType)*size*rank);
        }   else throw std::runtime_error("File could not be opened to read");
        stream.close();
    }

    // Write CSV file (ex: store indices when selecting random reads, *-fmr-items.txt)
    static void writeCSV_idx(const FSize size, FSize* V, const std::string filename){
        
        std::ofstream file(filename);

        for(int row = 0; row < size; ++row)
        {
            file << V[row] << "\n";
        }
        file.close();

    }

    // Write CSV file (ex: store components (positions) after performing MDS)
    static void writeCSV_compo(const FSize size, const FSize rank, FReal* V, const std::string filename){
        
        std::ofstream file(filename);

        // Write header (F1 F2 ... Frank)
        for(int col = 0; col < rank-1; ++col)
            file << "F" << col+1 << "\t";
        file << "F"<< rank << "\n";
        
        // Write positions 
        for(int row = 0; row < size; ++row)
        {
            for(int col = 0; col < rank-1; ++col){
                //// row major
                //file << V[row*rankV+col] << "\t";
                // col major
                file << V[row+col*size] << "\t";
            }
            file << V[row+(rank-1)*size] << "\n";
        }
        file.close();

    }

    // Write CSV file (ex: store approx singular values after performing MDS)
    static void writeCSV_sv(const FSize size, const FSize rank, FReal* V, const std::string filename, const int lowres = 1){
        
        std::ofstream file(filename);

        // Write header SINGVALS

        if(lowres>1)
            file << "IDX\t"; 
        if(rank==1)
            file << "SINGVALS" << "\n";
        else if(rank==3)
            file << "SINGVALS\tOESREL\tOEFREL" << "\n";
        else if(rank==4)
            file << "SINGVALS\tOESREL\tOEFREL\tDIAGVTU" << "\n";

        // Write positions 
        int varyingres=1;
        for(int row = 0; row < size; row+=varyingres)
        {
            if(lowres>1)
                file << row+1 << "\t";
            if(row>9) varyingres=lowres;
            for(int col = 0; col < rank; ++col)
                file << V[row+col*size] << "\t";
            file << "\n";
        }
        file.close();

    }

    // Write CSV file (ex: store leverage score using various norms)
    static void writeCSV_lev(const FSize size, const FSize rank, FReal* V, const std::string filename){
        
        std::ofstream file(filename);

        // Write header SINGVALS
        if(rank==10)
            file << "10P\t20P\t30P\t40P\t50P\t60P\t70P\t80P\t90P\t100P\t" << "\n";

        // Write positions 
        for(int row = 0; row < size; ++row)
        {
            for(int col = 0; col < rank; ++col)
                file << V[row+col*size] << "\t";
            file << "\n";
        }
        file.close();

    }

    // Write CSV file (ex: coherence)
    static void writeCSV_coh(const FSize rank, const FSize maxrank, FReal* V, const std::string filename){
        
        std::ofstream file(filename);

        // Write header SINGVALS
        file << "RANK\tMINLS\tMAXLS\tAVGLS\tDEVLS" << "\n";

        // Write positions 
        for(int row = 0; row < 10; ++row)
        {
                file << (row+1)*maxrank/10 << "\t" << V[row+0*4] << "\t" << V[row+1*10] << "\t" << V[row+2*10] << "\t" << V[row+3*10] << "\t";
            file << "\n";
        }
        file.close();

    }

    // Write CSV file (ex: partition/clustering)
    static void writeCSV_part(const FSize size, const int nbDim, const FReal* Grid, const int* partitions, const std::string filename){
        
        std::ofstream file(filename);

        // Write header SINGVALS
        file << "D0\tD1\tD2\tPART" << "\n";

        // Write positions 
        for(int row = 0; row < size; ++row)
        {
                file << Grid[row+0*size] << "\t" << Grid[row+1*size] << "\t" << Grid[row+2*size] << "\t" << partitions[row] << "\t";
            file << "\n";
        }
        file.close();

    }

    // Read CSV file (See SampleIO for distance matrices used in MDS)
    template<class ValueType>
    static void readCSV(const FSize size, const FSize rank, ValueType* &C, const std::string filename, const char delim, const bool withHeader = false){
        
        std::ifstream file(filename);

        std::string line;
        if(withHeader) // skip first line
            std::getline(file, line);

        for(int row = 0; row < size; ++row)
        {

            std::getline(file, line);
            // PB: the following test skips the last line...
            //if ( !file.good() ) 
            //    break;

            std::stringstream iss(line);

            for (int col = 0; col < rank; ++col)
            {
                std::string val;
                std::getline(iss, val, delim);
                // PB: the following test skips the last line...
                //if ( !iss.good() ) 
                //    break;

                std::stringstream convertor(val);
                convertor >> C[row+col*size];
            }
        }

    }


    // Read CSV file (ex: for distance matrix used in MDS)
    // TODO finalize
    // TODO ensure all required lines are read!! Problem if last line is empty
    static void readCSV_ukSize(FSize &size, FSize &rank, FReal* &C, const std::string filename, const char delim){
        
        // Beware! In reads_random_1k.txt last line is empty... => for now use readCSV (i.e. with known size)


        std::ifstream file(filename);

        // Init counter
        FSize countEle = 0;
        FSize countRow = 0;
        FSize countCol=0;
        FSize countInnerLoops=0;

        //for(int row = 0; row < sizeC; ++row)
        // Size not known, read while file is good
        while(file.good())
        {
            std::cout << "countRow=" << countRow << "\n" ;

            std::string line;
            std::getline(file, line);

            // PB: the following test skips the last line...
            //if ( !file.good() ) {
            //    std::cout << "File no good!" << "\n" ;
            //    break;
            //}
            std::stringstream iss(line);

            //for (int col = 0; col < rank; ++col)
            countCol=0;
            countInnerLoops=0;
            // Size not known, read while file is good
            while(iss.good())
            {
                std::string val;
                std::getline(iss, val, delim);

                // PB: the following test skips the last col...
                //if ( !iss.good() ) {
                //    std::cout << "Iss no good!" << "\n" ;
                //    break;
                //}

                // ignore first value of lne (a 0 char is automatically appended to the line)
                if(countInnerLoops>0){
                    std::stringstream convertor(val);
                    convertor >> C[countEle];
                    countCol++;
                    countEle++;
                }
                //std::cout << "    countEle=" << countEle << " - countCol=" << countCol << " - val=" << val << "\n" ;

                countInnerLoops++;

            }

            countRow++;

        }

        //// ignore first character of line
        //countEle--;

        //// display counters
        std::cout << "countEle=" << countEle << "\n" ;
        std::cout << "countInnerLoops=" << countInnerLoops << "\n" ;
        std::cout << "countCol=" << countCol << "\n" ;
        std::cout << "countRow=" << countRow << "\n" ;

        // Update actual sizes
        size=countRow;
        rank=countCol; // ignore first character

    }

};


#endif // MatrixIO_HPP
