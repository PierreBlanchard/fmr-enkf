#ifndef DISPLAY_HPP
#define DISPLAY_HPP



// std includes
#include <numeric>
#include <stdexcept>
#include <string>
#include <sstream>
#include <fstream>
#include <typeinfo>

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

// FMR includes


/**
 * @brief The Dislay class
 * 
 */
class Display {

public:

    template<class ValueType>
    static void matrix(const FSize size, const FSize rank, ValueType* matrix, const std::string name, const FSize displaySize, const int part=0){

        std::cout<<"\n"<< name <<"=["<<std::endl;
        for ( FSize i=0; i<displaySize; ++i) {
            for ( FSize j=0; j<displaySize; ++j)
                std::cout << matrix[i+j*size] << " ";
            std::cout<< std::endl;
        }
        std::cout<<"]"<<std::endl;

    }

    template<class ValueType>
    static void vector(const FSize size, ValueType* vector, const std::string name, const FSize displaySize, const int part=0){

        std::cout<<"\n"<< name <<"=["<<std::endl;
        if(part>=0){
            for ( FSize i=0; i<displaySize; ++i) {
                std::cout << vector[i] << " ";
            }            
        }
        if(part==1){
            std::cout<<" [...] ";
            for ( FSize i=size-1-displaySize; i<size; ++i) {
                std::cout << vector[i] << " ";
            }
        }
        std::cout<<"]"<<std::endl;

    }


};


#endif // DISPLAY_HPP
