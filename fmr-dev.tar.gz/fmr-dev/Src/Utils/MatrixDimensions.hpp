#ifndef MATRIXDIMENSIONS_HPP
#define MATRIXDIMENSIONS_HPP

// std includes
//#include <stdio.h>
//#include <stdlib.h>
#include <stdexcept>
#include <limits>

// ScalFMM includes
#include "Utils/FGlobal.hpp"

// Check if size can be represented by int, otherwise crashes and return error message!
static void is_int(FSize size) {
    if(!(size<std::numeric_limits<int>::max())) 
        throw std::runtime_error("Size is too large to be converted to integer!");
}


#endif // MATRIXDIMENSIONS_HPP
