#ifndef MATRIXNORMS_HPP
#define MATRIXNORMS_HPP


// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for 
#include "Utils/FMath.hpp"

// FMR includes
#include "StandardLRA/SVD.hpp"


/**
 * @brief The Matrix Norms class
 */
template<class FReal>
class MatrixNorms {

public:

  /*
   * Computes and returns Spectral norm of $A$, using expression in terms of largest singular values.
   * \param A contains input square matrix
   * \param size contains number of col/rows of A
   */
    static FReal computeSpectral(const FSize size, const FReal* A){

        // Compute SVD of A
        FReal *const S  = new FReal [size];
        SVD<FReal>::computeSVD(size,size,A,S);

        return S[0];

    }

  /*
   * Computes and returns Frobenius norm of $A$, using expression in terms of entrywise norm by default. Expression in terms of singular values is also available (flagSV = true).
   * \param A contains input square matrix
   * \param size contains number of col/rows of A
   */
    static FReal computeFrobenius(const FSize size, const FReal* A, const bool flagSV = false){

        FReal norm = 0.;

        if(!flagSV){

            // Compute norm
            for ( FSize i=0; i<size; ++i) {
                for ( FSize j=0; j<size; ++j) {
                    norm += A[i*size+j]*A[i*size+j];
                }
            }
            
        }
        else{

            // Compute SVD of A
            FReal *const S  = new FReal [size];
            SVD<FReal>::computeSVD(size,size,A,S);

            // Compute norm
            for ( FSize i=0; i<size; ++i)
                norm += S[i]*S[i];

        }

        return FMath::Sqrt(norm);

    }

};


template<class FReal>
class FrobeniusError {

    FReal error;
    FReal norm;

public:
    
    explicit FrobeniusError() 
        : error(FReal(0.)), norm(FReal(0.)) {}

    void add(const FReal A_ref, const FReal A = FReal(0.)){
        error += (A - A_ref)*(A - A_ref);
    }

    void addRel(const FReal A_ref, const FReal A = FReal(0.)){
        error += (A - A_ref)*(A - A_ref);
        norm  += A_ref*A_ref;
    }

    FReal getNorm(){
        return FMath::Sqrt(error);
    }

    FReal getRelativeNorm(){
        return FMath::Sqrt(error/norm);
    }

    FReal getReferenceNorm2(){
        return norm;
    }


};


#endif // MATRIXNORMS_HPP
