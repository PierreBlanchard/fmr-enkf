#ifndef ERRORESTIMATORS_HPP
#define ERRORESTIMATORS_HPP


// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for 
#include "Utils/FMath.hpp"

// FMR includes


/**
 * @brief The Error Estimators class
 */
template<class FReal>
class ErrorEstimators {

public:

    /*
     * Computes and returns the lower bound for any Randomized Range Finder 
     * and both Frobenius and Spectral norms
     */
    static const FReal lowerBound() {
        return FReal(0.);
    }

    /*
     * Computes and returns the upper bound for any Randomized Range Finder 
     * in Frobenius norm
     * TODO add expression in latex
     */
    static FReal upperAverageBoundFrobenius(const int qRSI, const FSize k, const int p) {
        if(qRSI==0) // RRF
            return FReal(FMath::Sqrt(FReal(1.)+FReal(k)/FReal(p-1))) - FReal(1.);
        else { //RSI
            //BEWARE! The upper average bound when q>0 is not given by Halko, 
            // because no proof yet!! Therefore we use the bound for q=0.
            return FReal(FMath::Sqrt(FReal(1.)+FReal(k)/FReal(p-1))) - FReal(1.);
        }
    }

    /*
     * Computes the error estimator for any Randomized Range Finder 
     * in Spectral norm
     * TODO add expression in latex
     *
     * \param residual_energy contains value of $(\sum_{j>k} \sigma_j(A)^2)^{1/2}$ if known otherwise replace by its upper bound, namely $\sqrt{min(m,n)-k}$.
     */
    static FReal upperAverageBoundSpectral(const int qRSI, const FSize k, const int p, const FReal residual) {
        if(qRSI==0) // RRF
            return FReal(FReal(1.)+FMath::Sqrt(FReal(k)/FReal(p-1))+FMath::Exp(FReal(0.))*FMath::Sqrt(FReal(k+p))/FReal(p)*residual) - FReal(1.);
        else { //RSI
            // Halko p.277
            return FMath::pow(FReal(FReal(1.)+FMath::Sqrt(FReal(k)/FReal(p-1))+FMath::Exp(FReal(0.))*FMath::Sqrt(FReal(k+p))/FReal(p)*residual),FReal(1.)/FReal(2*qRSI+1)) - FReal(1.);
        }
    }
 


};


#endif // ERRORESTIMATORS_HPP
