#ifndef VECTORNORMS_HPP
#define VECTORNORMS_HPP


// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for 
#include "Utils/FMath.hpp"

// FMR Includes


/**
 * @brief The Vector Norms class
*/
template <class FReal, class IndexType = FSize>
class VectorNorms {
    IndexType    nbElements;
    FReal one;
    FReal two;
    FReal max;
public:
    VectorNorms() : nbElements(0), one(0.0), two(0.0), max(0.0) {
    }
    /** with inital values */
    VectorNorms(const FReal inGood[], const IndexType nbValues)
        :  nbElements(0), one(0.0), two(0.0), max(0.0) {
        add(inGood, nbValues);
    }


    /** Add value to the current list */
    void add(const FReal inVal){
        one          += FMath::Abs(inVal);
        two          += (inVal) * (inVal);
        max           = FMath::Max(max , FMath::Abs(inVal));
        nbElements += 1 ;
    }
    /** Add array of values */
    void add(const FReal inVal[], const IndexType nbValues){
        for(IndexType idx = 0 ; idx < nbValues ; ++idx){
            add(inVal[idx]);
        }
        nbElements += nbValues ;
    }

    /** Add an accurater*/
    void add(const VectorNorms& inVec){
        one += inVec.getOne();
        two +=  inVec.getTwo();
        max = FMath::Max(max,inVec.getMax());
        nbElements += inVec.getNbElements();
    }
    FReal getOne() const{
        return one;
    }
    FReal getTwo() const{
        return two;
    }
    FReal getMax() const{
        return max;
    }
    IndexType getNbElements() const{
        return nbElements;
    }
    void  setNbElements(const IndexType & n) {
        nbElements = n;
    }

    /** Get the root mean squared error*/
    FReal getL1Norm() const{
        return one;
    }

    /** Get the root mean squared error*/
    FReal getL2Norm() const{
        return FMath::Sqrt(two);
    }

    /** Get the inf norm */
    FReal getInfNorm() const{
        return max;
    }

    /** Print */
    template <class StreamClass>
    friend StreamClass& operator<<(StreamClass& output, const VectorNorms& inVectorNorms){
        output << "[Error] Relative L1Norm = " << inVectorNorms.getL1Norm()
            << " \t Relative L2Norm = " << inVectorNorms.getL2Norm() 
            << " \t Relative Inf = " << inVectorNorms.getInfNorm();
        return output;
    }

    void reset()
    {
        one          = FReal(0);
        two          = FReal(0);;
        max            = FReal(0);
        nbElements = 0 ;
    }
};

#endif // VECTORNORMS_HPP