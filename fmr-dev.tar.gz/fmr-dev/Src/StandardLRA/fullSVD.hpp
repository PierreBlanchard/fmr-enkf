#ifndef FULLSVD_HPP
#define FULLSVD_HPP

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

// FMR includes
#include "Utils/Display.hpp"
#include "Utils/MatrixIO.hpp"


/**
 * @brief The SVD class
 */
template<class FReal>
class fullSVD {

public:


    static void ReadIfExists_ComputeAndWriteOtherwise(const FSize nbRows, const FSize nbCols, /*const (comment for gemm)*/ FReal* M, FReal* &Sigma, const std::string insvfilename, const bool matrixIsSymmetric, const bool economy = false){

        // Verbose
        const int verbose = 1;
        const FSize displaySize = 10;

        //
        const std::string svfilename = insvfilename + ".txt";

        // Declare array to write in file
        FReal* SVDINFO;
        // Declare optimal errors
        FReal* optErrorSpec;
        FReal* optErrorFrob;

        // test input file 
        std::cout << "Singular values of full matrix already precomputed?"<< std::endl;
        // Measure size of file. If >0 read file, else compute SVD and write file.
        // NB: "ate" makes a difference as it position cursor at end of file
        // which of course affects the value of filesize
        std::ifstream t_svfile( svfilename.c_str(), std::ios::in | std::ios::ate);
        const std::ifstream::pos_type filesize = t_svfile.tellg();
        t_svfile.close();

        // Size
        const FSize svdSize = std::min(nbRows,nbCols);

        FSize sizeSVDINFO = svdSize;
        FSize rankSVDINFO = 3; // SINGVALS, OESPEC, OEFROB

        // Allocate memory for singular values and optimal errors
        optErrorSpec = new FReal[svdSize];
        optErrorFrob = new FReal[svdSize];
        SVDINFO = new FReal[svdSize*rankSVDINFO];
        Sigma = new FReal[svdSize];

        if(filesize>0) { // Yes? Then read it from file

            std::cout << ">> Yes, then read it from file ("<< svfilename <<")."<< std::endl;

            MatrixIO::readCSV(sizeSVDINFO,rankSVDINFO,SVDINFO,svfilename,'\t',true);

            // Copy SVD infos
            for(FSize i = 0 ; i<sizeSVDINFO ; ++i){
                       Sigma[i]=SVDINFO[i+0*sizeSVDINFO];
                optErrorSpec[i]=SVDINFO[i+1*sizeSVDINFO];
                optErrorFrob[i]=SVDINFO[i+2*sizeSVDINFO];
            }

            //
            MatrixIO::readCSV(sizeSVDINFO,rankSVDINFO,SVDINFO,svfilename,'\t',true);

            // Write in lower resolution
            const FSize resolution = 10;
            const std::string svfilenamelowres = insvfilename + "-lowres.txt";
            MatrixIO::writeCSV_sv(sizeSVDINFO,rankSVDINFO,SVDINFO,svfilenamelowres,resolution);


        }
        else { // No? Then compute it and store in file

            std::cout << ">> No, then compute and store it in file ("<< svfilename <<")."<< std::endl;

            if(economy){
                std::cout << "    Compute economy size SVD of M, i.e. SVD of " ;
                // Compute M2
                FTic timeM2;
                timeM2.tic();
                FSize economySize = std::min(nbRows,nbCols);
                FReal* M2 = new FReal[economySize*economySize];
                if(nbCols==economySize){ // tall-thin
                    std::cout << "    ... M2=M^tM, since M is tall-thin." << std::endl;
                    FBlas::gemtm(int(nbRows),int(nbCols),int(nbCols),FReal(1.),M,int(nbRows),M,int(nbRows),M2,int(economySize));
                }
                else{ // short fat
                    std::cout << "    ... M2=MM^t, since M is short-fat."<< std::endl;
                    FBlas::gemmt(int(nbRows),int(nbRows),int(nbCols),FReal(1.),M,int(nbRows),M,int(nbRows),M2,int(economySize));
                }
                double tM2 = timeM2.tacAndElapsed();
                std::cout << "    ... took @tM2 = " << tM2 <<"\n";

                // Compute SVD of M2
                std::cout << "    ... Then SVD of M2 and take square root of singular values" ;
                timeM2.tic();
                SVD<FReal>::computeSYMSVD(economySize,M2,Sigma);
                for(FSize i = 0 ; i<svdSize; ++i)
                    Sigma[i]=FMath::Sqrt(Sigma[i]);
                double tSVDM2 = timeM2.tacAndElapsed();
                std::cout << "... took @tSVDM2 = " << tSVDM2 <<"\n";

                delete[] M2;
            }
            else{
                // Compute SVD of M
                if(matrixIsSymmetric) // symmetric matrix (ensure U = V)
                    SVD<FReal>::computeSYMSVD(nbRows,M,Sigma);
                else // rectangular or square
                    SVD<FReal>::computeSVD(nbRows,nbCols,M,Sigma);          
            }

            // Optimal/Minimal errors in Spectral norm (first entry has no meaning, should be equal to 1)
            for(FSize i = 0 ; i<svdSize ; ++i)
                optErrorSpec[i]=FMath::Abs(Sigma[i]/Sigma[0]);
            // Optimal/Minimal errors in Frobenius norm
            optErrorFrob[svdSize-1]=Sigma[svdSize-1]*Sigma[svdSize-1];
            for(FSize i = svdSize-2 ; i>=0 ; --i){
                optErrorFrob[i]=optErrorFrob[i+1]+Sigma[i]*Sigma[i];
            }
            FBlas::scal(int(svdSize),FReal(1.)/optErrorFrob[0],optErrorFrob);
            
            for(FSize i = 0 ; i<svdSize-1 ; ++i)
                optErrorFrob[i]=FMath::Sqrt(optErrorFrob[i]);

            // Display singular values
            if(verbose>=1){
                Display::vector(svdSize,Sigma,"Sigma",displaySize,1);
                Display::vector(svdSize,optErrorSpec,"OES",displaySize,1);
                Display::vector(svdSize,optErrorFrob,"OEF",displaySize,1);
            }

            // Copy SVD infos
            for(FSize i = 0 ; i<sizeSVDINFO ; ++i){
                SVDINFO[i+0*sizeSVDINFO]=Sigma[i];
                SVDINFO[i+1*sizeSVDINFO]=optErrorSpec[i];
                SVDINFO[i+2*sizeSVDINFO]=optErrorFrob[i];
            }

            delete [] optErrorSpec;
            delete [] optErrorFrob;

            //// Write singular values in binary file
            //MatrixIO::write(matrixSize,1,Sigma,svfilename);
            // Write singular values in text file
            MatrixIO::writeCSV_sv(sizeSVDINFO,rankSVDINFO,SVDINFO,svfilename);


        } // end compute and store SVD(M)

        delete[] SVDINFO;



    }

};


#endif // FULLSVD_HPP
