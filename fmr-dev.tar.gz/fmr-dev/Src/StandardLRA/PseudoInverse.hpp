#ifndef PseudoInverse_HPP
#define PseudoInverse_HPP

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

// FMR includes
#include "Utils/Display.hpp"

// ... pseudo inverse specific
#include "StandardLRA/SVD.hpp" // for svd
#include "Utils/MatrixNorms.hpp" // for frobenius error computation (DBG pseudo inverse)



/**
 * @brief The PseudoInverse class
 */
class PseudoInverse {

public:




    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Pseudo-Inverse wrapper
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    // list of functions:
    // * static void compute(const FSize nbRows, const FSize nbCols, const FReal* M, FReal* Mp)
    // * 
    // 

  /*
   * Compute Pseudo-Inverse $Mp=VSpU^T$ and return rank, $V$, $Sp$ and $U^T$.
   * \param M contains input rectangular m-by-n matrix to be decomposed   
   * \param Mp contains $U$
   */
  static FSize compute(const FSize nbRows, const FSize nbCols, const FReal* M, FReal* MPlus){
    // verbose
    const bool verbose = false;

    // 
    const FSize initRank = std::min(nbRows,nbCols);

    // Compute SVD of C 
    FTic timeRectSVD;
    timeRectSVD.tic();
    FReal *const U = new FReal[nbRows*nbCols];
    FReal *const Sigma = new FReal [initRank];
    FBlas::setzero(int(initRank),Sigma);
    FReal *const VT = new FReal[nbRows*initRank];

    SVD<FReal>::computeSVD(nbRows,initRank,M,Sigma,U,VT);

    double tRectSVD = timeRectSVD.tacAndElapsed();
    std::cout << "... took @tRectSVD = "<< tRectSVD <<"\n";
    
    const bool dbg = false;
    if(dbg)
    {

      // Verify SVD of C 
      FReal *const approxM = new FReal [nbRows*initRank];
      FBlas::setzero(int(nbRows*initRank),approxM);
      for ( FSize i=0; i<nbRows; ++i)
          for ( FSize j=0; j<initRank; ++j)
              for ( FSize k=0; k<initRank; ++k)
                  approxM[i+j*nbRows]+=U[i+k*nbRows]*Sigma[k]*VT[k+j*nbRows];

      if(verbose)
      {   
        // Display M
        Display::matrix(nbRows,nbCols,M,"M",10);
        // Display approxM
        Display::matrix(nbRows,nbCols,approxM,"M_Approx",10);
      }

      // Compute error in Frobenius norm
      std::cout << "Error ||M - M_Approx ||_F\n";
      FrobeniusError<FReal> frobError;
      for ( FSize i=0; i<nbRows; ++i) 
          for ( FSize j=0; j<nbCols; ++j)
              frobError.addRel(M[i+j*nbRows],approxM[i+j*nbRows]);
      std::cout << " Frob    = "<< frobError.getNorm() <<"\n";
      std::cout << " FrobRel = "<< frobError.getRelativeNorm() <<"\n";

      // free memory
      delete [] approxM;

    }

    // Invert singular values of M
    FReal *const SigmaPlus = new FReal [initRank];
    const FSize rank = SVD<FReal>::invertSV(initRank,Sigma,SigmaPlus);
    // Compute M^+, the pseudo-inverse of M
    //MPlus = new FReal [nbRows*initRank];
    FBlas::setzero(int(nbRows*initRank),MPlus);
    for ( FSize i=0; i<initRank; ++i)
        for ( FSize j=0; j<nbRows; ++j)
            for ( FSize k=0; k<rank; ++k)
                MPlus[i+j*initRank]+=U[j+k*nbRows]*SigmaPlus[k]*VT[k+i*nbRows];

    // free memory
    delete [] U;
    delete [] Sigma;
    delete [] VT;

    // return rank
    return rank;

  }

};


#endif // SVD_HPP
