#ifndef QRD_HPP
#define QRD_HPP

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for QRD (via FBlas::geqrf), explicit Q computation (via FBlas::orgqr) and pivoted QR decomposition
#include "Utils/FMath.hpp"

// FMR includes


/**
 * @brief The QRD class
 */
template<class FReal>
class QRD {

public:

  /*
   * Compute QRD $A=QR$ and return $Q$.
   * \param A contains input square matrix to be decomposed
   * \param Q contains $Q$
   */
  static void computeQRD(const FSize size, const FSize rank, const FReal* A, FReal* &Q){

    // init QRD
    int INFO;
    const FSize LWORK = 2 * (3*size + size);
    FReal *const WORK = new FReal [LWORK];
    FReal* tau = new FReal [rank];
    // copy A in Qout
    FReal *Qout = new FReal[rank*size]; // output is stored in col major
    is_int(size*rank);
    FBlas::copy(int(size*rank),A,Qout);

    // QRD of Y
    std::cout << "\nPerform QRD...";
    FTic timeQRD;
    timeQRD.tic();
    is_int(size); is_int(rank); is_int(LWORK);
    INFO = FBlas::geqrf(int(size), int(rank), Qout, tau, int(LWORK), WORK);
    if(INFO!=0) {
      std::stringstream stream;
      stream << INFO;
      throw std::runtime_error(" failed! INFO=" + stream.str());
    }
    //else {std::cout << " succeed!" << std::endl;}
    double tQRD = timeQRD.tacAndElapsed();
    std::cout << "... took @tQRD = "<< tQRD <<"\n";

    // get Q
    FTic timeGETQ;
    timeGETQ.tic();
    is_int(size); is_int(rank); is_int(LWORK);
    INFO = FBlas::orgqr(int(size), int(rank), Qout, tau, int(LWORK), WORK);
    if(INFO!=0) {
      std::stringstream stream;
      stream << INFO;
      throw std::runtime_error("get Q failed! INFO=" + stream.str());
    }
    double tGETQ = timeGETQ.tacAndElapsed();
    std::cout << "... took @tGETQ = "<< tGETQ <<"\n";

    // Reorder Q in row major
    FTic timeCPQ;
    timeCPQ.tic();
    //delete [] Q;
    Q = new FReal[rank*size];
    is_int(rank*size);
    FBlas::copy(int(rank*size),Qout,Q); // do not reorder but input mat needs to be r*size+i
//    for ( int i=0; i<size; ++i)
//      for ( int j=0; j<rank; ++j)
//        Q[i*rank+j] = Qout[i+j*size];
    double tCPQ = timeCPQ.tacAndElapsed();
    std::cout << "... took @tCPQ = "<< tCPQ <<"\n";


    // free memory
    delete [] tau;
    delete [] WORK;
    delete [] Qout;

  }

    /*
     * Compute pivoted QRD $A=QR$ and return $Q$ and indices of rank most important columns.
     * \param A contains input rectangle matrix to be decomposed
     * \param permutation contains indices of rank most important columns if nbRows<nbCols, rows if nbRows>nbCols
     */
    static void computePivotedQRD(const FSize nbRows, const FSize nbCols, const FReal* M,  const FSize rank, FSize* &permutation){


        // Rename sizes
        const FSize m = nbRows;
        const FSize n = nbCols;

        // copy M in MM
        FReal* MM = new FReal [m * n]; // matrix: column major ordering
        for (FSize ii=0; ii<m; ++ii)
            for (FSize jj=0; jj<n; ++jj)
                MM[ii + jj*m]=M[ii + jj*m];

        // Workspace
        // init SVD
        const FSize minMN = std::min(m,n);
        //const FSize LWORK = 2*4*minMN; // for square matrices
        //const FSize LWORK = 2*std::max(3*minMN+maxMN, 5*minMN);
        const FSize LWORK = 3*n+1; // minimum value from online doc
        FReal *const WORK = new FReal[LWORK];
        FReal* TAU = new FReal[minMN];

        // Pivot
        unsigned* jpiv = new unsigned[n]; 

        // perform Cholesky decomposition
        std::cout<<"\nQR decomposition ";
        FTic timeQR;
        int INFO = FBlas::geqp3(int(m), int(n), MM, jpiv, TAU, int(LWORK), WORK);

        if(INFO==0) {std::cout<<"succeeded!"<<std::endl;}
        else {std::cout<<"failed!"<<std::endl;}

        double tQR = timeQR.tacAndElapsed();
        std::cout << "... took @tQR = "<< tQR <<"\n";


        // free memory
        delete [] MM;
        delete [] TAU;
        delete [] WORK;

        // Keep only first rank indices
        permutation = new FSize[rank];
        for (FSize i=0; i<rank; ++i)
            permutation[i]=FSize(jpiv[i]);

        // free memory
        delete [] jpiv;

    }

};


#endif // QRD_HPP
