#ifndef SVD_HPP
#define SVD_HPP

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // for SVD (via FBlas::gesvd)
#include "Utils/FMath.hpp"

// FMR includes
#include "Utils/Display.hpp"



/**
 * @brief The SVD class
 */
template<class FReal>
class SVD {
public:

/**
 * @brief The SVD namespace
 */
//[TODO]namespace SVD {

    static FSize getNumericalRank(const FReal* S, const FSize size, const FReal eps)
    {
        const FReal nrm2 = FBlas::scpr(int(size), S, S);
        FReal nrm2k(0.);
        for (FSize k=size; k>0; --k) {
            nrm2k += S[k-1] * S[k-1];
            if (nrm2k > eps*eps * nrm2) return k;
        }
        throw std::runtime_error("rank cannot be larger than size");
        return 0;
    }

  // Beware! Does not necessarily mean that A=USU' with S non-negative! Use has_sqrt()
  static bool is_nonnegative(const FSize size, const FReal* A){
    // allocate spectrum
    FReal *S = new FReal[size];
    // compute SVD
    computeSVD(size,size,A,S);
    // test non-negativeness
    for (int i=0; i<size; ++i)
      if(S[i]<=-1e-15) return false;
    return true;
  }

  // 
  static bool has_sqrt(const FSize size, const FReal* A){
    // allocate spectrum
    FReal *S = new FReal[size];
    // compute SVD
    computeSYMSVD(size,A,S);
    // test non-negativeness
    for (int i=0; i<size; ++i)
      if(S[i]<=-1e-15) return false;
    return true;
  }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    // SVD wrappers
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    // list of functions:
    // * static void computeSYMSVD(const FSize size, const FReal* A, FReal* S, FReal* C)
    // * static void computeSYMSVD(const FSize size, const FReal* A, FReal* S)
    // * static void computeSVD(const FSize size, const FReal* A, FReal* S, FReal* C, FReal* Q)
    // * static void computeSVD(const FSize size, const FReal* A, FReal* S, FReal* C)
    // * static void computeSVD(const FSize size, const FReal* A, FReal* S)

    // 
    static void ensureUequalV(const FSize size, /*const*/ FReal* U, /*const*/ FReal* Vt, FReal* &S){

        // Compute VtU=V'*U
        FReal* VtU = new FReal[size*size];
        FBlas::gemm(int(size), int(size), int(size), FReal(1.), Vt, int(size), U, int(size), VtU, int(size));

        // Display diag(VtU)
        FReal* diagVtU = new FReal[size];
        for ( int i=0; i<size; ++i)
            diagVtU[i]=VtU[i+i*size];
        delete [] VtU;
        Display::vector(size,diagVtU,"diag(VtU)",10,1);

        std::cout << "Matrix is non-negative? ";
        bool isSPSD = true;
        for ( FSize i=0; i<size; ++i) {
            if(diagVtU[i]<FReal(-0.999)){

                //std::cout << "VtU["<<i<<","<<i<<"]=" << diagVtU[i] << std::endl;
                ////
                //std::cout << "Change sign of " << i << "-th singular value." << std::endl;
                //
                S[i]=-S[i];
                //
                // indicate that matrix is not SPSD
                if(S[i]<-1.e-14)
                   isSPSD = false;

            }
        }
        if(isSPSD) std::cout << "YES!" << std::endl;
        else std::cout << "NO, matrix has negative singular values!" << std::endl;

        // free memory
        delete[] diagVtU;
    }


  /*
   * Compute SVD $A=USU'$ and return $U$ and $S$.
   * If matrix not non-negative then S contains negative values !
   * \param A contains input square matrix to be decomposed
   * \param S contains singular values $S$
   * \param C contains $U$
   */
  static void computeSYMSVD(const FSize size, const FReal* A, FReal* S, FReal* C){
    // verbose
    const bool verbose = false;
    // copy A
    is_int(size*size);
    FBlas::copy(int(size*size),A,C);
    // init SVD
    const FSize LWORK = 2*4*size;
    FReal *const WORK = new FReal [LWORK];
    // singular value decomposition
    FReal *const Q = new FReal [size*size];

    if(verbose) std::cout << "\nPerform SVD...";
    // SO means that first min(m,n) lines of U overwritten on Q and V' on C (A=QSC)
    // AA means all lines
    // nothing means OS (the opposite of SO, A=CSQ) 
    is_int(size); is_int(LWORK);
    const unsigned int INFOSVD
      = FBlas::gesvd(int(size), int(size), C, S, Q, int(size),
                     int(LWORK), WORK);
    if(verbose) {
        if(INFOSVD!=0) {std::cout << " failed!" << std::endl;}
        else {std::cout << " succeed!" << std::endl;}
    }
//    // Display U
//    std::cout<<"\nU=["<<std::endl;
//    for ( int i=0; i</*sizeGrid[level]*/10; ++i) {
//      for ( int j=0; j</*sizeGrid[level]*/10; ++j)
//        std::cout << C[i*size+j] << " ";
//      std::cout<< std::endl;
//    }
//    std::cout<<"]"<<std::endl;
//
//    // Display V'
//    std::cout<<"\nV'=["<<std::endl;
//    for ( int i=0; i</*sizeGrid[level]*/10; ++i) {
//      for ( int j=0; j</*sizeGrid[level]*/10; ++j)
//        std::cout << Q[i+j*size] << " ";
//      std::cout<< std::endl;
//    }
//    std::cout<<"]"<<std::endl;

    // Ensure U=V by checkin diagonal of V'U
    ensureUequalV(size,C,Q,S); 

    // free memory
    delete[] WORK;
    delete[] Q;

  }

  /*
   * Compute SVD $A=USU'$ and return $S$.
   * If matrix not non-negative then S contains negative values !
   * \param A contains input square matrix to be decomposed
   * \param S contains singular values $S$
   */
  static void computeSYMSVD(const FSize size, const FReal* A, FReal* S){
    // verbose
    const bool verbose = false;
    // copy A
    FReal* C = new FReal[size*size];
    is_int(size*size);
    FBlas::copy(int(size*size),A,C);
    // init SVD
    const FSize LWORK = 2*4*size;
    FReal *const WORK = new FReal [LWORK];
    // singular value decomposition
    FReal *const Q = new FReal [size*size];

    if(verbose) std::cout << "\nPerform SVD...";
    // SO means that first min(m,n) lines of U overwritten on Q and V' on C (A=QSC)
    // AA means all lines
    // nothing means OS (the opposite of SO, A=CSQ) 
    is_int(size); is_int(LWORK);
    const unsigned int INFOSVD
      = FBlas::gesvd(int(size), int(size), C, S, Q, int(size),
                     int(LWORK), WORK);
    if(verbose) {
        if(INFOSVD!=0) {std::cout << " failed!" << std::endl;}
        else {std::cout << " succeed!" << std::endl;}
    }

    // Ensure U=V by checkin diagonal of V'U
    ensureUequalV(size,C,Q,S); 

    // free memory
    delete[] WORK;
    delete[] Q;
  }

  /*
   * Compute SVD $A=USV'$ and return $V'$, $S$ and $U$.
   * \param A contains input m-by-n matrix to be decomposed
   * \param S contains output min(m,n) singular values $S$
   * \param U contains output m-by-min(m,n) matrix $U$
   * \param VT contains output min(m,n)-by-n matrix $V'$
   */
  static void computeSVD(const FSize m, const FSize n,  const FReal* A, FReal* S, FReal* U, FReal* VT){
    // verbose
    const bool verbose = false;
    // Left and Right singular vectors 
    // Please allocate U[m x min(m,n)] VT[min(m,n) x n]
    
    // copy A
    is_int(m*n);
    if(m>=n) FBlas::copy(int(m*n),A,U);
    else FBlas::copy(int(m*n),A,VT);

    // init SVD
    const FSize minMN= std::min(m,n);
    const FSize maxMN= std::max(m,n);
    const FSize LWORK = 2*std::max(3*minMN+maxMN, 5*minMN);
    //const FSize LWORK = 2*4*size;
    FReal *const WORK = new FReal [LWORK];
    // singular value decomposition
    if(verbose) std::cout << "\nPerform SVD...";

    // How does gesvdXX function?
    // gesvdXX(m,n,B,S,C,ldC)
    // SO means that first min(m,n) lines of U overwritten on 3rd array and V' on 1st array (i.e. A=VT*S*U)
    // nothing means OS (the opposite of SO, i.e. A=U*S*VT)
    // AA means all lines
    // Should be used if we want to overwrite U on A (m>n) or VT on A (m<n). 
    // This is not the case in general for this library.
    is_int(m); is_int(n); is_int(LWORK);
    unsigned int INFOSVD;
    if(m>=n)
        INFOSVD  = FBlas::gesvd(int(m), int(n), U, S, VT, int(n), int(LWORK), WORK);
    else //if (m<n)
        INFOSVD  = FBlas::gesvdSO(int(m), int(n), VT, S, U, int(m), int(LWORK), WORK);
    //else
    //    INFOSVD  = FBlas::gesvdAA(int(m), int(n), U, S, VT, int(minMN), int(LWORK), WORK);
    if(INFOSVD!=0) {std::cout << " failed!" << std::endl;}
    else { if(verbose) std::cout << " succeed!" << std::endl;}

    // free memory
    delete[] WORK;
  }

  /*
   * Compute SVD $A=USV'$ and return $V'$ and $S$.
   * \param A contains input m-by-n matrix to be decomposed
   * \param S contains singular values $S$
   * \param U contains output m-by-min(m,n) matrix $U$
   */
  static void computeSVD(const FSize m, const FSize n, const FReal* A, FReal* S, FReal* U){
    // 
    const FSize minMN= std::min(m,n);
    // Allocate memory
    FReal *const VT = new FReal [minMN*n];
    // Compute SVD
    computeSVD(m,n,A,S,U,VT);

    // free memory
    delete[] VT;
  }

  /*
   * Compute SVD $A=USV'$ and return $S$.
   * \param A contains input m-by-n matrix to be decomposed
   * \param S contains singular values $S$
   */
  static void computeSVD(const FSize m, const FSize n, const FReal* A, FReal* S){
    //
    const FSize minMN= std::min(m,n);
    // Allocate memory
    FReal *const U = new FReal [m*minMN];
    FReal *const VT = new FReal [minMN*n];

    // Compute SVD
    computeSVD(m,n,A,S,U,VT);

    // free memory
    delete[] U;
    delete[] VT;

  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  // SVD::SQRT wrappers
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  // list of functions:
  // * static void computeSQRT(const FSize size, const FReal* A, FReal* sqrtA)
  // * static void computeSYMSQRT(const FSize size, const FReal* A, FReal* sqrtA)
  // * static void computeSYMSQRT_withSV(const FSize size, const FReal* A, FReal* sqrtA, FReal* S)
  // * static void computeSQRT_withSV(const FSize size, const FReal* A, FReal* sqrtA, FReal* S)
  // * static void computeSQRTINV_withSV(const FSize size, const FReal* A, FReal* sqrtA, FReal* S)


  static void computeSQRT(const FSize size, const FReal* A, FReal* sqrtA){

    // init SVD
    FReal *const S  = new FReal [size];

    // Perform SVD
    computeSYMSVD(size,A,S,sqrtA);

    // Tolerance for square root computation
    FReal machine_precision;
    if(sizeof(FReal)==4) machine_precision=FReal(1.e-7);
    else if(sizeof(FReal)==8) machine_precision=FReal(1.e-14);
    else throw std::runtime_error("Wrong value type!");
    const FReal tol = machine_precision;

    // Compute square root of S
    for (FSize i=0; i<size; ++i){

        //if(S[i]<=-1e-15)
        //  throw std::runtime_error("A has negative singular values! Cannot take square root!");
        //else
        //  S[i]=FMath::Sqrt(S[i]);
        if(FMath::Abs(S[i])<=tol) S[i]=0;
        else if(FMath::Abs(S[i])>tol && S[i]>=0.) S[i]=FMath::Sqrt(S[i]);
        else 
          throw std::runtime_error("A has negative singular values! Cannot take square root!");

      
    }

    // form US^{1/2}
    is_int(size);
    for ( FSize j=0; j<size; ++j) 
        FBlas::scal(int(size),S[j],sqrtA+j*size);

    // free memory
    delete[] S;

  }

  static void computeSYMSQRT(const FSize size, const FReal* A, FReal* sqrtA){

    // init SVD
    FReal *const S  = new FReal [size];
    FReal *const U  = new FReal [size*size]; // in col major

    // Perform SVD
    computeSYMSVD(size,A,S,U);

    // Tolerance for square root computation
    FReal machine_precision;
    if(sizeof(FReal)==4) machine_precision=FReal(1.e-7);
    else if(sizeof(FReal)==8) machine_precision=FReal(1.e-14);
    else throw std::runtime_error("Wrong value type!");
    const FReal tol = machine_precision;

    // Compute square root of S
    for (int i=0; i<size; ++i){

      if(FMath::Abs(S[i])<=tol) S[i]=0;
      else if(FMath::Abs(S[i])>tol && S[i]>=0.) S[i]=FMath::Sqrt(S[i]);
      else throw std::runtime_error("A has negative singular values! Cannot take square root!");

    }

    // form B=US^{1/2}
    FReal *const B  = new FReal [size*size]; // in col major
    for ( FSize i=0; i<size; ++i) 
      for ( FSize j=0; j<size; ++j) 
        B[i+j*size]=U[i+j*size]*S[j];

    // form BU^t
    is_int(size);
    FBlas::gemmt(int(size),int(size),int(size),FReal(1.),
                 B,int(size),U,int(size),sqrtA,int(size));

    // free memory
    delete[] S;
    delete[] U;
    delete[] B;

  }


    static void computeSYMSQRT_withSV(const FSize size, const FReal* A, FReal* sqrtA, FReal* S){

    // init SVD
    FReal *const U  = new FReal [size*size]; // in col major

    // Perform SVD
    computeSYMSVD(size,A,S,U);

    // Tolerance for square root computation
    FReal machine_precision;
    if(sizeof(FReal)==4) machine_precision=FReal(1.e-7);
    else if(sizeof(FReal)==8) machine_precision=FReal(1.e-14);
    else throw std::runtime_error("Wrong value type!");
    const FReal tol = machine_precision;

    // Compute square root of S
    FReal *const sqrtS = new FReal [size];
    for (FSize i=0; i<size; ++i){

        if(FMath::Abs(S[i])<=tol) sqrtS[i]=0;
        else if(FMath::Abs(S[i])>tol && S[i]>=0.) sqrtS[i]=FMath::Sqrt(S[i]);
        else throw std::runtime_error("A has negative singular values! Cannot take square root!");

    }

    // form B=US^{1/2}
    FReal *const B  = new FReal [size*size]; // in col major
    for ( FSize i=0; i<size; ++i) 
      for ( FSize j=0; j<size; ++j) 
        B[i+j*size]=U[i+j*size]*sqrtS[j];

    // form BU^t
    is_int(size);
    FBlas::gemmt(int(size),int(size),int(size),FReal(1.),
                 B,int(size),U,int(size),sqrtA,int(size));

    // free memory
    delete[] sqrtS;
    delete[] U;
    delete[] B;

  }


    static void computeSQRT_withSV(const FSize size, const FReal* A, FReal* sqrtA, FReal* S){

    // Perform SVD
    computeSYMSVD(size,A,S,sqrtA);

    // Tolerance for square root computation
    FReal machine_precision;
    if(sizeof(FReal)==4) machine_precision=FReal(1.e-7);
    else if(sizeof(FReal)==8) machine_precision=FReal(1.e-14);
    else throw std::runtime_error("Wrong value type!");
    const FReal tol = machine_precision;

    // Compute square root of S
    FReal *const sqrtS = new FReal [size];
    for (FSize i=0; i<size; ++i){

        if(FMath::Abs(S[i])<=tol) sqrtS[i]=0;
        else if(FMath::Abs(S[i])>tol && S[i]>=0.) sqrtS[i]=FMath::Sqrt(S[i]);
        else throw std::runtime_error("A has negative singular values! Cannot take square root!");

    }

    // form B=US^{1/2}
    is_int(size);
    for ( FSize j=0; j<size; ++j) 
        FBlas::scal(int(size),sqrtS[j],sqrtA+j*size);

    // free memory
    delete[] sqrtS;

  }

    static FSize computeSQRTINV_withSV(const FSize size, const FReal* A, FReal* sqrtA, FReal* S){

    // Perform SVD
    computeSYMSVD(size,A,S,sqrtA); // calls ensureUequalsV() => sign of S might be changed

    //// Display S
    //std::cout << "S=[" ;
    //for (int i=0; i<size; ++i) 
    //    std::cout << S[i] << " " ;
    //std::cout << "]" << std::endl;

    // Tolerance for pseudo inverse spectrum
    FReal machine_precision;
    if(sizeof(FReal)==4) machine_precision=FReal(1.e-7);
    else if(sizeof(FReal)==8) machine_precision=FReal(1.e-14);
    else throw std::runtime_error("Wrong value type!");
    const FReal tol = FReal(size)*machine_precision*S[0];
    // Init final rank for truncation to tolerance
    FSize rank=-1;

    // Compute square root of S
    FReal *const sqrtinvS = new FReal[size];
    for (FSize i=0; i<size; ++i){

        if(FMath::Abs(S[i])<=tol) {sqrtinvS[i]=0; if(rank==-1) rank=i;}
        else if(FMath::Abs(S[i])>tol && S[i]>0.) sqrtinvS[i]=FMath::Sqrt(FReal(1.)/S[i]);
        else throw std::runtime_error("A has negative singular values! Cannot take square root!");

    }

    if(rank==-1) rank=size;

    // Display S^{-1/2}
    std::cout << "S^{-1/2}=[" ;
    for (int i=0; i<size; ++i) 
        std::cout << sqrtinvS[i] << " " ;
    std::cout << "]" << std::endl;

    // form B=US^{1/2}
    is_int(rank);
    for ( FSize j=0; j<rank; ++j) 
        FBlas::scal(int(size),sqrtinvS[j],sqrtA+j*size);

    // free memory
    delete[] sqrtinvS;

    // Return nb of non zero values in S^{-1/2}
    return rank;

  }

    static FSize invertSV(const FSize size, const FReal* S,  FReal* invS){

        // Display S
        std::cout << "S=[" ;
        for (int i=0; i<size; ++i) 
            std::cout << S[i] << " " ;
        std::cout << "]" << std::endl;

        // Tolerance for pseudo inverse spectrum
        FReal machine_precision;
        if(sizeof(FReal)==4) machine_precision=FReal(1.e-7);
        else if(sizeof(FReal)==8) machine_precision=FReal(1.e-14);
        else throw std::runtime_error("Wrong value type!");
        const FReal tol = FReal(size)*machine_precision*S[0];
        // Init final rank for truncation to tolerance
        FSize rank=-1;

        // Compute inverse of S
        for (FSize i=0; i<size; ++i){

            if(FMath::Abs(S[i])<=tol) {invS[i]=0; if(rank==-1) rank=i;}
            else if(FMath::Abs(S[i])>tol) invS[i]=FReal(1.)/S[i];
            else throw std::runtime_error("Case not accounted for!");

        }

        if(rank==-1) rank=size;

        // Display S^{+}
        std::cout << "S^{+}=[" ;
        for (int i=0; i<size; ++i) 
            std::cout << invS[i] << " " ;
        std::cout << "]" << std::endl;


        // Return nb of non zero values in S^{+}
        return rank;

    }

    static FSize computeFACT_withSVandSVp(const FSize size, const FReal* A, FReal* U, FReal* S, FReal* invS){

    // Perform SVD
    computeSYMSVD(size,A,S,U); // calls ensureUequalsV() => sign of S might be changed

    // Invert singular values
    const FSize rank = invertSV(size,S,invS);

    // Return nb of non zero values in S^{+}
    return rank;

  }


};


#endif // SVD_HPP
