#ifndef RANDOMFIELDGENERATOR_HPP
#define RANDOMFIELDGENERATOR_HPP

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" 
#include "Utils/FMath.hpp"
//#include "Utils/FNoCopyable.hpp"

// FMR includes
#include "Correlations/CorrelationKernels.hpp"

/**
 * @author Pierre Blanchard (pierre.blanchard@inria.fr)
 * @date April 16th, 2015 
 *
 * TODO Implement FFT and CHOLESKY variants
 *
 */



template <class FReal>
class RandomFieldGenerator //: FNoCopyable
{
    //enum {};

private:

    // dimensions
    const FSize sizeGrid;
    const FSize rank;
    const FSize sizeCheckGrid;
    const int matrix_structure;
    const int nbReal;
    const int nbThreads;
    const int sizeBlock; // This affects the efficiency of C^{1/2} application A LOT (using Blass::gemm)

    // arrays
    FReal **X, **Y;
    FReal **meanX, **meanY;
    FReal **varY;


public:

    /**
    * Constructor: 
    */
    explicit RandomFieldGenerator(const FSize in_sizeGrid, const FSize in_rank, const int in_matrix_structure, const int in_powReal, const int in_ratioFullVsCheck)
    : sizeGrid(in_sizeGrid), rank(in_rank), sizeCheckGrid(in_sizeGrid/in_ratioFullVsCheck), matrix_structure(in_matrix_structure), nbReal(FMath::pow(10,in_powReal)),
    nbThreads(omp_get_max_threads()), sizeBlock(100)
    {

        /// Display number of threads
        std::cout << "@nbThreads = "<< nbThreads <<"\n";
        /// Display number of realizations
        std::cout << "@nReal = "<< nbReal <<"\n";
        /// Display number of realizations to compute at each loop and per thread 
        std::cout << "@sizeBlock = "<< sizeBlock <<"\n";

        /// Evaluate memory requirements
        const FSize totMEM = sizeof(FReal)*nbThreads*(sizeGrid*2*(sizeBlock+1)+sizeCheckGrid*sizeCheckGrid);
        std::cout << "@memGRF = "<< totMEM <<"\n";

        /// Allocate blocks
        // Uncorrelated variables X
        X = new FReal*[nbThreads]; // Control memory requirements!
        for ( int idxThread=0; idxThread<nbThreads; ++idxThread) // Do nbThread group of loops in parallel
          X[idxThread] = new FReal[sizeGrid*sizeBlock]; // Control memory requirements!
        // Correlated variables Y
        Y = new FReal*[nbThreads]; // Control memory requirements!
        for ( int idxThread=0; idxThread<nbThreads; ++idxThread) // Do nbThread group of loops in parallel
          Y[idxThread] = new FReal[sizeGrid*sizeBlock]; // Control memory requirements!

        // mean of uncorrelated variables
        meanX = new FReal*[nbThreads];
        for ( int idxThread=0; idxThread<nbThreads; ++idxThread) // Do nbThread group of loops in parallel
          meanX[idxThread] = new FReal[sizeGrid]; // Control memory requirements!
        // mean of correlated variables
        meanY = new FReal*[nbThreads];
        for ( int idxThread=0; idxThread<nbThreads; ++idxThread) // Do nbThread group of loops in parallel
          meanY[idxThread] = new FReal[sizeGrid]; // Control memory requirements!

        // sample covariance matrix Y
        varY = new FReal*[nbThreads];
        for ( int idxThread=0; idxThread<nbThreads; ++idxThread) // Do nbThread group of loops in parallel
            varY[idxThread] = new FReal[sizeCheckGrid*sizeCheckGrid];

    }

    /**
    * Destructor: Delete dynamically allocated memory for ...
    */
    ~RandomFieldGenerator()
    {
        for ( int idxThread=0; idxThread<nbThreads; ++idxThread){
            if(    X[idxThread]!=nullptr) delete[]     X[idxThread];
            if(meanX[idxThread]!=nullptr) delete[] meanX[idxThread];
            if(    Y[idxThread]!=nullptr) delete[]     Y[idxThread];
            if(meanY[idxThread]!=nullptr) delete[] meanY[idxThread];
            if( varY[idxThread]!=nullptr) delete[]  varY[idxThread];
        }

        delete[] X;
        delete[] Y;
        delete[] meanX;
        delete[] meanY;
        delete[] varY; 
    }

    void writeRealizations(const std::string visufilename, const FPoint<FReal>* t, const FReal *const inX) 
    {

        std::ofstream file( visufilename.c_str(), std::ofstream::out);

        FReal *particles = new FReal[8*sizeGrid];
        for ( FSize i=0; i<sizeGrid; ++i){
            particles[i*8  ] = t[i].getX();
            particles[i*8+1] = t[i].getY();
            particles[i*8+2] = t[i].getZ();
            particles[i*8+3] = inX[i+0*sizeGrid];
            particles[i*8+4] = inX[i+1*sizeGrid];
            particles[i*8+5] = inX[i+2*sizeGrid];
            particles[i*8+6] = inX[i+3*sizeGrid];
            particles[i*8+7] = inX[i+4*sizeGrid];   
        }
        std::cout << "Write distributions in .vtp file. "<< visufilename <<std::endl ;
        exportVTKxml( file, particles, sizeGrid, 8);

    }

    void displaySampleCovariance(const FSize sizeDisp = 20) 
    {
        // display sample-estimate covariance matrix of Y 
        // varY should approximate C if nb of realization sufficiently large
        std::cout<<"\nvarY[thread0]=["<<std::endl;
        for ( FSize i=0; i<sizeDisp; ++i) {
          for ( FSize j=0; j<sizeDisp; ++j)
            std::cout << varY[0][i*sizeCheckGrid+j] << " ";
          std::cout<< std::endl;
        }
        std::cout<<"]"<<std::endl;

    }

    void computeSampleCovarianceErrors(const FReal *const C) 
    {

        // Compute errors
        FMath::FAccurater<FReal> errorSampleC;
        for ( FSize i=0; i<sizeCheckGrid; ++i)
            for ( FSize j=0; j<sizeCheckGrid; ++j)
                errorSampleC.add(C[i*sizeGrid+j],varY[0][i*sizeCheckGrid+j]);

        // Display errors
        std::cout<<"\nError on covariance matrix (for " << sizeCheckGrid << " checkpoints / " << sizeGrid << " grid points): "<<std::endl;
        std::cout << "Error ||C - sample(C)||\n";
        std::cout << "@errorSC_Frob = "<< errorSampleC.getL2Norm() <<"\n";
        std::cout << "@errorSC_L2 = "<< errorSampleC.getRelativeL2Norm() <<"\n";
        std::cout << "@errorSC_Inf = "<< errorSampleC.getRelativeInfNorm() <<"\n";

    }

    template<class CorrelationKernelClass>
    void computeSampleCovarianceErrors(const CorrelationKernelClass *const CorrelationKernel, const FPoint<FReal>* t) 
    {

        // Compute errors
        FMath::FAccurater<FReal> errorSampleC;
        for ( FSize i=0; i<sizeCheckGrid; ++i)
            for ( FSize j=0; j<sizeCheckGrid; ++j)                 
                errorSampleC.add(CorrelationKernel->evaluate(t[i],t[j]),varY[0][i*sizeCheckGrid+j]);
        
        // Display errors
        std::cout<<"\nError on covariance matrix (for " << sizeCheckGrid << " checkpoints / " << sizeGrid << " grid points): "<<std::endl;
        std::cout << "Error ||C - sample(C)||\n";
        std::cout << "@errorSC_Frob = "<< errorSampleC.getL2Norm() <<"\n";
        std::cout << "@errorSC_L2 = "<< errorSampleC.getRelativeL2Norm() <<"\n";
        std::cout << "@errorSC_Inf = "<< errorSampleC.getRelativeInfNorm() <<"\n";

    }

    void visualize(/*const*/ FReal *const sqrtC, 
                    const std::string distributionname, const std::string outfilename, 
                    const FPoint<FReal>* grid, const FReal BoxWidth, const FPoint<FReal> CenterOfBox) 
    {

        //////////////////////////////////////////////////////////////////
        /// Write test X (if does not exist already) and resulting Y in visualization file (.vtp)

        // Test white noise input file
        std::string testXfmafilename("../Data/Visu/Distributions/"+ distributionname +"_WhiteNoiseX.bfma");
        std::string testXvtpfilename("../Data/Visu/Distributions/"+ distributionname +"_WhiteNoiseX.vtp");

        // declare and allocate testX
        FReal* testX = new FReal[5*sizeGrid];

        ////////////////////////////////////////////////////////////////////
        /// Init white noise generator
        std::default_random_engine generator;//(seed);
        std::normal_distribution<FReal> distribution(FReal(0.0),FReal(1.0));
        distribution(generator); // init

        // test input file 
        std::cout << "Test white noise X already computed?"<< std::endl;
        // NB: "ate" makes a difference as it position cursor at end of file
        // which of course affects the value of filesize
        std::ifstream t_file( testXfmafilename.c_str(), std::ios::in | std::ios::ate);
        const std::ifstream::pos_type filesize = t_file.tellg();
        t_file.close();
        if(filesize>0) { // Yes? Then read it from file
            std::cout << ">> Yes, then read it from file."<< std::endl;
            // open particle file
            FFmaGenericLoader<FReal> loader(testXfmafilename,true);
            if(!loader.isOpen()) throw std::runtime_error("testX file couldn't be opened!");
            // read particles properties (Potential and Forces) and copy in testX
            for(FSize idxPart = 0 ; idxPart < sizeGrid ; ++idxPart){
                FPoint<FReal> position;
                const unsigned int nbDataToRead = 8;
                FReal* DataToRead = new FReal[8];
                loader.fillParticle(DataToRead,nbDataToRead);
                testX[0*sizeGrid+idxPart]=DataToRead[3];
                testX[1*sizeGrid+idxPart]=DataToRead[4];
                testX[2*sizeGrid+idxPart]=DataToRead[5];
                testX[3*sizeGrid+idxPart]=DataToRead[6];
                testX[4*sizeGrid+idxPart]=DataToRead[7];
            }

        }
        else { // No? Then compute it and store in file
            std::cout << ">> No, then compute and store it in file."<< std::endl;
            // Compute testX
            for(FSize idxPart = 0 ; idxPart < 5*sizeGrid ; ++idxPart)
                testX[idxPart]=distribution(generator);

            // Write testX in BFMA file (X Y Z X0 X1 X2 X3 X4)
            {
                FReal * particles ;
                particles = new FReal[8*sizeGrid] ;
                memset(particles,0,8*sizeGrid*sizeof(FReal));
                FmaRWParticle<FReal,4,8> *ppart = (FmaRWParticle<FReal,4,8>*)(&particles[0]);
                for(FSize i = 0 ; i<sizeGrid ; ++i){
                    particles[i*8+0] = grid[i].getX();
                    particles[i*8+1] = grid[i].getY();
                    particles[i*8+2] = grid[i].getZ();
                    particles[i*8+3] = testX[i+0*sizeGrid];
                    particles[i*8+4] = testX[i+1*sizeGrid];
                    particles[i*8+5] = testX[i+2*sizeGrid];
                    particles[i*8+6] = testX[i+3*sizeGrid];
                    particles[i*8+7] = testX[i+4*sizeGrid];
                }
                std::cout << "Write "<< sizeGrid <<" Particles in file " << testXfmafilename <<std::endl;
                FFmaGenericWriter<FReal> writer(testXfmafilename,true) ;
                writer.writeHeader(CenterOfBox, BoxWidth, sizeGrid, *ppart) ;
                writer.writeArrayOfParticles(ppart, sizeGrid);
                std::cout << "    End of writing "<<std::endl;
                delete [] particles ;
            }

            // Write testX in VTP file
            writeRealizations(testXvtpfilename, grid, testX);

        }

        ////////////////////////////////////////////////////////////////////
        // Generate realization of Gaussian Random Field

        // declare and allocate testY
        FReal* testY = new FReal[5*sizeGrid];

        // Applying C^{1/2} to X
        is_int(sizeGrid); is_int(rank);
        FBlas::gemm(int(sizeGrid),int(rank),int(5),FReal(1.),sqrtC,int(sizeGrid),testX,int(sizeGrid),testY,int(sizeGrid));

        // Visualization filename
        std::string visufilename("../Data/Visu/Generators/"+ outfilename +".vtp");

        // Write realizations of Gaussian random field
        writeRealizations(visufilename, grid, testY);

    }

    void generate(/*const*/ FReal *const sqrtC) 
    {
        // Number of loops
        const int nbLoops = nbReal / (sizeBlock); // number of loops
        const int nbLoopsPerThread = nbLoops / nbThreads; // number of loops per thread

        //// Parallel parameters
        //const int chunkSize = FMath::Max(1 , nbLoops/(nbThreads*nbThreads/*omp_get_max_threads()*omp_get_max_threads()*/));

        // Init means
        is_int(sizeGrid);
        for (int idxThread=0; idxThread<nbThreads; ++idxThread) {
            FBlas::setzero(int(sizeGrid),meanX[idxThread]);
            FBlas::setzero(int(sizeGrid),meanY[idxThread]);
        }

        // Reduce number of points to check
        is_int(sizeCheckGrid*sizeCheckGrid);
        for (int idxThread=0; idxThread<nbThreads; ++idxThread) {
            FBlas::setzero(int(sizeCheckGrid*sizeCheckGrid),varY[idxThread]);
        }

        ////////////////////////////////////////////////////////////////////
        /// Init white noise generator
        //unsigned int seed = omp_get_thread_num();
        std::default_random_engine generator;//(seed);
        std::normal_distribution<FReal> distribution(FReal(0.0),FReal(1.0));
        distribution(generator); // init

        FTic timeMVP, timeGene;
        double meantimeMVP = double(0.0);
        timeGene.tic();
//#pragma omp parallel shared(X,Y,varY,meanX,meanY) // does not work anymore since these are members
#pragma omp parallel
        {// start parallel section
            
            int idxThread;
#pragma omp for schedule(static,1) private(idxThread)
            for ( idxThread=0; idxThread<nbThreads; ++idxThread){ // Do nbThread group of loops in parallel

                for ( int idxLoop=0; idxLoop<nbLoopsPerThread; ++idxLoop){ // each thread compute the group of loops sequentially

              
                  // generate white noise on the fly
                  for ( FSize i=0; i<sizeGrid; ++i){
                      for ( FSize r=0; r<sizeBlock; ++r){
                          X[idxThread][i+r*sizeGrid] = distribution(generator);
                          meanX[idxThread][i]+=X[idxThread][i+r*sizeGrid]; 
                      }
                  }

                  if(omp_get_thread_num()==0) {timeMVP.tic();}
                  {     
                          // Applying C^{1/2} to X
                          is_int(sizeGrid); is_int(sizeBlock);
                          FBlas::gemm(int(sizeGrid),int(rank),int(sizeBlock),FReal(1.),sqrtC,int(sizeGrid),X[idxThread],int(sizeGrid),Y[idxThread],int(sizeGrid));
                  }
                  if(omp_get_thread_num()==0) {meantimeMVP += timeMVP.tacAndElapsed();}

                  // Mean of Y
                  for ( FSize i=0; i<sizeGrid; ++i)
                      for ( FSize r=0; r<sizeBlock; ++r)
                          meanY[idxThread][i]+=Y[idxThread][i+r*sizeGrid]; 

                  // Init sample covariance 
                  is_int(sizeCheckGrid); is_int(sizeBlock);
                  FBlas::gemmta(int(sizeCheckGrid),int(sizeBlock),int(sizeCheckGrid),FReal(1.),Y[idxThread],int(sizeGrid),Y[idxThread],int(sizeGrid),varY[idxThread],int(sizeCheckGrid));

                  if(omp_get_thread_num()==0) {
                      // Progress bar 
                      FReal progress = FReal(idxLoop)/FReal(nbLoopsPerThread-1); // (return status of last thread)
                      if (progress <= 1) {
                          int barWidth = 70;

                          std::cout << "[";
                          FReal pos = barWidth * progress;
                          for (int i = 0; i < barWidth; ++i) {
                              if (i < pos) std::cout << "=";
                              else if (i == pos) std::cout << ">";
                              else std::cout << " ";
                          }
                          std::cout << "] " << int(progress * 100.0) << " % ("<< int(timeGene.tacAndElapsed()) << "/" << int(timeGene.tacAndElapsed()/progress) <<"s)     \r";
                          std::cout.flush();

                      }
                  }

                }// end nbLoopsPerThread

            } // end nbThreads

#pragma omp single 
            {
                /// Finalize means
                // sum contribution of all threads in first thread
                is_int(sizeGrid); 
                for (int idxT=1; idxT<nbThreads; ++idxT){
                    FBlas::add(int(sizeGrid),meanX[idxT],meanX[0]);
                    FBlas::add(int(sizeGrid),meanY[idxT],meanY[0]);
                }
                // scale 
                for ( FSize i=0; i<sizeGrid; ++i){
                    meanX[0][i] /= FReal(nbReal);
                    meanY[0][i] /= FReal(nbReal);
                }

                /// Finalize sample covariance
                // sum contribution of all threads in first thread
                is_int(sizeCheckGrid*sizeCheckGrid); 
                for (int idxT=1; idxT<nbThreads; ++idxT)
                    FBlas::add(int(sizeCheckGrid*sizeCheckGrid),varY[idxT],varY[0]);
                // scale and add last term
                for ( FSize i=0; i<sizeCheckGrid; ++i){
                    for ( FSize j=0; j<sizeCheckGrid; ++j){
                        varY[0][i*sizeCheckGrid+j]/=FReal(nbReal);
                        varY[0][i*sizeCheckGrid+j]+=-meanY[0][i]*meanY[0][j];
                    }
                }
            }


        } // end parallel section
        meantimeMVP/=double(nbLoopsPerThread*sizeBlock); // compute mean over nbRealPerThread (since timing only for thread 0)
        double tGRF = timeGene.tacAndElapsed();

        std::cout<<"\n mean timings: "<< meantimeMVP <<"s"<<std::endl;

        /// Display results and perfs
        std::cout << "@tReal = "<< meantimeMVP <<"\n";
        std::cout << "@tGRF = "<< tGRF <<"\n";

    }

};

#endif /* RANDOMFIELDGENERATOR_HPP */
