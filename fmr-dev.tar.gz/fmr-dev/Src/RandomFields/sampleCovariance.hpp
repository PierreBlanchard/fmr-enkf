#ifndef SAMPLECOVARIANCE_HPP
#define SAMPLECOVARIANCE_HPP

#include <stdlib.h>
#include <math.h> // for exp

// ScalFMM includes
#include "Utils/FMath.hpp"
// FMR includes


/**
 * @class sampleCovariance
 *
 * Evaluate sample covariance from set of random fields
 *
 *
 * @tparam NAME description \f$latex symbol\f$
 */

class sampleCovariance
{

private:
  const FSize sizeGrid_;
  const int nbReal_;

  FReal* sampleC;
  
  public:
  /**
   * Constructor: Initialize sizes
   */
  explicit sampleCovariance(const FSize sizeGrid, const int nbReal)
    : sizeGrid_(sizeGrid), nbReal_(nbReal)
  {
    sampleC = new FReal[sizeGrid*sizeGrid];
    is_int(sizeGrid_*sizeGrid_);
    FBlas::setzero(int(sizeGrid_*sizeGrid_),sampleC);
  }

  /**
   * Destructor: Dynamically delete memory allocated for ...
   */
  ~sampleCovariance()
  {
    delete[] sampleC;
  }


  FReal* getSampleCovariance(){
    return sampleC;
  }

  /**
   * performSampling: computes sample covariance matrix 
   * from nbReal realizations of a random field of size sizeGrid.
   */
  void performSampling(const FReal* Y)
  {
    // Mean of Y
    FReal *meanY = new FReal[sizeGrid_];
    for ( int i=0; i<sizeGrid_; ++i){
      meanY[i] = FReal(0.0);
      for ( int r=0; r<nbReal_; ++r)
        meanY[i]+=Y[r*sizeGrid_+i];
      meanY[i]/=nbReal_;
    }
    // display mean
    std::cout<<"\n meanY=[ ";
    for ( int i=0; i<sizeGrid_; ++i)
      std::cout << meanY[i] << " ";
    std::cout<<"]"<<std::endl;

    // Compute sample covariance
    for ( int i=0; i<sizeGrid_; ++i){
      for ( int j=0; j<sizeGrid_; ++j){
        for ( int r=0; r<nbReal_; ++r)
          sampleC[i*sizeGrid_+j]+=Y[r*sizeGrid_+i]*Y[r*sizeGrid_+j];
        sampleC[i*sizeGrid_+j]/=nbReal_;
        sampleC[i*sizeGrid_+j]+=-meanY[i]*meanY[j];
      }
    }
  }

  /**
   * updateSampling: update sample covariance matrix 
   * with contribution of current realization of random field of size sizeGrid. 
   * !!! When all realizations are performed call finalizeSampling 
   */
  void updateSampling(const FReal* Y)
  {
    for ( int i=0; i<sizeGrid_; ++i){
       for ( int j=0; j<sizeGrid_; ++j){
         sampleC[i*sizeGrid_+j]+=Y[i]*Y[j]; 
       }
     }
   }

   /**
    * finalizeSampling: add contribution of mean to sample covariance matrix
    */
   void finalizeSampling(const FReal* meanY)
   {
     for ( int i=0; i<sizeGrid_; ++i){
       for ( int j=0; j<sizeGrid_; ++j){
         sampleC[i*sizeGrid_+j]/=nbReal_;
         sampleC[i*sizeGrid_+j]+=-meanY[i]*meanY[j];
      }
    }
  }

  void computeError(const FReal* C)
  {
    // Compute error between analytic and sample covariance matrices
    FReal errC1 = FReal(0.0); FReal normC1 = FReal(0.0);
    FReal errC2 = FReal(0.0); FReal normC2 = FReal(0.0);
    for ( int i=0; i<sizeGrid_; ++i) {
      for ( int j=0; j<sizeGrid_; ++j){
        FReal diffC = std::abs(C[i*sizeGrid_+j]-sampleC[i*sizeGrid_+j]);
        FReal normC = std::abs(C[i*sizeGrid_+j]);
        errC1 += diffC; normC1 += normC;
        errC2 += diffC*diffC; normC2 += normC*normC;
      }
    }
    std::cout<<"\nError on covariance matrix: "<<std::endl;
    //  std::cout<<" ||C - C_sample||_1,abs = "<< errC1 <<std::endl;
    //  std::cout<<" ||C - C_sample||_2,abs = "<< FMath::Sqrt(errC2) <<std::endl;
    std::cout<<" ||C - C_sample||_1,rel = "<< errC1/normC1 <<std::endl;
    std::cout<<" ||C - C_sample||_2,rel = "<< FMath::Sqrt(errC2/normC2) <<std::endl;
    // for easier copy into output data file
    std::cout << errC1/normC1
              << " " 
              << FMath::Sqrt(errC2/normC2)
              << std::endl;
  }
  

  void performSamplingAndcomputeError(const FReal* Y, const FReal* C)
  {
    // compute sample covariance matrix
    performSampling(Y);

    // Compute error between analytic and sample covariance matrices
    computeError(C);

  }



};




#endif /* SAMPLECOVARIANCE_HPP */
