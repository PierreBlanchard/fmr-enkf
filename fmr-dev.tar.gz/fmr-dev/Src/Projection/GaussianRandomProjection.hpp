#ifndef GRP_HPP
#define GRP_HPP

// standard includes 
#include <stdio.h>
#include <stdlib.h>
#include <random> // for normal distribution generator

// For std::array<> (i.e. for MultiRhs purpose)
#include <array>

// ScalFMM includes
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FBlas.hpp" // necessary?
#include "Utils/FMath.hpp"
#include "Utils/FTic.hpp"

// FMR includes
#include "StandardLRA/QRD.hpp"

#include "Definition/ScalFMMDefines.hpp"

#include "Utils/MatrixIO.hpp" // read random matrix from file


/**
 * @author Pierre Blanchard (pierre.blanchard@inria.fr)
 * @date July 1st, 2014 
 *
 *
 */


/**
 * @brief Gaussian Random Projection class
 */
template<class FReal, class MatrixWrapperClass>
class GRP {

private:

    // needed for matrix multiplications
    MatrixWrapperClass* MatrixWrapper;
    // prescribed rank (only needed to get range size with a generic function)
    const FSize prescribedRank;
    // verify matrix multiplication?
    const bool verifyMultiplication;
    // Random Gaussian Transform
    FReal* GaussianTransform;
public:

    /*
     * Ctor
     */
      explicit GRP(MatrixWrapperClass* inMatrixWrapper, const FSize inPrescribedRank, const bool in_verifyMultiplication = false)
      : MatrixWrapper(inMatrixWrapper), prescribedRank(inPrescribedRank), verifyMultiplication(in_verifyMultiplication),
        GaussianTransform(NULL)
    {}
  
    /*
     * Dtor
     */
    ~GRP()
    {}

    /*
     * multiplyMatrix: This allows the multiplyMatrix() function from MatrixWrapper to be called from RRF. Needed by RandLowRank Algo
     */
    void multiplyMatrix(const FSize nbRows, const FSize nbCols, const FSize rank, FReal* W, FReal* &Y, const bool transposeMatrix = false){

        MatrixWrapper->multiplyMatrix(nbRows,nbCols,rank,W,Y,transposeMatrix);
        
    }

    const bool isMatrixSymmetric(){

        return MatrixWrapper->isSymmetric();
        
    }

    /*
     * computeError: This allows the computeError() function from MatrixWrapper to be called from RRF. Needed by RandLowRank Algo
     */
    void computeError(const FSize nbRows, const FSize nbCols, const FSize rank, FReal* W, FReal* Y){

        MatrixWrapper->computeError(nbRows,nbCols,rank,W,Y);
        
    }


    void initTransform(const bool readW){

        // Random matrix W: Compute or read from file?
        std::cout << "\nGenerate Gaussian Transform, i.e. white noise W... \n";
        FTic timeNoise;
        timeNoise.tic();

        if(readW)
        {
            /// Read from file

            // Input matrix filename (../Data/Matrices/Random/W_mt19937_64_size2000_rank100.bin)
            std::ostringstream sstream;
            sstream << "W_mt19937_64";
            sstream << "_size" << nbCols;
            sstream << "_rank" << oversampledRank;
            const std::string matfilename = "../Data/Matrices/Random/" + sstream.str() + ".bin";
            // display name and directory
            std::cout << matfilename;

            FSize m,n; m=n=0;            
            MatrixIO::read(m,n,GaussianTransform,matfilename);
            FAssertLF(m!=nbCols);
            FAssertLF(n!=oversampledRank);

        }
        else
        {
            /// Init random number generator (can be moved to ctor)
            //std::default_random_engine generator(/*no seed*/);
            // default random engine
            //std::default_random_engine generator(std::random_device{}());
            // Mersenne twister random engine
            std::mt19937_64 generator(std::random_device{}());

            std::normal_distribution<double> distribution(0.0,1.0);
            distribution(generator); // init

            /// Draw $r$ standards gaussian vectors w
            GaussianTransform = new FReal[nbCols*oversampledRank];
            for ( int i=0; i<nbCols; ++i) 
              for ( int j=0; j<oversampledRank; ++j) 
                GaussianTransform[i+j*nbCols] =  FReal(distribution(generator)); // set to 1 to DBG
        }

        double tNoise = timeNoise.tacAndElapsed();
        std::cout << "... took @tNoise = "<< tNoise <<"\n";

    }



    FSize project(const FSize nbRows, const FSize nbCols, FReal* &Y){

        /// Apply Gaussian Transform to C, i.e. compute Y=CW
        std::cout << "\nPerform Y=CW... \n";
        FTic timeCW;
        timeCW.tic();
        //FReal *Y = new FReal[nbRows*oversampledRank];
        multiplyMatrix(nbRows,nbCols,oversampledRank,GaussianTransform,Y);
        double tCW = timeCW.tacAndElapsed();
        std::cout << "... took @tCW = "<< tCW <<"\n";

        if(verifyMultiplication){
            std::cout << "\nError ||Y-Direct(CW)||\n";
            FTic timeErrorCW;
            timeErrorCW.tic();
            computeError(nbRows,nbCols,oversampledRank,W,Y);
            double tErrorCW = timeErrorCW.tacAndElapsed();
            std::cout << "... took @tErrorCW = "<< tErrorCW <<"\n";
        }

        // return rank
        return prescribedRank;

  }

};

#endif /* AdaptiveRRF_HPP */
