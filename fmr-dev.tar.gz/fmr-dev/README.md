# FMR

Fast and accurate Methods for Randomized numerical linear algebra. This project provides routines for performing low-rank matrix approximations (SVD, Cholesky...) based on randomized techniques. It relies heavily on the ScalFMM library, which allows for performing fast matrix-to-matrix operations. In particular, square roots of covariance matrices can be assembled and used to generate correlated Gaussian Random Fields (GRF).

## 0. Introduction :

**[TODO]**

## 1. What's inside :

* `Doc/` : **[TODO]**
* `Src/` : Core of FMR's project. Contains all algorithms, wrappers and ios routines written in c++ (only headers: `*.hpp`)
* `Data/` : 
	* `FMAInput/` : Example of particles distributions. 
	* `FMAOutput/` : Output potentials resulting from fmm or direct computations of particle interactions
	* `Sqrt/` : Square roots of covariance matrices are stored here. They can then be used to generate Gaussian Random Fields.
	* `Tests/` : Various output files related to Tests.
	* `Visu/Distributions/` : `*.vtp` files for the visualization of particle distributions and test white noise.
	* `Visu/Generators/` : `*.vtp` files for the visualization of random fields with respect to generation technique
* `Generators/` : contains examples of random field generators using various techniques for the computation of the square root of the covariance matrix.
* `Factorizers/` : contains example of matrix factorizers for applications where only the matrix decomposition matters (e.g. computation of eigen vectors/values)
* `Addons/`:
	* `MDS/`: contains examples of MultiDimensionnal Scaling (MDS) for distance matrices arising from the classification of biological species (distance between words). The distances are stored as short integers (they contain a prefactor of 10), the covariances as single floats. 
	* `MatlabAPI/`: Examples of Octave-compatible Matlab routines that call C++ executables, e.g., factRandSVD.
* `UTests/` : contains some unit tests (can be helpful to understand some features of FMR)
* `Tests/` : various numerical tests or conversions

## 2. Tutorial:

**[TODO]**

## 3. Compilation:

### 3.1 Install scalfmm package in Packages/scalfmm:
* Move to Packages directory:
```
cd Packages
```

* Get ScalFMM from tarball:
	*  using dev package
```
tar -zxvf ScalFMM-1.4-dev.tar.gz
```

	* or last release
```
tar -zxvf SCALFMM-1.4-148.tar.gz
```

* Rename directory
```
mv SCALFMM-1.4-148 scalfmm
```

* Move to newly created scalfmm directory, create then move to Build directory:
```
cd scalfmm
mkdir Build
cd Build
```

* Configure ScalFMM, i.e., set ScalFMM's compile options and define env variables:
    * (MANDATORY) Set the path for install. of ScalFMM to /path/to/fmr/Packages/scalfmm. 
    * (MANDATORY) Set Blas option to ON.
    * (MANDATORY) Set SSE option to OFF.
    * (CONVENIENT) EXAMPLES option to OFF in order to avoid time consuming compilations.
	```
	cmake ../ -DSCALFMM_USE_BLAS=ON -DSCALFMM_USE_FFT=ON -DSCALFMM_USE_SSE=OFF -DSCALFMM_BUILD_EXAMPLES=OFF -DSCALFMM_USE_ADDONS=ON -DSCALFMM_ADDON_HMAT=ON -DCMAKE_INSTALL_PREFIX=/path/to/fmr/Packages/scalfmm
	```

	* if MKL is used as BLAS library
	```
	 cmake ../ -DSCALFMM_USE_BLAS=ON -DSCALFMM_USE_MKL_AS_BLAS=ON -DSCALFMM_USE_FFT=ON -DSCALFMM_USE_MKL_AS_FFTW=ON -DSCALFMM_USE_SSE=OFF -DSCALFMM_BUILD_EXAMPLES=OFF  -DSCALFMM_USE_ADDONS=ON -DSCALFMM_ADDON_HMAT=ON -DCMAKE_INSTALL_PREFIX=/path/to/fmr/Packages/scalfmm
	```

	* another example with same options but pierre's specific install directory
	```
	 cmake ../ -DSCALFMM_USE_BLAS=ON -DSCALFMM_USE_MKL_AS_BLAS=ON -DSCALFMM_USE_FFT=ON -DSCALFMM_USE_MKL_AS_FFTW=ON -DSCALFMM_USE_SSE=OFF -DSCALFMM_BUILD_EXAMPLES=OFF  -DSCALFMM_USE_ADDONS=ON -DSCALFMM_ADDON_HMAT=ON -DCMAKE_INSTALL_PREFIX=/home/pierre/Code/fmr/Packages/scalfmm
	```

	* You can also do this using cmake GUI
	```
	ccmake ../
	```

### 3.2 Build FMR project

* Move to main fmr directory
```
cd /path/to/fmr
```

* Create a Build directory:
```
mkdir Build
```

* Go to:
```
cd fmr/Build
```

* Set compile options and define env variables:
	* using 1 command line (with or without options):
	```
	cmake ../
	```

	* using cmake GUI:
	```
	ccmake ../
	```

* Finally you can build all the required exexutables by typing:
```
make
```

* Access executables in:
	* fmr/Build/Tests/{Release,Debug}/.....
	* fmr/Build/Generators/{Release,Debug}/.....
	* fmr/Build/Factorizers/{Release,Debug}/.....

## 4. Build the doc:

**[TODO]**

## 5. Getting help/Having news from us (FMR):

You can subscribe to the fmr users mailing list ( fmr-public-users@lists.gforge.inria.fr,  http://lists.gforge.inria.fr/cgi-bin/mailman/listinfo/fmr-public-users ). 

Contact the developers at : fmr-public-support@lists.gforge.inria.fr