
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FParameterNames.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"

// FMR includes
#include "Definition/FMRDefines.hpp"
#include "Correlations/CorrelationKernels.hpp"

#include "Utils/MatrixIO.hpp" // for input/output matrix-file
#include "Utils/VectorNorms.hpp" // for leverage scores

#include "Utils/Display.hpp" // In order to display vectors and arrays

#include "StandardLRA/SVD.hpp" // for exact leverage scores

// ... for column sampling
#include "Sampling/UniformSampler.hpp"
//#include "Sampling/LandmarksSampler.hpp" // [TODO]
#include "Sampling/SubspaceSampler.hpp"
//#include "Sampling/AdaptiveSampler.hpp"

// ... for column extraction
#include "Sampling/Extractor.hpp"


/**
 * In this file we load a spatial grid and generate a covariance matrix C using a Gaussian kernel.
 * Then, we sample columns indices using various column selection algorithm.
 * Random variants are run 10 times, deterministic only once.
 *
 * Author: Pierre Blanchard (pierre.blanchard@inria.fr)
 * Date created: February 3rd, 2016
 */


int main(int argc, char* argv[])
{

    ////////////////////////////////////////////////////////////////////
    /// Help and description
    //FHelpDescribeAndExit(argc, argv,
    //                     "Generate a distance and a covariance matrix using a 3D grid (loaded from file), then compute leverage scores and store it in file."/*,
    //                     FParameterDefinitions::OctreeHeight,FParameterDefinitions::NbThreads,
    //                     FParameterDefinitions::OctreeSubHeight, FParameterDefinitions::InputFile,
    //                     FParameterDefinitions::InputBinFormat*/);

    // 

    ////////////////////////////////////////////////////////////////////
    /// Input file
    const std::string distributionName(FParameters::getStr(argc,argv,"-d",   "unitSphere2000"));
    const std::string distributionPath(FParameters::getStr(argc,argv,"-p2d", "../Data/FMAInput/"));
    std::string myfilename = distributionPath + distributionName;
    if(  FParameters::existParameter(argc, argv, FParameterDefinitions::InputBinFormat.options)){
        myfilename += ".bfma";
    }
    else {
        myfilename += ".fma";
    }
    const char* const filename       = FParameters::getStr(argc,argv,"-f", myfilename.c_str());
    // open particle file
    FFmaGenericLoader<FReal> loader(filename);
    if(!loader.isOpen()) throw std::runtime_error("Particle file couldn't be opened!");
    ////////////////////////////////////////////////////////////////////
    /// Timers
    FTic time;
    time.tic();

    ////////////////////////////////////////////////////////////////////
    /// Parameters
    // Verbose (print matrices)
    const int verbose = FParameters::getValue(argc, argv, "-v", 0);
    // dimension
    static const int dim = 3;
    // size of the grid
    const FSize N = loader.getNumberOfParticles();
    std::cout<< "Full rank: " << N <<std::endl;
//    // Method for Leverage Scores computation (0:SVD, 1: RandSVD)
//    const int fLS = FParameters::getValue(argc, argv, "-fLS", 0);

    ////////////////////////////////////////////////////////////////////
    /// Generate 3D grid
    ////////////////////////////////////////////////////////////////////
    FPoint<FReal> grid[N];

    for(FSize idxPart = 0 ; idxPart < N ; ++idxPart){
        FPoint<FReal> position;
        FReal physicalValue = 0.0;
        loader.fillParticle(&position,&physicalValue);
        grid[idxPart]=position;
    }

    ////////////////////////////////////////////////////////////////////
    /// Build covariance matrix C
    ////////////////////////////////////////////////////////////////////
    // Set length scales
    const FReal lengthScale[dim] = {FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.)),
                                    FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.)),
                                    FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.))}; 

    // correlation function
    std::cout<< "Correlation function: " ;
    typedef CK_Gauss<FReal,dim> CorrelationKernelClass; 
    const unsigned int CID = CorrelationKernelClass::CID;
    CorrelationKernelClass CorrelationKernel(lengthScale);

    // Declare pointer to C
    std::cout<< "Assemble covariance matrix C: " ;
    FReal *C = new FReal[N*N];

    FTic timeAssC;
    for(FSize idxRow = 0 ; idxRow < N  ; ++idxRow)
        for(FSize idxCol = 0 ; idxCol < N  ; ++idxCol)
            C[idxRow*N+idxCol] = CorrelationKernel.evaluate(grid[idxRow],
                                                            grid[idxCol]);
    double tAssC = timeAssC.tacAndElapsed();
    std::cout << "... took @tAssC = "<< tAssC <<"\n";

    // display C
    const FSize displaySize = 10;
    if(verbose){
        Display::matrix(N,N,C,"C",displaySize);
    }


    ////////////////////////////////////////////////////////////////////
    /// Parameters of LRA
    ////////////////////////////////////////////////////////////////////

    // sample with replacement? (0: without replacement; 1: with replacement)
    const bool withReplacement = FParameters::getValue(argc, argv, "-wR", true);
    // prescribed rank
    const FSize prescribedRank = FParameters::getValue(argc, argv, "-pr", N/10);
    // number of sampled columns over rank: a such that c = a * rank (1<a<10)
    const int nbSamplesOverRank = FParameters::getValue(argc, argv, "-a", 1);
    //// Build C?
    //const bool buildC = FParameters::getValue(argc, argv, "-buildC", true);

    // number of sampled column indices
    const FSize nbSampledColumnIndices = nbSamplesOverRank * prescribedRank;
    std::cout<< "Nb of sampled column indices: " << nbSampledColumnIndices <<std::endl;

    ////////////////////////////////////////////////////////////////////
    /// Uniform Sampler
    ////////////////////////////////////////////////////////////////////
    {
        typedef UniformSampler<FReal,FSize> SamplerClass;
        SamplerClass* uniformSampler = new SamplerClass(N,N,prescribedRank,nbSampledColumnIndices,withReplacement);
        uniformSampler->updateProbabilities();
        uniformSampler->sampleIndices();
        // extract columns from input matrix C
        FReal* sampledCols = NULL;
        Extractor::extractCols(N,N,C,nbSampledColumnIndices,uniformSampler->getSampledIndices(),sampledCols);
        // [TODO] Verify
        if(verbose){
            Display::matrix(N,nbSampledColumnIndices,sampledCols,"sampledCols",displaySize);
        }
        // Write sampled indices
        uniformSampler->writeIndices("plopUnif");
        // free memory
        delete[] sampledCols;
    }

    ////////////////////////////////////////////////////////////////////
    /// Subspace Sampler
    ////////////////////////////////////////////////////////////////////
    {
        typedef SubspaceSampler<FReal,FSize> SamplerClass;
        SamplerClass* subspaceSampler = new SamplerClass(N,N,prescribedRank,nbSampledColumnIndices,withReplacement);
        subspaceSampler->updateProbabilities(C); // probabilities computed from C
        subspaceSampler->sampleIndices();
        // extract columns from input matrix C
        FReal* sampledCols = NULL;
        Extractor::extractCols(N,N,C,nbSampledColumnIndices,subspaceSampler->getSampledIndices(),sampledCols);
        // [TODO] Verify
        if(verbose){
            Display::matrix(N,nbSampledColumnIndices,sampledCols,"sampledCols",displaySize);
        }
        // Write sampled indices
        subspaceSampler->writeIndices("plopSubspace");
        // free memory
        delete[] sampledCols;
    }


    ////////////////////////////////////////////////////////////////////
    /// Free memory
    delete[] C;





    return 0;
}
