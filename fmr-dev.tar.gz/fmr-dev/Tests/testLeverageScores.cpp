
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FParameterNames.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"

// FMR includes
#include "Definition/FMRDefines.hpp"
#include "Correlations/CorrelationKernels.hpp"

#include "Utils/MatrixIO.hpp" // for input/output matrix-file
#include "Utils/VectorNorms.hpp" // for leverage scores

#include "Utils/Display.hpp" // In order to display vectors and arrays

#include "StandardLRA/SVD.hpp" // for exact leverage scores
// ... for approximate leverage scores
#include "Sampling/LeverageScores.hpp"
/**
 * In this file we load a spatial grid and generate a covariance matrix C using a Gaussian kernel.
 * Then, we compute the leverage scores, i.e. the squared 2 norm of the rows of V. If 
 * If SVD is used then leverage scores are exact, otherwise (RandSVD or fazstRandSVD) they are approximated.
 * 
 * Author: Pierre Blanchard (pierre.blanchard@inria.fr)
 * Date created: February 3rd, 2016
 */


int main(int argc, char* argv[])
{

    ////////////////////////////////////////////////////////////////////
    /// Help and description
    //FHelpDescribeAndExit(argc, argv,
    //                     "Generate a distance and a covariance matrix using a 3D grid (loaded from file), then compute leverage scores and store it in file."/*,
    //                     FParameterDefinitions::OctreeHeight,FParameterDefinitions::NbThreads,
    //                     FParameterDefinitions::OctreeSubHeight, FParameterDefinitions::InputFile,
    //                     FParameterDefinitions::InputBinFormat*/);



    ////////////////////////////////////////////////////////////////////
    /// Input file
    const std::string distributionName(FParameters::getStr(argc,argv,"-d",   "unitSphere2000"));
    const std::string distributionPath(FParameters::getStr(argc,argv,"-p2d", "../Data/FMAInput/"));
    std::string myfilename = distributionPath + distributionName;
    if(  FParameters::existParameter(argc, argv, FParameterDefinitions::InputBinFormat.options)){
        myfilename += ".bfma";
    }
    else {
        myfilename += ".fma";
    }
    const char* const filename       = FParameters::getStr(argc,argv,"-f", myfilename.c_str());
    // open particle file
    FFmaGenericLoader<FReal> loader(filename);
    if(!loader.isOpen()) throw std::runtime_error("Particle file couldn't be opened!");
    ////////////////////////////////////////////////////////////////////
    /// Timers
    FTic time;
    time.tic();

    ////////////////////////////////////////////////////////////////////
    /// Parameters
    // Verbose (print matrices)
    const int verbose = FParameters::getValue(argc, argv, "-v", 0);
    // dimension
    static const int dim = 3;
    // size of the grid
    const FSize N = loader.getNumberOfParticles();
    std::cout<< "Full rank: " << N <<std::endl;
    // Method for Leverage Scores computation (0:SVD, 1: RandSVD)
    const int fLS = FParameters::getValue(argc, argv, "-fLS", 0);

    ////////////////////////////////////////////////////////////////////
    /// Generate 3D grid
    ////////////////////////////////////////////////////////////////////
    FPoint<FReal> grid[N];

    for(FSize idxPart = 0 ; idxPart < N ; ++idxPart){
        FPoint<FReal> position;
        FReal physicalValue = 0.0;
        loader.fillParticle(&position,&physicalValue);
        grid[idxPart]=position;
    }

    ////////////////////////////////////////////////////////////////////
    /// Build covariance matrix C
    ////////////////////////////////////////////////////////////////////
    // Set length scales
    const FReal lengthScale[dim] = {FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.)),
                                    FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.)),
                                    FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.))}; 

    // correlation function
    std::cout<< "Correlation function: " ;
    typedef CK_Gauss<FReal,dim> CorrelationKernelClass; 
    const unsigned int CID = CorrelationKernelClass::CID;
    CorrelationKernelClass CorrelationKernel(lengthScale);

    // Declare pointer to C
    std::cout<< "Assemble covariance matrix C: " ;
    FReal *C = new FReal[N*N];

    FTic timeAssC;
    for(FSize idxRow = 0 ; idxRow < N  ; ++idxRow)
        for(FSize idxCol = 0 ; idxCol < N  ; ++idxCol)
            C[idxRow*N+idxCol] = CorrelationKernel.evaluate(grid[idxRow],
                                                            grid[idxCol]);
    double tAssC = timeAssC.tacAndElapsed();
    std::cout << "... took @tAssC = "<< tAssC <<"\n";

    // display C
    const FSize displaySize = 10;
    if(verbose){
        Display::matrix(N,N,C,"C",displaySize);
    }


    ////////////////////////////////////////////////////////////////////
    /// Compute leverage scores using either fullSVD or randSVD

    // Allocate memory
    FReal* U = NULL;

    // Compute leverage scores
    FSize maxRank = N/10; // N/10
    std::cout << "\nCompute left singular vectors U... ";
    FTic timeLS;
    double tLS;
    timeLS.tic();

    LeverageScores::computeU(N,maxRank,C,U,fLS);

    tLS = timeLS.tacAndElapsed();
    std::cout << "... took @tLS = "<< tLS <<"\n";

    // Leverage scores of for lower ranks
    FTic timeNormU;
    double tNormU;
    std::cout << "\nCompute norm if the rows of U ... ";
    timeNormU.tic();
    // Compute norms of each line of U^T
    FReal* leverageScores = new FReal[10*N];
    FReal* coherence = new FReal[10*4];
    VectorNorms<FReal>* rowsNorm = new VectorNorms<FReal>[N];
    std::cout << "\nFor rank=";
    for (int r = 0; r < 10; ++r){
        // rank
        is_int(maxRank);
        int rank = (r+1)*int(maxRank)/10;
        // 
        std::cout << rank << ", ";
        // init coherence
        FReal minLS=FReal(1.);
        FReal maxLS=FReal(0.);
        FReal avgLS=FReal(0.);
        FReal devLS=FReal(0.);
        for (int i = 0; i < N; ++i){ // For each row U_i of U
        // reset vector norm
        rowsNorm[i].reset();
            // Compute the norm of U_i
            for (FSize j = 0; j < rank; ++j) 
            {
                rowsNorm[i].add(U[i+j*N]);
            }
            leverageScores[i+r*N]=rowsNorm[i].getTwo();
            // Coherence: min, max, mean and std dev of leverage score
            minLS=FMath::Min(minLS,leverageScores[i+r*N]);
            maxLS=FMath::Max(maxLS,leverageScores[i+r*N]);
            avgLS+=leverageScores[i+r*N];
            devLS+=leverageScores[i+r*N]*leverageScores[i+r*N];

        }
        avgLS/=FReal(N);
        devLS=FMath::Sqrt(devLS/FReal(N)-avgLS*avgLS);
        // coherence
        coherence[r+0*10]=minLS;
        coherence[r+1*10]=maxLS;
        coherence[r+2*10]=avgLS;
        coherence[r+3*10]=devLS;
    }
    tNormU = timeNormU.tacAndElapsed();
    std::cout << "\n... took @tNormU = "<< tNormU <<"\n";


    if(verbose){
        Display::vector(N,leverageScores+0*N,"lev",displaySize,1);
        Display::vector(N,leverageScores+1*N,"lev",displaySize,1);
        Display::vector(N,coherence,"coh",displaySize,0);

    }

    ////////////////////////////////////////////////////////////////////
    /// Write kernel matrix in binary file

    std::ostringstream oss;
    oss << 100*lengthScale[0];
    std::string MatrixKernelID;
    if(CID==0) // EXPO
        MatrixKernelID = "E" + oss.str();
    else if(CID==1) // GAUSS
        MatrixKernelID = "G" + oss.str();

    std::ostringstream oss_maxRank;
    oss_maxRank << maxRank;
    // Output file name
    const std::string matrixName((distributionName + "_" + MatrixKernelID).c_str());

    std::string mthd_name;
    if(fLS==0) mthd_name="-fsvd";
    else if(fLS==1) mthd_name="-rsvd";
    else throw std::runtime_error("Invalid flag for LS computation method!");

    const std::string levFileName = "../Data/Scores/" + matrixName + "-rmax" + oss_maxRank.str() + mthd_name + "-lev.txt";
    const std::string cohFileName = "../Data/Scores/" + matrixName + "-rmax" + oss_maxRank.str() + mthd_name + "-coh.txt";

    // Write 
    std::cout<< "Write leverages and coherence in txt files: " << levFileName << " and "<<cohFileName<<"\n";
    FTic timeWriteMat;
    double tWriteMat;
    timeWriteMat.tic();

    MatrixIO::writeCSV_lev(N,10,leverageScores,levFileName);
    MatrixIO::writeCSV_coh(10,maxRank,coherence,cohFileName);

    tWriteMat = timeWriteMat.tacAndElapsed();
    std::cout << "... took @tWriteMat = "<< tWriteMat <<"\n";




    ////////////////////////////////////////////////////////////////////
    /// Free memory
    delete[] C;
    delete[] U;
    delete[] rowsNorm;
    delete[] leverageScores;





    return 0;
}
