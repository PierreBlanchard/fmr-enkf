
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameterNames.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"

// FMR includes
#include "Definition/FMRDefines.hpp"
#include "Correlations/CorrelationKernels.hpp"

#include "Utils/MatrixIO.hpp"



/**
 * In this file we load a spatial grid and generate a covariance matrix C.
 * The matrix is then stored in a file to be used for h-matrix representation (in ScalFMM). 
 * 
 * Author: Pierre Blanchard (pierre.blanchard@inria.fr)
 * Date created: June 8th, 2015
 */


int main(int argc, char* argv[])
{

    //////////////////////////////////////////////////////////////////////
    ///// Help and description
    //FHelpDescribeAndExit(argc, argv,
    //                     "Generate a distance and a covariance matrix using a 3D grid (loaded from file), then store it in file."/*,
    //                     FParameterDefinitions::OctreeHeight,FParameterDefinitions::NbThreads,
    //                     FParameterDefinitions::OctreeSubHeight, FParameterDefinitions::InputFile,
    //                     FParameterDefinitions::InputBinFormat*/);

    ////////////////////////////////////////////////////////////////////
    /// Input file
    const std::string distributionName(FParameters::getStr(argc,argv,"-d",   "unitSphere2000"));
    std::string myfilename = "../Data/FMAInput/" + distributionName;
    if(  FParameters::existParameter(argc, argv, FParameterDefinitions::InputBinFormat.options)){
        myfilename += ".bfma";
    }
    else {
        myfilename += ".fma";
    }
    const char* const filename       = FParameters::getStr(argc,argv,"-f", myfilename.c_str());
    // open particle file
    FFmaGenericLoader<FReal> loader(filename);
    if(!loader.isOpen()) throw std::runtime_error("Particle file couldn't be opened!");

    ////////////////////////////////////////////////////////////////////
    /// Timers
    FTic time;
    time.tic();

    ////////////////////////////////////////////////////////////////////
    /// Parameters
    // Verbose (print matrices)
    const int verbose = FParameters::getValue(argc, argv, "-v", 0);
    // dimension
    static const int dim = 3;
    // size of the grid
    const FSize N = loader.getNumberOfParticles();
    std::cout<< "Size of the grid: " << N <<std::endl;
    // Matrix size
    const FSize nbRows = FParameters::getValue(argc, argv, "-R", N);
    const FSize nbCols = FParameters::getValue(argc, argv, "-C", N);


    ////////////////////////////////////////////////////////////////////
    /// Generate 3D grid
    ////////////////////////////////////////////////////////////////////
    FPoint<FReal> grid[N];

    for(FSize idxPart = 0 ; idxPart < N ; ++idxPart){
        FPoint<FReal> position;
        FReal physicalValue = 0.0;
        loader.fillParticle(&position,&physicalValue);
        grid[idxPart]=position;
    }

    ////////////////////////////////////////////////////////////////////
    /// Build covariance matrix C
    ////////////////////////////////////////////////////////////////////
    // Set length scales
    const FReal lengthScale[dim] = {FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.)),
                                    FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.)),
                                    FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.))}; 

    // correlation function
    std::cout<< "Correlation function: " ;
    typedef CK_Gauss<FReal,dim> CorrelationKernelClass; 
    const unsigned int CID = CorrelationKernelClass::CID;
    CorrelationKernelClass CorrelationKernel(lengthScale);

    // Declare pointer to C
    std::cout<< "Assemble covariance matrix C: " ;
    FReal *C = new FReal[nbRows*nbCols];

    FTic timeAssC;
    for(FSize idxRow = 0 ; idxRow < nbRows  ; ++idxRow)
        for(FSize idxCol = 0 ; idxCol < nbCols  ; ++idxCol)
            C[idxRow+idxCol*nbRows] = CorrelationKernel.evaluate(grid[idxRow], grid[idxCol]);
    double tAssC = timeAssC.tacAndElapsed();
    std::cout << "... took @tAssC = "<< tAssC <<"\n";

    // display C
    if(verbose){
        std::cout<<"\nC=["<<std::endl;
        for ( FSize i=0; i<10; ++i) {
            for ( FSize j=0; j<10; ++j)
                std::cout << C[i+j*nbRows] << " ";
            std::cout<< std::endl;
        }
        std::cout<<"]"<<std::endl;
    }


    ////////////////////////////////////////////////////////////////////
    /// Write kernel matrix in binary file

    std::ostringstream oss;
    oss << 100*lengthScale[0];
    std::string MatrixKernelID;
    if(CID==0) // EXPO
        MatrixKernelID = "E" + oss.str();
    else if(CID==1) // GAUSS
        MatrixKernelID = "G" + oss.str();

    if(nbRows!=nbCols) MatrixKernelID = MatrixKernelID + "_rect";

    // Output file name
    const std::string matrixName((distributionName + "_" + MatrixKernelID).c_str());
    const std::string outputFileName = FParameters::getStr(argc,argv,"-of", std::string("../Data/Matrices/Covariance/" + matrixName + ".bin").c_str());

    // Write 
    std::cout<< "Write matrix in binary file: " << outputFileName << "\n";
    FTic timeWriteMat;
    double tWriteMat;
    timeWriteMat.tic();

    MatrixIO::write(nbRows,nbCols,C,outputFileName);

    tWriteMat = timeWriteMat.tacAndElapsed();
    std::cout << "... took @tWriteMat = "<< tWriteMat <<"\n";




    ////////////////////////////////////////////////////////////////////
    /// Free memory
    delete[] C;





    return 0;
}
