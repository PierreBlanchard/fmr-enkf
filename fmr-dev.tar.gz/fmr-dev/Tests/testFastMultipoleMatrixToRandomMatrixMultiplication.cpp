
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FMemUtils.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"
#include "Utils/FParameterNames.hpp"

// not mandatory but useful to define some flags
#include "Core/FFmmAlgorithm.hpp"
#include "Core/FFmmAlgorithmThread.hpp"

// ... for FMM
#include "Kernels/Interpolation/FInterpMatrixKernel.hpp" // Otherwise KERNEL_FUNCTION_TYPE not declared in M2L handler

// FMR includes
#include "Definition/FMRDefines.hpp"
#include "Correlations/CorrelationKernels.hpp"
#include "StandardLRA/SVD.hpp"
#include "StandardLRA/QRD.hpp"
#include "RandomizedLRA/AdaptiveRandomizedRangeFinder.hpp"
#include "RandomizedLRA/RandomizedRangeFinder.hpp"
#include "RandomizedLRA/RandSVD.hpp"
#include "Utils/MatrixNorms.hpp"
#include "Utils/ErrorEstimators.hpp"
#include "Utils/MatrixIO.hpp" // In order to read covariance matrix from file

// ... for FMM
#include "Definition/ScalFMMDefines.hpp"
#include "FMM/UniformKernel.hpp"
#include "FMM/FMMWrapper.hpp"
#include "MatrixWrappers/DenseWrapper.hpp"

/**
* In this file load a grid from a file. Then we compute a matrix to matrix product using the FMM.
* C can be explicitely build (not mandatory).
*
* ./Tests/Release/testFastMultipoleMatrixToRandomMatrixMultiplication -binin
* 
* Author: Pierre Blanchard (pierre.blanchard@inria.fr)
* Date created: April 9th, 2015 
*/


int main(int argc, char* argv[])
{
	std::cout << "Fast Multipole Matrix to Random Matrix multiplication and error computation." << std::endl;

    ////////////////////////////////////////////////////////////////////
    /// Input file

    // Still read geometry (for now)
    const std::string distributionName(FParameters::getStr(argc,argv,"-d",   "unitSphere2000"));
    const std::string distributionPath(FParameters::getStr(argc,argv,"-p2d", "../Data/FMAInput/"));
    std::string myfilename = distributionPath + distributionName;
    if(  FParameters::existParameter(argc, argv, FParameterDefinitions::InputBinFormat.options)){
        myfilename += ".bfma";
    }
    else {
        myfilename += ".fma";
    }

    const char* const filename       = FParameters::getStr(argc,argv,"-f", myfilename.c_str());
    // open particle file
    FFmaGenericLoader<FReal> loader(filename);
    if(!loader.isOpen()) throw std::runtime_error("Particle file couldn't be opened!");

    ////////////////////////////////////////////////////////////////////
    /// Timers
    FTic time;
    time.tic();

    ////////////////////////////////////////////////////////////////////
    /// Parameters

    // Verbose (print matrices)
    const int verbose = FParameters::getValue(argc, argv, "-v", 0);
    const FSize displaySize = 10;
    std::cout<< "Verbose level: " << verbose <<std::endl;
    // dimension
    static const int dim = 3;
    // size of the grid
    const FSize sizeGrid = loader.getNumberOfParticles();
    std::cout<< "Full rank: " << sizeGrid <<std::endl;
    // number of column in random matrix
    const FSize rank = 100;
    // Build C?
    const bool buildC = FParameters::getValue(argc, argv, "-fbuildC", true);

    ////////////////////////////////////////////////
    /// Generate 3D grid
    FPoint<FReal>* grid = new FPoint<FReal>[sizeGrid];
    FReal* pV = new FReal[sizeGrid];

    for(FSize idxPart = 0 ; idxPart < sizeGrid ; ++idxPart){
        FPoint<FReal> position;
        FReal physicalValue = 0.0;
        loader.fillParticle(&position,&physicalValue);
        grid[idxPart]=position;
        pV[idxPart]=physicalValue;
    }

    ////////////////////////////////////////////////////////////////////
    /// Build covariance matrix C
  
    // Set length scales
    const FReal lengthScale[dim] = {FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.)),
                                    FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.)),
                                    FReal(0.01)*FParameters::getValue(argc, argv, "-ls", FReal(50.))}; 

    // correlation function
    std::cout<< "Correlation function: " ;
    typedef CK_Gauss<FReal,dim> CorrelationKernelClass; 
    const unsigned int CID = CorrelationKernelClass::CID;
    CorrelationKernelClass CorrelationKernel(lengthScale);

    // Declare pointer to C
    FReal *C;

    // Build C?
    if(!buildC){C = NULL;}
    else{

        std::cout<< "Assemble covariance matrix C: " ;
  
        C = new FReal[sizeGrid*sizeGrid];
  
        FTic timeAssC;
        for(FSize idxRow = 0 ; idxRow < sizeGrid  ; ++idxRow)
            for(FSize idxCol = 0 ; idxCol < sizeGrid  ; ++idxCol)
                C[idxRow+idxCol*sizeGrid] = CorrelationKernel.evaluate(grid[idxRow],
                                                                       grid[idxCol]);
        double tAssC = timeAssC.tacAndElapsed();
        std::cout << "... took @tAssC = "<< tAssC <<"\n";
    
        // display C
        if(verbose){
            std::cout<<"\nC=["<<std::endl;
            for ( FSize i=0; i<displaySize; ++i) {
                for ( FSize j=0; j<displaySize; ++j)
                    std::cout << C[i+j*sizeGrid] << " ";
                std::cout<< std::endl;
            }
            std::cout<<"]"<<std::endl;
        }

    }// end build C

    ////////////////////////////////////////////////////////////////////
    /// Init FMM components for fast application of C

    // Approximate nearfield? Kernel needs to be smooth (in particular at origin), e.g. Gaussian.
    const bool approximateNearfield = FParameters::getValue(argc, argv, "-appNF", false);
    // tree height
    const int TreeHeight    = FParameters::getValue(argc,argv,"-h", 3);
    const int SubTreeHeight = FParameters::getValue(argc,argv,"-sh", 2);
    // init oct-tree
    OctreeClass tree(TreeHeight, SubTreeHeight, loader.getBoxWidth(), loader.getCenterOfBox());
    // UnifFMM with precomputed P2P
    typedef UniformKernel< FReal, CellClass, ContainerClass, CorrelationKernelClass, ORDER, NVALS > FMMKernelClass;
    // ScalFMM algorithm    
    typedef FFmmAlgorithm<OctreeClass,CellClass,ContainerClass,FMMKernelClass,LeafClass> FMMAlgoClass;

    ////////////////////////////////////////////////////////////////////
    /// Init FMR components for factorization of C

    // FMM Matrix Wrapper
    typedef FMMWrapper<FReal,OctreeClass,CorrelationKernelClass,FMMKernelClass,FMMAlgoClass> FMMWrapperClass;
    // Dense Matrix Wrapper
    typedef DenseWrapper<FReal> DenseWrapperClass;

    // Output matrix
    FReal* Ydense = new FReal[rank*sizeGrid];
    FReal* Yfmm   = new FReal[rank*sizeGrid];

    ////////////////////////////////////////////////////////////////////
    /// Compute Fast Multipole Matrix to Random Matrix Multiplication
    double tInput,tFMM,tDM,tInitFMM,tInitDM;
    FTic timeInput, timeFmm, timeDM, timeInitFmm, timeInitDM;
    {

        std::cout << "\nInit Input Random Matrix ... \n";
        timeInput.tic();

        FReal* X = new FReal[rank*sizeGrid];
        for(FSize idxCol = 0 ; idxCol < rank  ; ++idxCol)
            FBlas::copy(int(sizeGrid),pV,X+idxCol*sizeGrid);

        tInput = timeInput.tacAndElapsed();
        std::cout << "... took @tInput = "<< tInput <<"\n";

        if(buildC)
        {        
            //
            // Init Dense algorithm
            
            std::cout << "\nInit Dense Algorithm ... \n";
            timeInitDM.tic();
            // Dense Wrapper
            DenseWrapperClass* DenseMatrixWrapper = new DenseWrapperClass(sizeGrid,sizeGrid,true);
            DenseMatrixWrapper->init(C);
            //
            tInitDM = timeInitDM.tacAndElapsed();
            std::cout << "... took @tInitDM = "<< tInitDM <<"\n";
            //
            std::cout << "\nPerform Dense Matrix Multiplication ... ";
            timeDM.tic();
            // Dense Matrix Multiplication
            DenseMatrixWrapper->multiplyMatrix(sizeGrid,sizeGrid,rank,C,X,Ydense);

            tDM = timeDM.tacAndElapsed();
            std::cout << "... took @tDM = "<< tDM <<"\n";
        }


        std::cout << "\nInit FMM ... \n";
        timeInitFmm.tic();

        // FMM Wrapper
        FMMWrapperClass* FMMMatrixWrapper = new FMMWrapperClass(&tree,&CorrelationKernel,grid,sizeGrid,approximateNearfield);
        FMMMatrixWrapper->init();

        //
        tInitFMM = timeInitFmm.tacAndElapsed();
        std::cout << "... took @tInitFMM = "<< tInitFMM <<"\n";
        //
        std::cout << "\nPerform Fast Multipole Matrix Multiplication ... ";
        timeFmm.tic();
        // Fast Multipole Matrix Multiplication
        FMMMatrixWrapper->multiplyMatrix(sizeGrid,sizeGrid,rank,C,X,Yfmm);
        // Error on 1 MVP
        FMMMatrixWrapper->computeError(sizeGrid,sizeGrid,rank,X,Yfmm);

        tFMM = timeFmm.tacAndElapsed();
        std::cout << "... took @tFMM = "<< tFMM <<"\n";
    }


    ////////////////////////////////////////////////////////////////////
    /// Verify that Yfmm ~ Ydense
    std::cout << "\nVerify Accuracy || Y_fmm - Y_dense ||_rel ... \n";
    FTic timeApprox;
    timeApprox.tic();

    // Compute error on full MMP
    FMath::FAccurater<FReal> errorFMM;
    for ( int r=0; r<rank; ++r) 
      for ( FSize j=0; j<sizeGrid; ++j)
        errorFMM.add(Ydense[r*sizeGrid+j],Yfmm[r*sizeGrid+j]);

    std::cout << "@errorFMM_L2 = "<< errorFMM.getRelativeL2Norm() <<"\n";
    std::cout << "@errorFMM_Inf = "<< errorFMM.getRelativeInfNorm() <<"\n";

    double tApprox = timeApprox.tacAndElapsed();
    std::cout << "... took @tApprox = " << tApprox <<"\n";

    /// Display results and perfs
    std::cout << "\nA few parameters and performances: \n";
    std::cout << "@size = "<< sizeGrid <<"\n";
    std::cout << "@rank = "<< rank <<"\n";
    std::cout << "@tInitDM = "<< tInitDM <<"\n";
    std::cout << "@tDM = "<< tDM <<"\n";
    std::cout << "@tInitFMM = "<< tInitFMM <<"\n";
    std::cout << "@tFMM = "<< tFMM <<"\n";
    std::cout << "@tApprox = "<< tApprox <<"\n";


    /// Free memory
      //delete[] sqrtC;

  return 0;
}
