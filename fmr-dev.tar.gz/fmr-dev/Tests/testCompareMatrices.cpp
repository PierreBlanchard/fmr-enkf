
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameterNames.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"

// FMR includes
#include "Definition/FMRDefines.hpp"

#include "Utils/MatrixIO.hpp"



/**
 * In this file we read 2 matrices from file and then compare them in Frobenius norm error. 
 * 
 * Author: Pierre Blanchard (pierre.blanchard@inria.fr)
 * Date created: June 8th, 2015
 */


int main(int argc, char* argv[])
{

    ////////////////////////////////////////////////////////////////////
    /// Help and description
    //FHelpDescribeAndExit(argc, argv,
    //                     "Read 2 matrices from file and compare them.");
    std::cout << "Read 2 matrices from file and compare them." << std::endl;

    ////////////////////////////////////////////////////////////////////
    /// Parameters

    // Number of rows
    const FSize size = FParameters::getValue(argc, argv, "-N", 2000);
    // Number of columns
    FSize rank = FParameters::getValue(argc, argv, "-rank", 100);

    // FMM parameters
    int depth = FParameters::getValue(argc, argv, "-h", 3);
    int order = FParameters::getValue(argc, argv, "-o", 5);

    // distribution
    const std::string distributionName(FParameters::getStr(argc,argv,"-d",   "unitSphere"));

    // input matrix filename (default: compare ufmm RSVD with direct RSVD)
    std::ostringstream sstreamA, sstreamB;
    sstreamA << distributionName << size << "_G50_q0_pr" << rank << "os5.bin";
    sstreamB << distributionName << size << "_UFMMh" << depth << "o" << order 
                                         << "_G50_q0_pr" << rank << "os5.bin";

    const std::string Amatfilename = "../Data/Sqrt/geneRandSVD/" + sstreamA.str() ;
    const std::string Bmatfilename = "../Data/Sqrt/geneFastRandSVD/" + sstreamB.str() ;

    // TODO extension to fixed precision problem might need a similar input random matrix

    ////////////////////////////////////////////////////////////////////
    /// Read A and B from file
    FTic timeStore;
    timeStore.tic();
    //
    // Read A
    std::cout << "\nRead A from file... ";
    std::cout << "\n" << Amatfilename;
    FReal *A = nullptr;
    {
        FSize nbRows, nbCols; nbRows=nbCols=0;
        MatrixIO::read(nbRows,nbCols,A,Amatfilename);
        FAssertLF(nbRows==size);
        FAssertLF(nbCols==rank);
    }
    // Read B
    std::cout << "\nRead B from file... ";
    std::cout << "\n" << Bmatfilename;
    FReal *B = nullptr;
    {
        FSize nbRows, nbCols; nbRows=nbCols=0;
        MatrixIO::read(nbRows,nbCols,B,Bmatfilename);
        FAssertLF(nbRows==size);
        FAssertLF(nbCols==rank);
    }
    //
    double tStore = timeStore.tacAndElapsed();
    std::cout << "... took @tStore = "<< tStore <<"\n";

    ////////////////////////////////////////////////////////////////////
    /// Display A and B

    std::cout<<"\nA=["<<std::endl;
    for ( FSize i=0; i<10/*size*/; ++i) {
        for ( FSize j=0; j<10/*rank*/; ++j)
            std::cout << A[i+j*size] << " ";
        std::cout<< std::endl;
    }
    std::cout<<"]"<<std::endl;


    std::cout<<"\nB=["<<std::endl;
    for ( FSize i=0; i<10/*size*/; ++i) {
        for ( FSize j=0; j<10/*rank*/; ++j)
            std::cout << B[i+j*size] << " ";
        std::cout<< std::endl;
    }
    std::cout<<"]"<<std::endl;

    std::cout<<"\nB-A=["<<std::endl;
    for ( FSize i=0; i<10/*size*/; ++i) {
        for ( FSize j=0; j<10/*rank*/; ++j)
            std::cout << (B[i+j*size]-A[i+j*size])/A[i+j*size] << " ";
        std::cout<< std::endl;
    }
    std::cout<<"]"<<std::endl;


    ////////////////////////////////////////////////////////////////////
    /// Compare A and B
    FMath::FAccurater<FReal> errorAB;
    for ( FSize i=0; i<size; ++i) 
        for ( FSize j=0; j<rank; ++j)
            errorAB.add(A[i+j*size],B[i+j*size]);

    std::cout << "\n@errorAB_L2  = "<< errorAB.getRelativeL2Norm() <<"\n";
    std::cout << "@errorAB_Inf = "<< errorAB.getRelativeInfNorm() <<"\n";
    
    ////////////////////////////////////////////////////////////////////
    /// Free memory
    delete[] A;
    delete[] B;


    return 0;
}
