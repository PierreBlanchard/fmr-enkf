
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameterNames.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"

// FMR includes
#include "Definition/FMRDefines.hpp"

#include "Utils/MatrixIO.hpp"



/**
 * In this file we generate a random matrix using a suitable random engine and a normal distribution.
 * The matrix is then stored in a file to be used for generating comparable randomized low rank representations. 
 * 
 * Author: Pierre Blanchard (pierre.blanchard@inria.fr)
 * Date created: June 8th, 2015
 */


int main(int argc, char* argv[])
{

    ////////////////////////////////////////////////////////////////////
    /// Help and description
//    FHelpDescribeAndExit(argc, argv,
//                         "Generate a random matrix and store it in a file.",
//                         FParameterDefinitions::OctreeHeight,FParameterDefinitions::NbThreads,
//                         FParameterDefinitions::OctreeSubHeight, FParameterDefinitions::InputFile,
//                         FParameterDefinitions::InputBinFormat);
    std::cout << "Generate a random matrix and store it in a file." << std::endl;

    ////////////////////////////////////////////////////////////////////
    /// Parameters

    // Number of rows
    const int size = FParameters::getValue(argc, argv, "-N", 0);
    // Number of columns
    const int rank = FParameters::getValue(argc, argv, "-rank", 0);

    ////////////////////////////////////////////////////////////////////
    /// Init random number generator
    // default random engine (no seed)
    //std::default_random_engine generator(/*no seed*/);
    // default random engine (random seed)
    //std::default_random_engine generator(std::random_device{}());
    // Mersenne twister random engine
    std::mt19937_64 generator(std::random_device{}());

    ////////////////////////////////////////////////////////////////////
    // Init distribution (white noise)
    std::normal_distribution<double> distribution(0.0,1.0);
    distribution(generator); // init

    ////////////////////////////////////////////////////////////////////
    /// Draw $r$ standards gaussian vectors w
    std::cout << "\nGenerate white noise W... \n";
    FTic timeNoise;
    timeNoise.tic();
    FReal *W = new FReal[rank*size];
    for ( int i=0; i<rank; ++i) 
        for ( int j=0; j<size; ++j) 
            W[i*size+j] = FReal(distribution(generator));
    double tNoise = timeNoise.tacAndElapsed();
    std::cout << "... took @tNoise = "<< tNoise <<"\n";

    ////////////////////////////////////////////////////////////////////
    /// Store in file
    FTic timeStore;
    timeStore.tic();
    //
    std::cout << "\nStore W in file... ";
    // Output filename (../Data/Matrices/Random/W_mt19937_64_size2000_rank100.bin)
    std::ostringstream sstream;
    sstream << "W_mt19937_64";
    sstream << "_size" << size;
    sstream << "_rank" << rank;
    const std::string outfilename = sstream.str();
    const std::string matfilename = "../Data/Matrices/Random/" + outfilename + ".bin";
    // display name and directory
    std::cout << matfilename;
    // Write sqrtC in file
    MatrixIO::write(size,rank,W,matfilename);
    //
    double tStore = timeStore.tacAndElapsed();
    std::cout << "... took @tStore = "<< tStore <<"\n";

    ////////////////////////////////////////////////////////////////////
    /// Free memory
    delete[] W;


    return 0;
}
