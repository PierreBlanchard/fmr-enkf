
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random> // for normal distribution generator


// ScalFMM includes
#include "Files/FFmaGenericLoader.hpp"
#include "Utils/FGlobal.hpp"
#include "Utils/FTic.hpp"
#include "Utils/FParameters.hpp"
#include "Utils/FParameterNames.hpp"
#include "Utils/FBlas.hpp" // for FBlas::potrf (and QR,SVD...)
#include "Utils/FMath.hpp"

// FMR includes
#include "Definition/FMRDefines.hpp"
#include "Correlations/CorrelationKernels.hpp"

#include "Utils/MatrixIO.hpp" // for input/output matrix-file
#include "Utils/VectorNorms.hpp" // for leverage scores

#include "Utils/Display.hpp" // In order to display vectors and arrays

// HMAT specific includes
#include "../Src/Clustering/FCCLKCluster.hpp"
#include "../Src/Utils/FMatrixIO.hpp"

#include "../Src/Containers/FPartitionsMapping.hpp"
#include "../Src/Utils/FSvgRect.hpp"
#include "../Src/Viewers/FDenseBlockWrapper.hpp"
#include "../Src/Blocks/FDenseBlock.hpp"



/**
 * In this file we load a spatial grid and generate a covariance matrix C using a Gaussian kernel.
 * Then, we compute the leverage scores, i.e. the squared 2 norm of the rows of V. If 
 * If SVD is used then leverage scores are exact, otherwise (RandSVD or fazstRandSVD) they are approximated.
 * 
 * Author: Pierre Blanchard (pierre.blanchard@inria.fr)
 * Date created: February 3rd, 2016
 */


int main(int argc, char* argv[])
{

    static const FParameterNames SvgOutParam = {
        {"-fout", "--out", "-out"} ,
         "Svg output directory."
    };
    static const FParameterNames ElemParam = {
        {"-nE", "-nbElements", "-elem"} ,
         "Nbof elements to partition."
    };
    static const FParameterNames DimParam = {
        {"-nD", "-nbDim", "-dim"} ,
         "Dimension of ambiant space."
    };
    static const FParameterNames NbPartitionsParam = {
        {"-Part", "-nbPartitions", "-nbClusters"} ,
         "Dim of the matrix."
    };
    static const FParameterNames NbPassesParam = {
        {"-Pass", "-nbPasses", "-nbPass"} ,
         "Dim of the matrix."
    };

    ////////////////////////////////////////////////////////////////////
    /// Help and description
    //FHelpDescribeAndExit(argc, argv,
    //                     "Generate a distance and a covariance matrix using a 3D grid (loaded from file), then compute leverage scores and store it in file."/*,
    //                     FParameterDefinitions::OctreeHeight,FParameterDefinitions::NbThreads,
    //                     FParameterDefinitions::OctreeSubHeight, FParameterDefinitions::InputFile,
    //                     FParameterDefinitions::InputBinFormat*/);

    std::cout << "Tests: Load a grid and perform clustering using kclusters or kmedoids algorithm, then write partitions in file (.svg and .fma)." << std::endl;

    ////////////////////////////////////////////////////////////////////
    /// TODOs
    ///
    //
    ////////////////////////////////////////////////////////////////////
    /// Command line examples
    /// 
    //./Tests/Release/testKClusters -binin -d unitSphere2000 -Part 8 -Pass 5
    

    ////////////////////////////////////////////////////////////////////
    /// Input file
    const std::string distributionName(FParameters::getStr(argc,argv,"-d",   "unitSphere2000"));
    const std::string distributionPath(FParameters::getStr(argc,argv,"-p2d", "../Data/FMAInput/"));
    std::string distributionFileName = distributionPath + distributionName;
    if(  FParameters::existParameter(argc, argv, FParameterDefinitions::InputBinFormat.options)){
        distributionFileName += ".bfma";
    }
    else {
        distributionFileName += ".fma";
    }
    const char* const filename       = FParameters::getStr(argc,argv,"-f", distributionFileName.c_str());

    ////////////////////////////////////////////////////////////////////
    /// Timers
    FTic time;
    time.tic();

    ////////////////////////////////////////////////////////////////////
    /// Parameters
    // Verbose (print matrices)
    const int verbose = FParameters::getValue(argc, argv, "-v", 0);

    // size of the grid
    const int nbElements = FParameters::getValue(argc,argv,"-nE", 1000); 

    // size of the grid
    const int nbDim = FParameters::getValue(argc,argv,"-nD", 3); 

    // Define number of partitions
    const int nbPartitions = FParameters::getValue(argc, argv, NbPartitionsParam.options, 4);

    // Define number of passes
    const int nbPasses = FParameters::getValue(argc, argv, NbPassesParam.options, 5);


    ////////////////////////////////////////////////////////////////////
    /// Output file
    const std::string partitionPath(FParameters::getStr(argc,argv,"-p2p", "../Data/Clustering/"));



    ////////////////////////////////////////////////////////////////////
    /// Cluster data using kclusters algorithm
    ////////////////////////////////////////////////////////////////////
    // Compute partitions from data matrix (i.e. grid)
    {

        std::cout << "Spatial grid read from file:" << filename << std::endl;
        // open particle file
        FFmaGenericLoader<FReal> loader(filename);
        if(!loader.isOpen()) throw std::runtime_error("Particle file couldn't be opened!");

        ////////////////////////////////////////////////////////////////////
        /// Load grid from distribution file
        //FPoint<FReal>* grid = new FPoint<FReal>[nbElements];
        FReal* grid = new FReal[nbElements*nbDim];

        for(FSize idxPart = 0 ; idxPart < nbElements ; ++idxPart){
            FPoint<FReal> position;
            FReal physicalValue = 0.0;
            loader.fillParticle(&position,&physicalValue);
            //grid[idxPart]=position;
            grid[idxPart+0*nbElements]=position.getX();
            grid[idxPart+1*nbElements]=position.getY();
            grid[idxPart+2*nbElements]=position.getZ();
        }


        // Test Cluster Center Method K-MEANS
        {
            FTic timeKMeans;
            double tKMeans;
            timeKMeans.tic();

            FCCLKCluster<FReal> partitioner(nbPartitions, nbElements, nbDim, grid, CCL::CCL_CCM_ARITHMETIC_MEAN, CCL::CCL_DIST_MEAN, nbPasses);

            tKMeans = timeKMeans.tacAndElapsed();
            std::cout << "... took @tKMeans = "<< tKMeans <<"\n";

            // Get index of partitions centroids
            std::unique_ptr<int[]> centroidsIdx(new int[nbElements]);
            partitioner.getCentroidsIdx(nbElements,centroidsIdx.get());

            // Count nb of particles in each partition
            std::unique_ptr<int[]> partitions(new int[nbPartitions]);
            partitioner.getPartitions(nbPartitions,partitions.get());
            {
                typedef FDenseBlock<FReal> CellClass;
                typedef FPartitionsMapping<FReal, CellClass> GridClass;

                GridClass bissection(nbElements, partitions.get(), nbPartitions);

                char svgName[1024];
                sprintf(svgName, "%s/%s-%s-P%d.svg", partitionPath.c_str(), distributionName.c_str(), "CCL_KMEANS_DIST_MEAN", nbPartitions);
                std::cout << "\tSave svg to " << svgName << "\n";
                FSvgRect output(svgName, nbElements);

                bissection.forAllBlocksDescriptor([&](const FBlockDescriptor& info){
                    output.addRectWithLegend(info.col, info.row, info.nbCols, info.nbRows, info.level);
                });

                // Write in .fma or .txt file
                char partName[1024];
                sprintf(partName, "%s/%s-%s-P%d.txt", partitionPath.c_str(), distributionName.c_str(), "CCL_KMEANS_DIST_MEAN", nbPartitions);
                std::cout << "\tSave partitions to " << partName << "\n";
                MatrixIO::writeCSV_part(nbElements,nbDim,grid,centroidsIdx.get(),std::string(partName));

            }

        }

        // Test Cluster Center Method K-MEDIANS
        {
            FTic timeKMedians;
            double tKMedians;
            timeKMedians.tic();

            FCCLKCluster<FReal> partitioner(nbPartitions, nbElements, nbDim, grid, CCL::CCL_CCM_MEDIAN, CCL::CCL_DIST_MEAN, nbPasses);

            tKMedians = timeKMedians.tacAndElapsed();
            std::cout << "... took @tKMedians = "<< tKMedians <<"\n";

            // Get index of partitions centroids
            std::unique_ptr<int[]> centroidsIdx(new int[nbElements]);
            partitioner.getCentroidsIdx(nbElements,centroidsIdx.get());

            // Count nb of particles in each partition
            std::unique_ptr<int[]> partitions(new int[nbPartitions]);
            partitioner.getPartitions(nbPartitions,partitions.get());
            {
                typedef FDenseBlock<FReal> CellClass;
                typedef FPartitionsMapping<FReal, CellClass> GridClass;

                GridClass bissection(nbElements, partitions.get(), nbPartitions);

                // Write in .svg file
                char svgName[1024];
                sprintf(svgName, "%s/%s-%s-P%d.svg", partitionPath.c_str(), distributionName.c_str(), "CCL_KMEDIANS_DIST_MEAN", nbPartitions);
                std::cout << "\tSave svg to " << svgName << "\n";
                FSvgRect output(svgName, nbElements);

                bissection.forAllBlocksDescriptor([&](const FBlockDescriptor& info){
                    output.addRectWithLegend(info.col, info.row, info.nbCols, info.nbRows, info.level);
                });

                // Write in .fma or .txt file
                char partName[1024];
                sprintf(partName, "%s/%s-%s-P%d.txt", partitionPath.c_str(), distributionName.c_str(), "CCL_KMEDIANS_DIST_MEAN", nbPartitions);
                std::cout << "\tSave partitions to " << partName << "\n";
                MatrixIO::writeCSV_part(nbElements,nbDim,grid,centroidsIdx.get(),std::string(partName));
                
            }
        }


        std::cout << "Distance matrix computed from grid:" << std::endl;

        // Read distances
        FReal* distances = new FReal[nbElements*nbElements];
        FBlas::setzero(int(nbElements*nbElements),distances);

        // Build (symmetric) kernel matrix
        FTic timeAssK;

        for(FSize idxRow = 0 ; idxRow < nbElements  ; ++idxRow)
            for(FSize idxCol = idxRow ; idxCol < nbElements ; ++idxCol) {
                FReal diffX(grid[idxRow+0*nbElements]-grid[idxCol+0*nbElements]);
                FReal diffY(grid[idxRow+1*nbElements]-grid[idxCol+1*nbElements]);
                FReal diffZ(grid[idxRow+2*nbElements]-grid[idxCol+2*nbElements]);
                distances[idxRow*nbElements+idxCol] = FMath::Sqrt(diffX*diffX+diffY*diffY+diffZ*diffZ);
                if(idxCol!=idxRow)
                    distances[idxCol*nbElements+idxRow] = distances[idxRow*nbElements+idxCol];
            }

        double tAssK = timeAssK.tacAndElapsed();
        std::cout << "... took @tAssK = "<< tAssK <<"\n";

        // Test Cluster Center Method K-MEDOIDS
        {
            FTic timeKMedoids;
            double tKMedoids;
            timeKMedoids.tic();

            FCCLKCluster<FReal> partitioner(nbPartitions, nbElements, distances, nbPasses);

            tKMedoids = timeKMedoids.tacAndElapsed();
            std::cout << "... took @tKMedoids = "<< tKMedoids <<"\n";

            // Get index of partitions centroids
            std::unique_ptr<int[]> centroidsIdx(new int[nbElements]);
            partitioner.getCentroidsIdx(nbElements,centroidsIdx.get());

                // Count nb of particles in each partition
            std::unique_ptr<int[]> partitions(new int[nbPartitions]);
            partitioner.getPartitions(nbPartitions,partitions.get());
            {
                typedef FDenseBlock<FReal> CellClass;
                typedef FPartitionsMapping<FReal, CellClass> GridClass;

                GridClass bissection(nbElements, partitions.get(), nbPartitions);

                // Write in .svg file
                char svgName[1024];
                sprintf(svgName, "%s/%s-%s-P%d.svg", partitionPath.c_str(), distributionName.c_str(), "CCL_KMEDOIDS", nbPartitions);
                std::cout << "\tSave svg to " << svgName << "\n";
                FSvgRect output(svgName, nbElements);

                bissection.forAllBlocksDescriptor([&](const FBlockDescriptor& info){
                    output.addRectWithLegend(info.col, info.row, info.nbCols, info.nbRows, info.level);
                });

                // Write in .fma or .txt file
                char partName[1024];
                sprintf(partName, "%s/%s-%s-P%d.txt", partitionPath.c_str(), distributionName.c_str(), "CCL_KMEDOIDS", nbPartitions);
                std::cout << "\tSave partitions to " << partName << "\n";
                MatrixIO::writeCSV_part(nbElements,nbDim,grid,centroidsIdx.get(),std::string(partName));
                
            }

        }

    }




    ////////////////////////////////////////////////////////////////////
    /// Free memory


    return 0;
}
